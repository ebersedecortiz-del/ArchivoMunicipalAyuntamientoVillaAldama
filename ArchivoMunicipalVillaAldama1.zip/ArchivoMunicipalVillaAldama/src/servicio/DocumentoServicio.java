
package servicio;

import dao.DocumentoDAO;
import modelo.Documento;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class DocumentoServicio {

    private final DocumentoDAO documentoDAO = new DocumentoDAO();

    /**
     * Consulta los documentos registrados.
     */
    public List<Documento> listarDocumentos() throws SQLException {
        return documentoDAO.listarTodos();
    }

    /**
     * Registra un documento después de validar sus datos.
     */
    public long registrarDocumento(Documento documento)
            throws SQLException {

        validarDocumento(documento);

        return documentoDAO.registrar(documento);
    }

    /**
     * Actualiza un documento existente después de validar sus datos.
     */
    public boolean actualizarDocumento(Documento documento)
            throws SQLException {

        if (documento == null) {
            throw new IllegalArgumentException(
                "El documento que se desea actualizar no puede ser nulo."
            );
        }

        if (documento.getIdDocumento() <= 0) {
            throw new IllegalArgumentException(
                "El identificador del documento debe ser positivo."
            );
        }

        validarDocumento(documento);

        return documentoDAO.actualizar(documento);
    }

    /**
     * Comprueba las reglas básicas para registrar o actualizar.
     */
    private void validarDocumento(Documento documento) {

        if (documento == null) {
            throw new IllegalArgumentException(
                "Los datos del documento son obligatorios."
            );
        }

        // Folio interno
        String folio = documento.getFolioInterno();

        if (folio == null || folio.isBlank()) {
            throw new IllegalArgumentException(
                "El folio interno es obligatorio."
            );
        }

        if (folio.trim().length() > 40) {
            throw new IllegalArgumentException(
                "El folio interno no puede superar 40 caracteres."
            );
        }

        // Nombre
        String nombre = documento.getNombre();

        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException(
                "El nombre del documento es obligatorio."
            );
        }

        if (nombre.trim().length() > 250) {
            throw new IllegalArgumentException(
                "El nombre no puede superar 250 caracteres."
            );
        }

        // Catálogos relacionados
        if (documento.getIdCategoria() <= 0) {
            throw new IllegalArgumentException(
                "Debes seleccionar una categoría válida."
            );
        }

        if (documento.getIdTipo() <= 0) {
            throw new IllegalArgumentException(
                "Debes seleccionar un tipo documental válido."
            );
        }

        if (documento.getIdArea() <= 0) {
            throw new IllegalArgumentException(
                "Debes seleccionar un área administrativa válida."
            );
        }

        // Expediente opcional
        if (documento.getIdExpediente() != null
                && documento.getIdExpediente() <= 0) {
            throw new IllegalArgumentException(
                "El identificador del expediente debe ser positivo."
            );
        }

        // Fecha de emisión
        LocalDate fechaEmision = documento.getFechaEmision();

        if (fechaEmision == null) {
            throw new IllegalArgumentException(
                "La fecha de emisión es obligatoria."
            );
        }

        if (fechaEmision.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException(
                "La fecha de emisión no puede ser futura."
            );
        }

        // Fecha de recepción opcional
        LocalDate fechaRecepcion = documento.getFechaRecepcion();

        if (fechaRecepcion != null) {

            if (fechaRecepcion.isAfter(LocalDate.now())) {
                throw new IllegalArgumentException(
                    "La fecha de recepción no puede ser futura."
                );
            }

            if (fechaRecepcion.isBefore(fechaEmision)) {
                throw new IllegalArgumentException(
                    "La fecha de recepción no puede ser anterior "
                    + "a la fecha de emisión."
                );
            }
        }

        // Palabras clave
        String palabrasClave = documento.getPalabrasClave();

        if (palabrasClave != null
                && palabrasClave.length() > 500) {
            throw new IllegalArgumentException(
                "Las palabras clave no pueden superar "
                + "500 caracteres."
            );
        }

        // Descripción
        String descripcion = documento.getDescripcion();

        if (descripcion != null
                && descripcion.length() > 65535) {
            throw new IllegalArgumentException(
                "La descripción supera la longitud permitida."
            );
        }

        // Estado
        String estado = documento.getEstado();

        if (estado != null && estado.length() > 30) {
            throw new IllegalArgumentException(
                "El estado no puede superar 30 caracteres."
            );
        }
    }
}
