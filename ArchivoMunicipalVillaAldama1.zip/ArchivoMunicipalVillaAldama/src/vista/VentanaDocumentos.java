
package vista;

import conexion.ConexionBD;
import dao.CatalogoDAO;
import modelo.Documento;
import modelo.OpcionCatalogo;
import servicio.DocumentoServicio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

public class VentanaDocumentos extends JFrame {

    private final JTextField txtFolio = new JTextField(25);
    private final JTextField txtNombre = new JTextField(25);
    private final JTextField txtFechaEmision = new JTextField(25);
    private final JTextField txtFechaRecepcion = new JTextField(25);
    private final JTextField txtExpediente = new JTextField(25);
    private final JTextField txtPalabrasClave = new JTextField(25);

    private final JTextArea txtDescripcion = new JTextArea(3, 25);

    private final JComboBox<OpcionCatalogo> cmbCategoria =
            new JComboBox<>();

    private final JComboBox<OpcionCatalogo> cmbTipo =
            new JComboBox<>();

    private final JComboBox<OpcionCatalogo> cmbArea =
            new JComboBox<>();

    private final DefaultTableModel modeloTabla =
            new DefaultTableModel(
                    new Object[]{
                        "ID",
                        "Folio interno",
                        "Nombre",
                        "Fecha de emisión",
                        "Estado"
                    }, 0) {

                @Override
                public boolean isCellEditable(
                        int fila, int columna) {
                    return false;
                }
            };

    private final JTable tablaDocumentos =
            new JTable(modeloTabla);

    private final DocumentoServicio documentoServicio =
            new DocumentoServicio();

    private final CatalogoDAO catalogoDAO =
            new CatalogoDAO();

    private final JButton btnRegistrar =
            new JButton("Registrar documento");

    private final JButton btnModificar =
            new JButton("Cargar selección para modificar");

    private final JButton btnGuardarCambios =
            new JButton("Guardar modificación");

    private final JButton btnConsultar =
            new JButton("Consultar documentos");

    private final JButton btnLimpiar =
            new JButton("Limpiar / cancelar edición");

    private final JButton btnConexion =
            new JButton("Probar conexión");

    private Documento documentoEnEdicion = null;

    public VentanaDocumentos() {

        setTitle(
                "Sistema Integral de Gestión Documental - Villa Aldama");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setSize(1150, 780);

        setMinimumSize(new Dimension(900, 650));

        setLocationRelativeTo(null);

        construirInterfaz();

        cargarCatalogos();

        consultarDocumentos();

        actualizarEstadoBotones();
    }

    private void construirInterfaz() {

        JPanel principal =
                new JPanel(new BorderLayout(10, 10));

        principal.setBorder(
                BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titulo = new JLabel(
                "GESTIÓN DOCUMENTAL Y ARCHIVO MUNICIPAL",
                SwingConstants.CENTER);

        titulo.setFont(new Font("Serif", Font.BOLD, 23));

        principal.add(titulo, BorderLayout.NORTH);

        JPanel centro =
                new JPanel(new BorderLayout(10, 10));

        JPanel formulario =
                new JPanel(new GridBagLayout());

        formulario.setBorder(
                BorderFactory.createTitledBorder(
                        "Datos del documento"));

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(5, 7, 5, 7);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        int fila = 0;

        agregarCampo(
                formulario, gbc, fila++,
                "Folio interno:", txtFolio);

        agregarCampo(
                formulario, gbc, fila++,
                "Nombre del documento:", txtNombre);

        agregarCampo(
                formulario, gbc, fila++,
                "Fecha de emisión (AAAA-MM-DD):",
                txtFechaEmision);

        agregarCampo(
                formulario, gbc, fila++,
                "Fecha de recepción (opcional):",
                txtFechaRecepcion);

        agregarCampo(
                formulario, gbc, fila++,
                "Categoría:", cmbCategoria);

        agregarCampo(
                formulario, gbc, fila++,
                "Tipo documental:", cmbTipo);

        agregarCampo(
                formulario, gbc, fila++,
                "Área administrativa:", cmbArea);

        agregarCampo(
                formulario, gbc, fila++,
                "ID de expediente (opcional):",
                txtExpediente);

        agregarCampo(
                formulario, gbc, fila++,
                "Palabras clave (opcional):",
                txtPalabrasClave);

        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.weightx = 0;

        formulario.add(new JLabel("Descripción:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;

        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);

        formulario.add(
                new JScrollPane(txtDescripcion), gbc);

        centro.add(formulario, BorderLayout.NORTH);

        JPanel panelTabla =
                new JPanel(new BorderLayout());

        panelTabla.setBorder(
                BorderFactory.createTitledBorder(
                        "Documentos registrados"));

        tablaDocumentos.setAutoCreateRowSorter(true);

        tablaDocumentos.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION);

        panelTabla.add(
                new JScrollPane(tablaDocumentos),
                BorderLayout.CENTER);

        centro.add(panelTabla, BorderLayout.CENTER);

        principal.add(centro, BorderLayout.CENTER);

        btnRegistrar.addActionListener(
                e -> registrarDocumento());

        btnModificar.addActionListener(
                e -> cargarSeleccionParaModificar());

        btnGuardarCambios.addActionListener(
                e -> guardarModificacion());

        btnConsultar.addActionListener(
                e -> consultarDocumentos());

        btnLimpiar.addActionListener(
                e -> limpiarFormulario());

        btnConexion.addActionListener(
                e -> probarConexion());

        JPanel botones =
                new JPanel(new FlowLayout(
                        FlowLayout.CENTER, 8, 5));

        botones.add(btnRegistrar);
        botones.add(btnModificar);
        botones.add(btnGuardarCambios);
        botones.add(btnConsultar);
        botones.add(btnLimpiar);
        botones.add(btnConexion);

        principal.add(botones, BorderLayout.SOUTH);

        setContentPane(principal);
    }

    private void agregarCampo(
            JPanel panel,
            GridBagConstraints gbc,
            int fila,
            String etiqueta,
            Component campo) {

        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.weightx = 0;

        panel.add(new JLabel(etiqueta), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;

        panel.add(campo, gbc);
    }

    private void cargarCatalogos() {

        try {

            cmbCategoria.removeAllItems();
            cmbTipo.removeAllItems();
            cmbArea.removeAllItems();

            List<OpcionCatalogo> categorias =
                    catalogoDAO.listarCategorias();

            List<OpcionCatalogo> tipos =
                    catalogoDAO.listarTiposDocumentales();

            List<OpcionCatalogo> areas =
                    catalogoDAO.listarAreas();

            for (OpcionCatalogo opcion : categorias) {
                cmbCategoria.addItem(opcion);
            }

            for (OpcionCatalogo opcion : tipos) {
                cmbTipo.addItem(opcion);
            }

            for (OpcionCatalogo opcion : areas) {
                cmbArea.addItem(opcion);
            }

            if (categorias.isEmpty()
                    || tipos.isEmpty()
                    || areas.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Uno o más catálogos están vacíos.\n\n"
                        + "Se necesitan categorías, tipos documentales "
                        + "y áreas administrativas autorizados "
                        + "para registrar documentos.",
                        "Catálogos pendientes",
                        JOptionPane.WARNING_MESSAGE);
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible cargar los catálogos.\n"
                    + e.getMessage(),
                    "Error de catálogos",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarEstadoBotones() {

        boolean catalogosDisponibles =
                cmbCategoria.getItemCount() > 0
                && cmbTipo.getItemCount() > 0
                && cmbArea.getItemCount() > 0;

        btnRegistrar.setEnabled(
                catalogosDisponibles
                && documentoEnEdicion == null);

        btnModificar.setEnabled(
                documentoEnEdicion == null
                && tablaDocumentos.getRowCount() > 0);

        btnGuardarCambios.setEnabled(
                catalogosDisponibles
                && documentoEnEdicion != null);

        if (!catalogosDisponibles) {

            btnRegistrar.setToolTipText(
                    "Faltan catálogos autorizados.");

            btnGuardarCambios.setToolTipText(
                    "Faltan catálogos autorizados.");

        } else {

            btnRegistrar.setToolTipText(
                    "Registrar un documento nuevo.");

            btnGuardarCambios.setToolTipText(
                    "Validar y guardar los cambios.");
        }

        btnModificar.setToolTipText(
                "Selecciona una fila de la tabla antes de modificar.");
    }

    private void registrarDocumento() {

        if (documentoEnEdicion != null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Termina o cancela la edición antes de registrar "
                    + "otro documento.",
                    "Edición en curso",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {

            Documento documento = leerFormulario();

            long idGenerado =
                    documentoServicio.registrarDocumento(documento);

            JOptionPane.showMessageDialog(
                    this,
                    "Documento registrado correctamente.\n"
                    + "Identificador generado: " + idGenerado,
                    "Registro exitoso",
                    JOptionPane.INFORMATION_MESSAGE);

            limpiarFormulario();
            consultarDocumentos();

        } catch (DateTimeParseException e) {

            mostrarErrorFecha();

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "El ID de expediente debe ser un número entero válido.",
                    "Dato incorrecto",
                    JOptionPane.ERROR_MESSAGE);

        } catch (IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                    this,
                    e.getMessage(),
                    "Validación",
                    JOptionPane.WARNING_MESSAGE);

        } catch (SQLException e) {

            mostrarErrorBaseDatos(e);
        }
    }

    private Documento leerFormulario() {

        Documento documento = new Documento();

        documento.setFolioInterno(
                txtFolio.getText().trim());

        documento.setNombre(
                txtNombre.getText().trim());

        documento.setDescripcion(
                textoONull(txtDescripcion.getText()));

        documento.setPalabrasClave(
                textoONull(txtPalabrasClave.getText()));

        OpcionCatalogo categoria =
                (OpcionCatalogo) cmbCategoria.getSelectedItem();

        OpcionCatalogo tipo =
                (OpcionCatalogo) cmbTipo.getSelectedItem();

        OpcionCatalogo area =
                (OpcionCatalogo) cmbArea.getSelectedItem();

        if (categoria == null || tipo == null || area == null) {
            throw new IllegalArgumentException(
                    "Selecciona una categoría, un tipo documental "
                    + "y un área administrativa.");
        }

        documento.setIdCategoria(categoria.getId());
        documento.setIdTipo(tipo.getId());
        documento.setIdArea(area.getId());

        String fechaEmision =
                txtFechaEmision.getText().trim();

        if (fechaEmision.isEmpty()) {
            throw new IllegalArgumentException(
                    "La fecha de emisión es obligatoria.");
        }

        documento.setFechaEmision(
                LocalDate.parse(fechaEmision));

        String fechaRecepcion =
                txtFechaRecepcion.getText().trim();

        if (!fechaRecepcion.isEmpty()) {
            documento.setFechaRecepcion(
                    LocalDate.parse(fechaRecepcion));
        } else {
            documento.setFechaRecepcion(null);
        }

        String expediente =
                txtExpediente.getText().trim();

        if (!expediente.isEmpty()) {

            long idExpediente =
                    Long.parseLong(expediente);

            if (idExpediente <= 0) {
                throw new IllegalArgumentException(
                        "El ID de expediente debe ser positivo.");
            }

            documento.setIdExpediente(idExpediente);

        } else {
            documento.setIdExpediente(null);
        }

        documento.setEstado("REGISTRADO");
        documento.setCreadoPor(null);

        return documento;
    }

    private void cargarSeleccionParaModificar() {

        int filaVista =
                tablaDocumentos.getSelectedRow();

        if (filaVista < 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Selecciona un documento de la tabla "
                    + "antes de pulsar este botón.",
                    "Documento no seleccionado",
                    JOptionPane.WARNING_MESSAGE);

            return;
        }

        int filaModelo =
                tablaDocumentos.convertRowIndexToModel(filaVista);

        long idDocumento;

        try {

            idDocumento = Long.parseLong(
                    modeloTabla.getValueAt(filaModelo, 0).toString());

            List<Documento> documentos =
                    documentoServicio.listarDocumentos();

            Documento encontrado = null;

            for (Documento documento : documentos) {

                if (documento.getIdDocumento() == idDocumento) {
                    encontrado = documento;
                    break;
                }
            }

            if (encontrado == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "El documento seleccionado ya no existe "
                        + "en la base de datos. Actualiza la consulta.",
                        "Documento no encontrado",
                        JOptionPane.WARNING_MESSAGE);

                consultarDocumentos();
                return;
            }

            documentoEnEdicion = encontrado;

            txtFolio.setText(encontrado.getFolioInterno());
            txtNombre.setText(encontrado.getNombre());

            txtFechaEmision.setText(
                    encontrado.getFechaEmision() == null
                    ? ""
                    : encontrado.getFechaEmision().toString());

            txtFechaRecepcion.setText(
                    encontrado.getFechaRecepcion() == null
                    ? ""
                    : encontrado.getFechaRecepcion().toString());

            txtExpediente.setText(
                    encontrado.getIdExpediente() == null
                    ? ""
                    : encontrado.getIdExpediente().toString());

            txtPalabrasClave.setText(
                    encontrado.getPalabrasClave() == null
                    ? ""
                    : encontrado.getPalabrasClave());

            txtDescripcion.setText(
                    encontrado.getDescripcion() == null
                    ? ""
                    : encontrado.getDescripcion());

            seleccionarCatalogo(
                    cmbCategoria, encontrado.getIdCategoria());

            seleccionarCatalogo(
                    cmbTipo, encontrado.getIdTipo());

            seleccionarCatalogo(
                    cmbArea, encontrado.getIdArea());

            txtFolio.setEditable(false);

            actualizarEstadoBotones();

            JOptionPane.showMessageDialog(
                    this,
                    "Documento cargado para edición.\n\n"
                    + "Modifica los campos necesarios y pulsa "
                    + "\"Guardar modificación\".\n"
                    + "El folio interno no se puede cambiar.",
                    "Edición de documento",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {

            mostrarErrorBaseDatos(e);

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "No se pudo interpretar el identificador "
                    + "del documento seleccionado.",
                    "Error de selección",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void seleccionarCatalogo(
            JComboBox<OpcionCatalogo> combo,
            long idBuscado) {

        for (int i = 0; i < combo.getItemCount(); i++) {

            OpcionCatalogo opcion = combo.getItemAt(i);

            if (opcion.getId() == idBuscado) {
                combo.setSelectedIndex(i);
                return;
            }
        }

        combo.setSelectedIndex(-1);
    }

    private void guardarModificacion() {

        if (documentoEnEdicion == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Primero selecciona y carga un documento "
                    + "para modificar.",
                    "No hay edición activa",
                    JOptionPane.WARNING_MESSAGE);

            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
                this,
                "¿Deseas guardar los cambios del documento?\n\n"
                + "ID: " + documentoEnEdicion.getIdDocumento()
                + "\nFolio: "
                + documentoEnEdicion.getFolioInterno(),
                "Confirmar modificación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            Documento actualizado = leerFormulario();

            // Se conserva la identidad del documento original.
            actualizado.setIdDocumento(
                    documentoEnEdicion.getIdDocumento());

            actualizado.setFolioInterno(
                    documentoEnEdicion.getFolioInterno());

            // Se conservan los datos originales de creación.
            actualizado.setCreadoPor(
                    documentoEnEdicion.getCreadoPor());

            actualizado.setEstado(
                    documentoEnEdicion.getEstado());

            boolean modificado =
                    documentoServicio.actualizarDocumento(actualizado);

            if (modificado) {

                JOptionPane.showMessageDialog(
                        this,
                        "Los cambios se guardaron correctamente.",
                        "Modificación exitosa",
                        JOptionPane.INFORMATION_MESSAGE);

                limpiarFormulario();
                consultarDocumentos();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No se actualizó ningún registro. "
                        + "El documento puede haber sido eliminado "
                        + "o ya no existir.",
                        "Sin cambios",
                        JOptionPane.WARNING_MESSAGE);
            }

        } catch (DateTimeParseException e) {

            mostrarErrorFecha();

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "El ID de expediente debe ser un número entero válido.",
                    "Dato incorrecto",
                    JOptionPane.ERROR_MESSAGE);

        } catch (IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                    this,
                    e.getMessage(),
                    "Validación",
                    JOptionPane.WARNING_MESSAGE);

        } catch (SQLException e) {

            mostrarErrorBaseDatos(e);
        }
    }

    private String textoONull(String texto) {

        if (texto == null || texto.isBlank()) {
            return null;
        }

        return texto.trim();
    }

    private void consultarDocumentos() {

        try {

            List<Documento> documentos =
                    documentoServicio.listarDocumentos();

            modeloTabla.setRowCount(0);

            for (Documento documento : documentos) {

                modeloTabla.addRow(new Object[]{
                    documento.getIdDocumento(),
                    documento.getFolioInterno(),
                    documento.getNombre(),
                    documento.getFechaEmision(),
                    documento.getEstado()
                });
            }

            actualizarEstadoBotones();

            setTitle(
                    "Sistema Integral de Gestión Documental - "
                    + documentos.size() + " documentos");

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible consultar los documentos.\n"
                    + e.getMessage(),
                    "Error de consulta",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarFormulario() {

        documentoEnEdicion = null;

        txtFolio.setEditable(true);

        txtFolio.setText("");
        txtNombre.setText("");
        txtFechaEmision.setText("");
        txtFechaRecepcion.setText("");
        txtExpediente.setText("");
        txtPalabrasClave.setText("");
        txtDescripcion.setText("");

        cmbCategoria.setSelectedIndex(-1);
        cmbTipo.setSelectedIndex(-1);
        cmbArea.setSelectedIndex(-1);

        tablaDocumentos.clearSelection();

        actualizarEstadoBotones();

        txtFolio.requestFocus();
    }

    private void probarConexion() {

        try (Connection conexion = ConexionBD.conectar()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Conexión exitosa con MySQL.\n"
                    + "Base de datos: " + conexion.getCatalog(),
                    "Conexión",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {

            mostrarErrorBaseDatos(e);
        }
    }

    private void mostrarErrorFecha() {

        JOptionPane.showMessageDialog(
                this,
                "La fecha no es válida.\n"
                + "Utiliza el formato AAAA-MM-DD, "
                + "por ejemplo 2026-10-21.",
                "Fecha incorrecta",
                JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarErrorBaseDatos(SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "No fue posible completar la operación en MySQL.\n\n"
                + "Detalle: " + e.getMessage(),
                "Error de base de datos",
                JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            VentanaDocumentos ventana =
                    new VentanaDocumentos();

            ventana.setVisible(true);
        });
    }
}
