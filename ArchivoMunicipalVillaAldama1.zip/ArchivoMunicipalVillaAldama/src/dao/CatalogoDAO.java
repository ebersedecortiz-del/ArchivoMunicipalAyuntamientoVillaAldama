
package dao;

import conexion.ConexionBD;
import modelo.OpcionCatalogo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CatalogoDAO {

    public List<OpcionCatalogo> listarCategorias()
            throws SQLException {

        String sql = """
            SELECT id_categoria, nombre
            FROM categorias
            WHERE activa = 1
            ORDER BY nombre
            """;

        return consultarCatalogo(sql, "id_categoria");
    }

    public List<OpcionCatalogo> listarTiposDocumentales()
            throws SQLException {

        String sql = """
            SELECT id_tipo, nombre
            FROM tipos_documentales
            WHERE activo = 1
            ORDER BY nombre
            """;

        return consultarCatalogo(sql, "id_tipo");
    }

    public List<OpcionCatalogo> listarAreas()
            throws SQLException {

        String sql = """
            SELECT id_area, nombre
            FROM areas
            WHERE activa = 1
            ORDER BY nombre
            """;

        return consultarCatalogo(sql, "id_area");
    }

    private List<OpcionCatalogo> consultarCatalogo(
            String sql,
            String columnaId) throws SQLException {

        List<OpcionCatalogo> opciones = new ArrayList<>();

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                     conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            while (resultado.next()) {
                opciones.add(
                        new OpcionCatalogo(
                                resultado.getLong(columnaId),
                                resultado.getString("nombre")
                        )
                );
            }
        }

        return opciones;
    }
}
