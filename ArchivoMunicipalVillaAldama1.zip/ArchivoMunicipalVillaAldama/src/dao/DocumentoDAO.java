
package dao;

import conexion.ConexionBD;
import modelo.Documento;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class DocumentoDAO {

    /**
     * Consulta todos los documentos registrados.
     */
    public List<Documento> listarTodos() throws SQLException {

        List<Documento> documentos = new ArrayList<>();

        String sql = """
            SELECT id_documento,
                   folio_interno,
                   nombre,
                   descripcion,
                   id_categoria,
                   id_tipo,
                   id_area,
                   id_expediente,
                   fecha_emision,
                   fecha_recepcion,
                   palabras_clave,
                   estado,
                   creado_por
            FROM documentos
            ORDER BY id_documento DESC
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia = conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            while (resultado.next()) {

                Documento documento = new Documento();

                documento.setIdDocumento(
                    resultado.getLong("id_documento")
                );

                documento.setFolioInterno(
                    resultado.getString("folio_interno")
                );

                documento.setNombre(
                    resultado.getString("nombre")
                );

                documento.setDescripcion(
                    resultado.getString("descripcion")
                );

                documento.setIdCategoria(
                    resultado.getLong("id_categoria")
                );

                documento.setIdTipo(
                    resultado.getLong("id_tipo")
                );

                documento.setIdArea(
                    resultado.getLong("id_area")
                );

                long idExpediente =
                    resultado.getLong("id_expediente");

                if (resultado.wasNull()) {
                    documento.setIdExpediente(null);
                } else {
                    documento.setIdExpediente(idExpediente);
                }

                Date fechaEmision =
                    resultado.getDate("fecha_emision");

                if (fechaEmision != null) {
                    documento.setFechaEmision(
                        fechaEmision.toLocalDate()
                    );
                }

                Date fechaRecepcion =
                    resultado.getDate("fecha_recepcion");

                if (fechaRecepcion != null) {
                    documento.setFechaRecepcion(
                        fechaRecepcion.toLocalDate()
                    );
                }

                documento.setPalabrasClave(
                    resultado.getString("palabras_clave")
                );

                documento.setEstado(
                    resultado.getString("estado")
                );

                long creadoPor =
                    resultado.getLong("creado_por");

                if (resultado.wasNull()) {
                    documento.setCreadoPor(null);
                } else {
                    documento.setCreadoPor(creadoPor);
                }

                documentos.add(documento);
            }
        }

        return documentos;
    }

    /**
     * Registra un documento nuevo y devuelve su identificador.
     */
    public long registrar(Documento documento) throws SQLException {

        String sql = """
            INSERT INTO documentos (
                folio_interno,
                nombre,
                descripcion,
                id_categoria,
                id_tipo,
                id_area,
                id_expediente,
                fecha_emision,
                fecha_recepcion,
                palabras_clave,
                estado,
                creado_por
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                 conexion.prepareStatement(
                     sql, Statement.RETURN_GENERATED_KEYS
                 )) {

            sentencia.setString(
                1, documento.getFolioInterno()
            );

            sentencia.setString(
                2, documento.getNombre()
            );

            sentencia.setString(
                3, documento.getDescripcion()
            );

            sentencia.setLong(
                4, documento.getIdCategoria()
            );

            sentencia.setLong(
                5, documento.getIdTipo()
            );

            sentencia.setLong(
                6, documento.getIdArea()
            );

            if (documento.getIdExpediente() != null) {
                sentencia.setLong(
                    7, documento.getIdExpediente()
                );
            } else {
                sentencia.setNull(7, Types.BIGINT);
            }

            sentencia.setDate(
                8, Date.valueOf(documento.getFechaEmision())
            );

            if (documento.getFechaRecepcion() != null) {
                sentencia.setDate(
                    9, Date.valueOf(documento.getFechaRecepcion())
                );
            } else {
                sentencia.setNull(9, Types.DATE);
            }

            sentencia.setString(
                10, documento.getPalabrasClave()
            );

            String estado = documento.getEstado();

            if (estado == null || estado.isBlank()) {
                estado = "REGISTRADO";
            }

            sentencia.setString(11, estado);

            if (documento.getCreadoPor() != null) {
                sentencia.setLong(
                    12, documento.getCreadoPor()
                );
            } else {
                sentencia.setNull(12, Types.BIGINT);
            }

            int filasInsertadas = sentencia.executeUpdate();

            if (filasInsertadas != 1) {
                throw new SQLException(
                    "No fue posible registrar el documento."
                );
            }

            try (ResultSet claves =
                     sentencia.getGeneratedKeys()) {

                if (claves.next()) {
                    return claves.getLong(1);
                }
            }

            throw new SQLException(
                "El documento se registró, pero no se pudo "
                + "recuperar su identificador."
            );
        }
    }

    /**
     * Modifica los datos de un documento existente.
     * El folio interno y el identificador no se modifican.
     *
     * Devuelve true si se actualizó una fila.
     */
    public boolean actualizar(Documento documento)
            throws SQLException {

        String sql = """
            UPDATE documentos
            SET nombre = ?,
                descripcion = ?,
                id_categoria = ?,
                id_tipo = ?,
                id_area = ?,
                id_expediente = ?,
                fecha_emision = ?,
                fecha_recepcion = ?,
                palabras_clave = ?,
                estado = ?
            WHERE id_documento = ?
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                 conexion.prepareStatement(sql)) {

            sentencia.setString(
                1, documento.getNombre()
            );

            sentencia.setString(
                2, documento.getDescripcion()
            );

            sentencia.setLong(
                3, documento.getIdCategoria()
            );

            sentencia.setLong(
                4, documento.getIdTipo()
            );

            sentencia.setLong(
                5, documento.getIdArea()
            );

            if (documento.getIdExpediente() != null) {
                sentencia.setLong(
                    6, documento.getIdExpediente()
                );
            } else {
                sentencia.setNull(6, Types.BIGINT);
            }

            if (documento.getFechaEmision() != null) {
                sentencia.setDate(
                    7, Date.valueOf(documento.getFechaEmision())
                );
            } else {
                sentencia.setNull(7, Types.DATE);
            }

            if (documento.getFechaRecepcion() != null) {
                sentencia.setDate(
                    8, Date.valueOf(documento.getFechaRecepcion())
                );
            } else {
                sentencia.setNull(8, Types.DATE);
            }

            sentencia.setString(
                9, documento.getPalabrasClave()
            );

            sentencia.setString(
                10, documento.getEstado()
            );

            sentencia.setLong(
                11, documento.getIdDocumento()
            );

            return sentencia.executeUpdate() == 1;
        }
    }
}
