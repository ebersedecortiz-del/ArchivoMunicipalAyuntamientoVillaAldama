
package modelo;

public class OpcionCatalogo {

    private long id;
    private String nombre;

    public OpcionCatalogo(long id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
