
package util;

import dao.UsuarioDAO;
import modelo.Usuario;

import javax.swing.*;
import java.awt.GridLayout;
import java.util.Arrays;

public class RestablecerContrasenaAdministrador {

    public static void main(String[] args) {

        UsuarioDAO usuarioDAO = new UsuarioDAO();

        String nombreUsuario = JOptionPane.showInputDialog(
                null,
                "Escribe el nombre de usuario del administrador:"
        );

        if (nombreUsuario == null || nombreUsuario.isBlank()) {
            return;
        }

        JPasswordField txtNueva = new JPasswordField();
        JPasswordField txtConfirmar = new JPasswordField();

        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));

        panel.add(new JLabel("Nueva contraseña (mínimo 12 caracteres):"));
        panel.add(txtNueva);

        panel.add(new JLabel("Confirmar nueva contraseña:"));
        panel.add(txtConfirmar);

        int opcion = JOptionPane.showConfirmDialog(
                null,
                panel,
                "Restablecer contraseña de administrador",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (opcion != JOptionPane.OK_OPTION) {
            return;
        }

        char[] nueva = txtNueva.getPassword();
        char[] confirmar = txtConfirmar.getPassword();

        try {

            if (nueva.length < 12) {
                JOptionPane.showMessageDialog(
                        null,
                        "La contraseña debe tener al menos 12 caracteres."
                );
                return;
            }

            if (!Arrays.equals(nueva, confirmar)) {
                JOptionPane.showMessageDialog(
                        null,
                        "Las contraseñas no coinciden."
                );
                return;
            }

            Usuario usuario = usuarioDAO.buscarPorNombreUsuario(
                    nombreUsuario.trim()
            );

            if (usuario == null
                    || !"ADMINISTRADOR".equals(usuario.getRol())) {

                JOptionPane.showMessageDialog(
                        null,
                        "No se encontró una cuenta con el rol ADMINISTRADOR.",
                        "Cuenta no válida",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            if (!usuario.isActivo()) {
                JOptionPane.showMessageDialog(
                        null,
                        "La cuenta está desactivada. "
                        + "Primero debe revisarse su estado."
                );
                return;
            }

            String nuevoHash =
                    SeguridadContrasena.generarHash(nueva);

            boolean actualizado =
                    usuarioDAO.actualizarHashContrasena(
                            usuario.getIdUsuario(),
                            nuevoHash
                    );

            if (actualizado) {

                JOptionPane.showMessageDialog(
                        null,
                        "Contraseña restablecida correctamente.\n"
                        + "Usuario: " + usuario.getNombreUsuario()
                        + "\nYa puedes iniciar sesión con tu nueva contraseña."
                );

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "No fue posible actualizar la contraseña."
                );
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Ocurrió un error al restablecer la contraseña:\n"
                    + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );

        } finally {

            Arrays.fill(nueva, '\0');
            Arrays.fill(confirmar, '\0');

            txtNueva.setText("");
            txtConfirmar.setText("");
        }
    }
}
