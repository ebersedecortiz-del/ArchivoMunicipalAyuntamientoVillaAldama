
package util;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class SeguridadContrasena {

    private static final String ALGORITMO =
            "PBKDF2WithHmacSHA256";

    private static final int ITERACIONES = 600_000;
    private static final int LONGITUD_HASH = 256;
    private static final int LONGITUD_SAL = 16;

    private static final SecureRandom RANDOM =
            new SecureRandom();

    private SeguridadContrasena() {
        // Evita crear objetos de esta clase.
    }

    /**
     * Genera un hash seguro para almacenar en MySQL.
     */
    public static String generarHash(char[] contrasena) {

        if (contrasena == null || contrasena.length == 0) {
            throw new IllegalArgumentException(
                    "La contraseña es obligatoria."
            );
        }

        byte[] sal = new byte[LONGITUD_SAL];
        RANDOM.nextBytes(sal);

        byte[] hash = derivarHash(
                contrasena, sal, ITERACIONES
        );

        return "pbkdf2_sha256$"
                + ITERACIONES + "$"
                + Base64.getEncoder().encodeToString(sal)
                + "$"
                + Base64.getEncoder().encodeToString(hash);
    }

    /**
     * Comprueba una contraseña contra el hash almacenado.
     */
    public static boolean verificar(
            char[] contrasena, String hashAlmacenado) {

        if (contrasena == null
                || hashAlmacenado == null
                || hashAlmacenado.isBlank()) {
            return false;
        }

        try {
            String[] partes = hashAlmacenado.split(
                    "\\$", -1
            );

            if (partes.length != 4
                    || !partes[0].equals("pbkdf2_sha256")) {
                return false;
            }

            int iteraciones = Integer.parseInt(partes[1]);

            // Limita el costo de hashes recibidos desde la BD.
            if (iteraciones < 100_000
                    || iteraciones > 2_000_000) {
                return false;
            }

            byte[] sal = Base64.getDecoder()
                    .decode(partes[2]);

            byte[] hashEsperado = Base64.getDecoder()
                    .decode(partes[3]);

            if (sal.length != LONGITUD_SAL
                    || hashEsperado.length
                            != LONGITUD_HASH / 8) {
                return false;
            }

            byte[] hashCalculado = derivarHash(
                    contrasena, sal, iteraciones
            );

            return MessageDigest.isEqual(
                    hashEsperado, hashCalculado
            );

        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static byte[] derivarHash(
            char[] contrasena,
            byte[] sal,
            int iteraciones) {

        PBEKeySpec especificacion = new PBEKeySpec(
                contrasena,
                sal,
                iteraciones,
                LONGITUD_HASH
        );

        try {
            SecretKeyFactory fabrica =
                    SecretKeyFactory.getInstance(ALGORITMO);

            return fabrica.generateSecret(especificacion)
                    .getEncoded();

        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(
                    "No fue posible procesar la contraseña.",
                    e
            );

        } finally {
            especificacion.clearPassword();
        }
    }
}
