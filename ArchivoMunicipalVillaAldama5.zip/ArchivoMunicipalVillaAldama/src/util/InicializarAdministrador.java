
package util;

import dao.UsuarioDAO;
import modelo.Usuario;

import javax.swing.*;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.util.Arrays;

public class InicializarAdministrador {

    public static void main(String[] args) {

        UsuarioDAO usuarioDAO = new UsuarioDAO();

        // Solo se permite inicializar cuando no hay usuarios.
        try {
            if (!usuarioDAO.listarTodos().isEmpty()) {
                JOptionPane.showMessageDialog(
                    null,
                    "La tabla usuarios ya contiene registros.\n"
                    + "No se creará otro administrador mediante "
                    + "esta herramienta.",
                    "Inicialización no permitida",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                null,
                "No fue posible consultar la base de datos.\n"
                + e.getMessage(),
                "Error de conexión",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        JTextField txtNombre = new JTextField();
        JTextField txtUsuario = new JTextField();
        JTextField txtCorreo = new JTextField();
        JPasswordField txtContrasena = new JPasswordField();
        JPasswordField txtConfirmacion = new JPasswordField();

        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));

        panel.add(new JLabel("Nombre completo:"));
        panel.add(txtNombre);

        panel.add(new JLabel("Nombre de usuario:"));
        panel.add(txtUsuario);

        panel.add(new JLabel("Correo electrónico (opcional):"));
        panel.add(txtCorreo);

        panel.add(new JLabel("Contraseña (mínimo 12 caracteres):"));
        panel.add(txtContrasena);

        panel.add(new JLabel("Confirmar contraseña:"));
        panel.add(txtConfirmacion);

        int resultado = JOptionPane.showConfirmDialog(
            null,
            panel,
            "Crear primer administrador",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (resultado != JOptionPane.OK_OPTION) {
            limpiarContrasenas(txtContrasena, txtConfirmacion);
            return;
        }

        char[] contrasena = txtContrasena.getPassword();
        char[] confirmacion = txtConfirmacion.getPassword();

        try {
            String nombre = txtNombre.getText().trim();
            String nombreUsuario = txtUsuario.getText().trim();
            String correo = txtCorreo.getText().trim();

            if (nombre.isEmpty() || nombreUsuario.isEmpty()) {
                JOptionPane.showMessageDialog(
                    null,
                    "El nombre y el nombre de usuario son obligatorios.",
                    "Datos incompletos",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            if (nombreUsuario.length() < 3) {
                JOptionPane.showMessageDialog(
                    null,
                    "El nombre de usuario debe tener al menos 3 caracteres.",
                    "Nombre de usuario inválido",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            if (contrasena.length < 12) {
                JOptionPane.showMessageDialog(
                    null,
                    "La contraseña debe tener al menos 12 caracteres.",
                    "Contraseña insuficiente",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            if (!Arrays.equals(contrasena, confirmacion)) {
                JOptionPane.showMessageDialog(
                    null,
                    "Las contraseñas no coinciden.",
                    "Error de confirmación",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            // Volver a comprobar antes de insertar.
            if (!usuarioDAO.listarTodos().isEmpty()) {
                JOptionPane.showMessageDialog(
                    null,
                    "Ya existe un usuario. No se insertó el administrador.",
                    "Inicialización cancelada",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            Usuario administrador = new Usuario();
            administrador.setNombre(nombre);
            administrador.setNombreUsuario(nombreUsuario);
            administrador.setCorreo(
                correo.isEmpty() ? null : correo
            );
            administrador.setRol("ADMINISTRADOR");
            administrador.setIdArea(null);
            administrador.setActivo(true);

            String hash =
                SeguridadContrasena.generarHash(contrasena);

            usuarioDAO.registrar(administrador, hash);

            JOptionPane.showMessageDialog(
                null,
                "El primer administrador se registró correctamente.\n\n"
                + "Usuario: " + nombreUsuario
                + "\nRol: ADMINISTRADOR"
                + "\n\nYa puedes probar el inicio de sesión.",
                "Inicialización completada",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                null,
                "No fue posible registrar al administrador.\n"
                + "Verifica la conexión y que el nombre de usuario "
                + "o correo no estén duplicados.\n\n"
                + e.getMessage(),
                "Error al registrar",
                JOptionPane.ERROR_MESSAGE
            );
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(
                null,
                "No se pudo generar la contraseña segura.\n"
                + e.getMessage(),
                "Error de contraseña",
                JOptionPane.ERROR_MESSAGE
            );
        } finally {
            Arrays.fill(contrasena, '\0');
            Arrays.fill(confirmacion, '\0');
            limpiarContrasenas(txtContrasena, txtConfirmacion);
        }
    }

    private static void limpiarContrasenas(
        JPasswordField campo1,
        JPasswordField campo2
    ) {
        campo1.setText("");
        campo2.setText("");
    }
}
