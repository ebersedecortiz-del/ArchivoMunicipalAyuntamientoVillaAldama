
module ArchivoMunicipalVillaAldama {
    requires java.sql;
    requires java.desktop;
}
