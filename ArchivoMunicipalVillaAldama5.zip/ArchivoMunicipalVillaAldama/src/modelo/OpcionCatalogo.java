
package modelo;

public class OpcionCatalogo {

    private long id;
    private String nombre;
    private String clave;

    public OpcionCatalogo(long id, String nombre) {
        this(id, nombre, null);
    }

    public OpcionCatalogo(
            long id,
            String nombre,
            String clave) {

        this.id = id;
        this.nombre = nombre;
        this.clave = clave;
    }

    public long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getClave() {
        return clave;
    }

    @Override
    public String toString() {

        if (clave != null && !clave.isBlank()) {
            return nombre + " (" + clave + ")";
        }

        return nombre;
    }
}
