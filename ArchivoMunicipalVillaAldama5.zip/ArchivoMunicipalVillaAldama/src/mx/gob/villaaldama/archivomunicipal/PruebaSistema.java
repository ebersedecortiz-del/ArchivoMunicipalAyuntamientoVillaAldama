package mx.gob.villaaldama.archivomunicipal;

public class PruebaSistema {

    public static void main(String[] args) {

        System.out.println("========================================");
        System.out.println(" ARCHIVO MUNICIPAL VILLA ALDAMA");
        System.out.println("========================================");
        System.out.println("Java detectado: "
                + System.getProperty("java.version"));
        System.out.println("Sistema operativo: "
                + System.getProperty("os.name"));
        System.out.println("Proyecto iniciado correctamente.");
        System.out.println("========================================");
    }
}
