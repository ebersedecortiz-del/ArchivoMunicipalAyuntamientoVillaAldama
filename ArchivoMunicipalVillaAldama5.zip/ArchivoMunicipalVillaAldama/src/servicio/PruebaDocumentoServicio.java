
package servicio;

import modelo.Documento;
import java.time.LocalDate;

public class PruebaDocumentoServicio {

    public static void main(String[] args) {

        DocumentoServicio servicio = new DocumentoServicio();

        System.out.println("PRUEBA DE VALIDACIONES");
        System.out.println("----------------------");

        // Prueba 1: documento sin folio
        Documento documento1 = new Documento();
        documento1.setNombre("Oficio de prueba");
        documento1.setIdCategoria(1);
        documento1.setIdTipo(1);
        documento1.setIdArea(1);
        documento1.setFechaEmision(LocalDate.now());

        probarDocumento(servicio, documento1, "Prueba 1");

        // Prueba 2: documento sin nombre
        Documento documento2 = new Documento();
        documento2.setFolioInterno("PRUEBA-002");
        documento2.setNombre(" ");
        documento2.setIdCategoria(1);
        documento2.setIdTipo(1);
        documento2.setIdArea(1);
        documento2.setFechaEmision(LocalDate.now());

        probarDocumento(servicio, documento2, "Prueba 2");

        // Prueba 3: documento sin fecha de emisión
        Documento documento3 = new Documento();
        documento3.setFolioInterno("PRUEBA-003");
        documento3.setNombre("Oficio de prueba");
        documento3.setIdCategoria(1);
        documento3.setIdTipo(1);
        documento3.setIdArea(1);

        probarDocumento(servicio, documento3, "Prueba 3");

        // Prueba 4: documento con datos básicos válidos
        Documento documento4 = new Documento();
        documento4.setFolioInterno("PRUEBA-004");
        documento4.setNombre("Documento de prueba");
        documento4.setIdCategoria(1);
        documento4.setIdTipo(1);
        documento4.setIdArea(1);
        documento4.setFechaEmision(LocalDate.now());

        probarDocumento(servicio, documento4, "Prueba 4");

        System.out.println("----------------------");
        System.out.println("FIN DE LAS PRUEBAS");
        System.out.println("No se insertaron datos en MySQL.");
    }

    private static void probarDocumento(
            DocumentoServicio servicio,
            Documento documento,
            String nombrePrueba) {

        try {
            // Solo ejecutamos las validaciones.
            // No llamamos a registrarDocumento().
            var metodo = DocumentoServicio.class
                    .getDeclaredMethod(
                            "validarDocumento",
                            Documento.class);

            metodo.setAccessible(true);
            metodo.invoke(servicio, documento);

            System.out.println(nombrePrueba + ": VALIDACION CORRECTA");

        } catch (java.lang.reflect.InvocationTargetException e) {
            System.out.println(
                    nombrePrueba + ": " + e.getCause().getMessage());

        } catch (Exception e) {
            System.out.println(
                    nombrePrueba + ": ERROR DE PRUEBA - "
                    + e.getMessage());
        }
    }
}
