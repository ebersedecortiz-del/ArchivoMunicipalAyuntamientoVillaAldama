
package servicio;

import dao.UsuarioDAO;
import modelo.Usuario;
import util.SeguridadContrasena;

import java.sql.SQLException;

public class AutenticacionServicio {

    private final UsuarioDAO usuarioDAO;

    public AutenticacionServicio() {
        this.usuarioDAO = new UsuarioDAO();
    }

    /**
     * Autentica a un usuario activo.
     *
     * Devuelve el usuario si las credenciales son correctas.
     * Devuelve null si las credenciales no son válidas.
     */
    public Usuario autenticar(
            String nombreUsuario,
            char[] contrasena) throws SQLException {

        if (contrasena == null || contrasena.length == 0) {
            return null;
        }

        try {
            if (nombreUsuario == null
                    || nombreUsuario.isBlank()) {
                return null;
            }

            String nombre = nombreUsuario.trim();

            Usuario usuario =
                    usuarioDAO.buscarPorNombreUsuario(nombre);

            if (usuario == null || !usuario.isActivo()) {
                return null;
            }

            String hash =
                    usuarioDAO.obtenerHashContrasena(nombre);

            if (hash == null || hash.isBlank()) {
                return null;
            }

            boolean credencialesValidas =
                    SeguridadContrasena.verificar(
                            contrasena, hash
                    );

            if (!credencialesValidas) {
                return null;
            }

            return usuario;

        } finally {
            java.util.Arrays.fill(contrasena, '\0');
        }
    }
}
