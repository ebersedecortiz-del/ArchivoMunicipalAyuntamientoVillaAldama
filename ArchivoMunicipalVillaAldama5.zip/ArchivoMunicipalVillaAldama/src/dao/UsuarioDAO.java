
package dao;

import conexion.ConexionBD;
import modelo.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    /**
     * Busca un usuario por su nombre de usuario.
     */
    public Usuario buscarPorNombreUsuario(String nombreUsuario)
            throws SQLException {

        String sql = """
            SELECT id_usuario, nombre, nombre_usuario,
                   correo, rol, id_area, activo
            FROM usuarios
            WHERE nombre_usuario = ?
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                 conexion.prepareStatement(sql)) {

            sentencia.setString(1, nombreUsuario);

            try (ResultSet resultado = sentencia.executeQuery()) {

                if (resultado.next()) {
                    return mapearUsuario(resultado);
                }
            }
        }

        return null;
    }

    /**
     * Recupera el hash para comprobar la contraseña.
     * Nunca recupera ni almacena la contraseña original.
     */
    public String obtenerHashContrasena(String nombreUsuario)
            throws SQLException {

        String sql = """
            SELECT hash_contrasena
            FROM usuarios
            WHERE nombre_usuario = ?
              AND activo = 1
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                 conexion.prepareStatement(sql)) {

            sentencia.setString(1, nombreUsuario);

            try (ResultSet resultado = sentencia.executeQuery()) {

                if (resultado.next()) {
                    return resultado.getString("hash_contrasena");
                }
            }
        }

        return null;
    }

    /**
     * Lista todos los usuarios sin recuperar sus hashes.
     */
    public List<Usuario> listarTodos() throws SQLException {

        List<Usuario> usuarios = new ArrayList<>();

        String sql = """
            SELECT id_usuario, nombre, nombre_usuario,
                   correo, rol, id_area, activo
            FROM usuarios
            ORDER BY nombre
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                 conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            while (resultado.next()) {
                usuarios.add(mapearUsuario(resultado));
            }
        }

        return usuarios;
    }

    /**
     * Registra un usuario con un hash de contraseña previamente
     * generado mediante el servicio de seguridad.
     *
     * Devuelve el identificador generado por MySQL.
     */
    public long registrar(Usuario usuario, String hashContrasena)
            throws SQLException {

        if (hashContrasena == null || hashContrasena.isBlank()) {
            throw new IllegalArgumentException(
                "La contraseña debe estar configurada."
            );
        }

        String sql = """
            INSERT INTO usuarios (
                nombre, nombre_usuario, correo,
                hash_contrasena, rol, id_area, activo
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                 conexion.prepareStatement(
                     sql, Statement.RETURN_GENERATED_KEYS
                 )) {

            sentencia.setString(1, usuario.getNombre());
            sentencia.setString(2, usuario.getNombreUsuario());

            if (usuario.getCorreo() != null
                    && !usuario.getCorreo().isBlank()) {
                sentencia.setString(3, usuario.getCorreo());
            } else {
                sentencia.setNull(3, Types.VARCHAR);
            }

            sentencia.setString(4, hashContrasena);
            sentencia.setString(5, usuario.getRol());

            if (usuario.getIdArea() != null) {
                sentencia.setLong(6, usuario.getIdArea());
            } else {
                sentencia.setNull(6, Types.BIGINT);
            }

            sentencia.setBoolean(7, usuario.isActivo());

            if (sentencia.executeUpdate() != 1) {
                throw new SQLException(
                    "No fue posible registrar el usuario."
                );
            }

            try (ResultSet claves = sentencia.getGeneratedKeys()) {
                if (claves.next()) {
                    return claves.getLong(1);
                }
            }

            throw new SQLException(
                "No se pudo recuperar el identificador del usuario."
            );
        }
    }

    /**
     * Modifica los datos generales y el rol de un usuario.
     * No modifica su contraseña.
     */
    public boolean actualizarDatos(Usuario usuario)
            throws SQLException {

        String sql = """
            UPDATE usuarios
            SET nombre = ?,
                nombre_usuario = ?,
                correo = ?,
                rol = ?,
                id_area = ?,
                activo = ?
            WHERE id_usuario = ?
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                 conexion.prepareStatement(sql)) {

            sentencia.setString(1, usuario.getNombre());
            sentencia.setString(2, usuario.getNombreUsuario());

            if (usuario.getCorreo() != null
                    && !usuario.getCorreo().isBlank()) {
                sentencia.setString(3, usuario.getCorreo());
            } else {
                sentencia.setNull(3, Types.VARCHAR);
            }

            sentencia.setString(4, usuario.getRol());

            if (usuario.getIdArea() != null) {
                sentencia.setLong(5, usuario.getIdArea());
            } else {
                sentencia.setNull(5, Types.BIGINT);
            }

            sentencia.setBoolean(6, usuario.isActivo());
            sentencia.setLong(7, usuario.getIdUsuario());

            return sentencia.executeUpdate() == 1;
        }
    }

    /**
     * Permite actualizar el hash de contraseña.
     * El hash debe generarse previamente en el servicio de seguridad.
     */
    public boolean actualizarHashContrasena(
            long idUsuario, String nuevoHash)
            throws SQLException {

        if (nuevoHash == null || nuevoHash.isBlank()) {
            throw new IllegalArgumentException(
                "El hash de contraseña no puede estar vacío."
            );
        }

        String sql = """
            UPDATE usuarios
            SET hash_contrasena = ?
            WHERE id_usuario = ?
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                 conexion.prepareStatement(sql)) {

            sentencia.setString(1, nuevoHash);
            sentencia.setLong(2, idUsuario);

            return sentencia.executeUpdate() == 1;
        }
    }

    /**
     * Desactiva una cuenta sin eliminar su historial.
     */
    public boolean desactivar(long idUsuario) throws SQLException {

        String sql = """
            UPDATE usuarios
            SET activo = 0
            WHERE id_usuario = ?
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                 conexion.prepareStatement(sql)) {

            sentencia.setLong(1, idUsuario);

            return sentencia.executeUpdate() == 1;
        }
    }

    /**
     * Convierte una fila de MySQL en un objeto Usuario.
     */
    private Usuario mapearUsuario(ResultSet resultado)
            throws SQLException {

        Usuario usuario = new Usuario();

        usuario.setIdUsuario(
            resultado.getLong("id_usuario")
        );

        usuario.setNombre(
            resultado.getString("nombre")
        );

        usuario.setNombreUsuario(
            resultado.getString("nombre_usuario")
        );

        usuario.setCorreo(
            resultado.getString("correo")
        );

        usuario.setRol(
            resultado.getString("rol")
        );

        long idArea = resultado.getLong("id_area");

        if (resultado.wasNull()) {
            usuario.setIdArea(null);
        } else {
            usuario.setIdArea(idArea);
        }

        usuario.setActivo(
            resultado.getBoolean("activo")
        );

        return usuario;
    }
}
