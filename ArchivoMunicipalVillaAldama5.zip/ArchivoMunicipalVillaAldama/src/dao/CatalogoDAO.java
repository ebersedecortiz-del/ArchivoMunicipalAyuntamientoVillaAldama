
package dao;

import conexion.ConexionBD;
import modelo.OpcionCatalogo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CatalogoDAO {

    public List<OpcionCatalogo> listarCategorias()
            throws SQLException {

        String sql = """
            SELECT id_categoria, nombre
            FROM categorias
            WHERE activa = 1
            ORDER BY nombre
            """;

        return consultarCatalogo(
            sql, "id_categoria", null
        );
    }

    public List<OpcionCatalogo> listarTiposDocumentales()
            throws SQLException {

        String sql = """
            SELECT id_tipo, nombre
            FROM tipos_documentales
            WHERE activo = 1
            ORDER BY nombre
            """;

        return consultarCatalogo(
            sql, "id_tipo", null
        );
    }

    public List<OpcionCatalogo> listarAreas()
            throws SQLException {

        String sql = """
            SELECT id_area, nombre, clave_auxiliar
            FROM areas
            WHERE activa = 1
            ORDER BY nombre
            """;

        return consultarCatalogo(
            sql, "id_area", "clave_auxiliar"
        );
    }

    private List<OpcionCatalogo> consultarCatalogo(
            String sql,
            String columnaId,
            String columnaClave) throws SQLException {

        List<OpcionCatalogo> opciones =
                new ArrayList<>();

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                     conexion.prepareStatement(sql);
             ResultSet resultado =
                     sentencia.executeQuery()) {

            while (resultado.next()) {

                long id =
                        resultado.getLong(columnaId);

                String nombre =
                        resultado.getString("nombre");

                String clave = null;

                if (columnaClave != null) {
                    clave = resultado.getString(
                        columnaClave
                    );
                }

                opciones.add(
                    new OpcionCatalogo(
                        id, nombre, clave
                    )
                );
            }
        }

        return opciones;
    }
}
