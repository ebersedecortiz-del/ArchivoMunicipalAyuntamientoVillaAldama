
package dao;

import conexion.ConexionBD;
import modelo.Documento;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DocumentoDAO {

    /**
     * Consulta todos los documentos registrados.
     */
    public List<Documento> listarTodos() throws SQLException {

        List<Documento> documentos = new ArrayList<>();

        String sql = """
            SELECT id_documento,
                   folio_interno,
                   nombre,
                   descripcion,
                   id_categoria,
                   id_tipo,
                   id_area,
                   id_expediente,
                   fecha_emision,
                   fecha_recepcion,
                   palabras_clave,
                   estado,
                   creado_por
            FROM documentos
            ORDER BY id_documento DESC
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                     conexion.prepareStatement(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            while (resultado.next()) {

                Documento documento = new Documento();

                documento.setIdDocumento(
                    resultado.getLong("id_documento")
                );

                documento.setFolioInterno(
                    resultado.getString("folio_interno")
                );

                documento.setNombre(
                    resultado.getString("nombre")
                );

                documento.setDescripcion(
                    resultado.getString("descripcion")
                );

                documento.setIdCategoria(
                    resultado.getLong("id_categoria")
                );

                documento.setIdTipo(
                    resultado.getLong("id_tipo")
                );

                documento.setIdArea(
                    resultado.getLong("id_area")
                );

                long idExpediente =
                    resultado.getLong("id_expediente");

                if (resultado.wasNull()) {
                    documento.setIdExpediente(null);
                } else {
                    documento.setIdExpediente(idExpediente);
                }

                Date fechaEmision =
                    resultado.getDate("fecha_emision");

                if (fechaEmision != null) {
                    documento.setFechaEmision(
                        fechaEmision.toLocalDate()
                    );
                }

                Date fechaRecepcion =
                    resultado.getDate("fecha_recepcion");

                if (fechaRecepcion != null) {
                    documento.setFechaRecepcion(
                        fechaRecepcion.toLocalDate()
                    );
                }

                documento.setPalabrasClave(
                    resultado.getString("palabras_clave")
                );

                documento.setEstado(
                    resultado.getString("estado")
                );

                long creadoPor =
                    resultado.getLong("creado_por");

                if (resultado.wasNull()) {
                    documento.setCreadoPor(null);
                } else {
                    documento.setCreadoPor(creadoPor);
                }

                documentos.add(documento);
            }
        }

        return documentos;
    }

    /**
     * Registra un documento y genera su folio automáticamente.
     *
     * El folio se genera dentro de una transacción MySQL.
     */
    public long registrar(Documento documento) throws SQLException {

        if (documento == null) {
            throw new IllegalArgumentException(
                "El documento no puede ser nulo."
            );
        }

        if (documento.getFechaEmision() == null) {
            throw new IllegalArgumentException(
                "La fecha de emisión es obligatoria."
            );
        }

        String sql = """
            INSERT INTO documentos (
                folio_interno,
                nombre,
                descripcion,
                id_categoria,
                id_tipo,
                id_area,
                id_expediente,
                fecha_emision,
                fecha_recepcion,
                palabras_clave,
                estado,
                creado_por
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection conexion = ConexionBD.conectar()) {

            conexion.setAutoCommit(false);

            try {

                // 1. Generar el folio automáticamente.
                String folio = generarFolio(
                    conexion,
                    documento.getIdArea(),
                    documento.getFechaEmision()
                );

                documento.setFolioInterno(folio);

                // 2. Preparar el registro.
                try (PreparedStatement sentencia =
                        conexion.prepareStatement(
                            sql,
                            Statement.RETURN_GENERATED_KEYS
                        )) {

                    sentencia.setString(
                        1, folio
                    );

                    sentencia.setString(
                        2, documento.getNombre()
                    );

                    sentencia.setString(
                        3, documento.getDescripcion()
                    );

                    sentencia.setLong(
                        4, documento.getIdCategoria()
                    );

                    sentencia.setLong(
                        5, documento.getIdTipo()
                    );

                    sentencia.setLong(
                        6, documento.getIdArea()
                    );

                    if (documento.getIdExpediente() != null) {
                        sentencia.setLong(
                            7, documento.getIdExpediente()
                        );
                    } else {
                        sentencia.setNull(7, Types.BIGINT);
                    }

                    sentencia.setDate(
                        8,
                        Date.valueOf(documento.getFechaEmision())
                    );

                    if (documento.getFechaRecepcion() != null) {
                        sentencia.setDate(
                            9,
                            Date.valueOf(
                                documento.getFechaRecepcion()
                            )
                        );
                    } else {
                        sentencia.setNull(9, Types.DATE);
                    }

                    sentencia.setString(
                        10, documento.getPalabrasClave()
                    );

                    String estado = documento.getEstado();

                    if (estado == null || estado.isBlank()) {
                        estado = "REGISTRADO";
                    }

                    sentencia.setString(11, estado);

                    if (documento.getCreadoPor() != null) {
                        sentencia.setLong(
                            12, documento.getCreadoPor()
                        );
                    } else {
                        sentencia.setNull(12, Types.BIGINT);
                    }

                    int filasInsertadas =
                        sentencia.executeUpdate();

                    if (filasInsertadas != 1) {
                        throw new SQLException(
                            "No fue posible registrar el documento."
                        );
                    }

                    // 3. Recuperar el identificador generado.
                    try (ResultSet claves =
                            sentencia.getGeneratedKeys()) {

                        if (claves.next()) {

                            long idDocumento =
                                claves.getLong(1);

                            // 4. Confirmar ambas operaciones.
                            conexion.commit();

                            return idDocumento;
                        }
                    }

                    throw new SQLException(
                        "No se pudo recuperar el identificador "
                        + "del documento."
                    );
                }

            } catch (SQLException | RuntimeException e) {

                conexion.rollback();
                throw e;
            }
        }
    }

    /**
     * Genera el folio interno por área y año.
     *
     * Ejemplo:
     * OBPU-2026-000501
     */
    private String generarFolio(
            Connection conexion,
            long idArea,
            java.time.LocalDate fechaEmision)
            throws SQLException {

        // 1. Obtener la clave auxiliar del área.
        String claveArea;

        String sqlArea = """
            SELECT clave_auxiliar
            FROM areas
            WHERE id_area = ?
              AND activa = 1
            """;

        try (PreparedStatement sentencia =
                conexion.prepareStatement(sqlArea)) {

            sentencia.setLong(1, idArea);

            try (ResultSet resultado =
                    sentencia.executeQuery()) {

                if (!resultado.next()) {
                    throw new SQLException(
                        "El área seleccionada no existe "
                        + "o está inactiva."
                    );
                }

                claveArea =
                    resultado.getString("clave_auxiliar");

                if (claveArea == null || claveArea.isBlank()) {
                    throw new SQLException(
                        "El área no tiene una clave auxiliar."
                    );
                }
            }
        }

        int anio = fechaEmision.getYear();

        // 2. Crear el consecutivo si todavía no existe.
        String sqlInsertar = """
            INSERT IGNORE INTO secuencias_folio
                (id_area, anio, ultimo_folio)
            VALUES (?, ?, 500)
            """;

        try (PreparedStatement sentencia =
                conexion.prepareStatement(sqlInsertar)) {

            sentencia.setLong(1, idArea);
            sentencia.setInt(2, anio);

            sentencia.executeUpdate();
        }

        // 3. Incrementar el consecutivo de forma segura.
        String sqlActualizar = """
            UPDATE secuencias_folio
            SET ultimo_folio =
                LAST_INSERT_ID(ultimo_folio + 1)
            WHERE id_area = ?
              AND anio = ?
            """;

        try (PreparedStatement sentencia =
                conexion.prepareStatement(sqlActualizar)) {

            sentencia.setLong(1, idArea);
            sentencia.setInt(2, anio);

            int filas = sentencia.executeUpdate();

            if (filas != 1) {
                throw new SQLException(
                    "No fue posible actualizar el consecutivo."
                );
            }
        }

        // 4. Recuperar el consecutivo generado.
        long consecutivo;

        String sqlConsecutivo = "SELECT LAST_INSERT_ID()";

        try (PreparedStatement sentencia =
                conexion.prepareStatement(sqlConsecutivo);
             ResultSet resultado = sentencia.executeQuery()) {

            if (!resultado.next()) {
                throw new SQLException(
                    "No se pudo recuperar el consecutivo."
                );
            }

            consecutivo = resultado.getLong(1);
        }

        // 5. Construir el folio definitivo.
        return claveArea.trim().toUpperCase(Locale.ROOT)
            + "-"
            + anio
            + "-"
            + String.format(
                Locale.ROOT,
                "%06d",
                consecutivo
            );
    }

    /**
     * Modifica un documento existente.
     *
     * El folio interno no se modifica.
     */
    public boolean actualizar(Documento documento)
            throws SQLException {

        String sql = """
            UPDATE documentos
            SET nombre = ?,
                descripcion = ?,
                id_categoria = ?,
                id_tipo = ?,
                id_area = ?,
                id_expediente = ?,
                fecha_emision = ?,
                fecha_recepcion = ?,
                palabras_clave = ?,
                estado = ?
            WHERE id_documento = ?
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement sentencia =
                     conexion.prepareStatement(sql)) {

            sentencia.setString(
                1, documento.getNombre()
            );

            sentencia.setString(
                2, documento.getDescripcion()
            );

            sentencia.setLong(
                3, documento.getIdCategoria()
            );

            sentencia.setLong(
                4, documento.getIdTipo()
            );

            sentencia.setLong(
                5, documento.getIdArea()
            );

            if (documento.getIdExpediente() != null) {
                sentencia.setLong(
                    6, documento.getIdExpediente()
                );
            } else {
                sentencia.setNull(6, Types.BIGINT);
            }

            if (documento.getFechaEmision() != null) {
                sentencia.setDate(
                    7,
                    Date.valueOf(documento.getFechaEmision())
                );
            } else {
                sentencia.setNull(7, Types.DATE);
            }

            if (documento.getFechaRecepcion() != null) {
                sentencia.setDate(
                    8,
                    Date.valueOf(documento.getFechaRecepcion())
                );
            } else {
                sentencia.setNull(8, Types.DATE);
            }

            sentencia.setString(
                9, documento.getPalabrasClave()
            );

            sentencia.setString(
                10, documento.getEstado()
            );

            sentencia.setLong(
                11, documento.getIdDocumento()
            );

            return sentencia.executeUpdate() == 1;
        }
    }
}
