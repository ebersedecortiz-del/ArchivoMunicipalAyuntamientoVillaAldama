
package conexion;

import java.sql.Connection;
import java.sql.SQLException;

public class PruebaConexion {

    public static void main(String[] args) {

        try (Connection conexion = ConexionBD.conectar()) {

            if (conexion != null && !conexion.isClosed()) {
                System.out.println("CONEXION EXITOSA");
                System.out.println(
                    "Java se conecto correctamente con MySQL."
                );
                System.out.println(
                    "Base de datos: " + conexion.getCatalog()
                );
            }

        } catch (SQLException e) {
            System.out.println("ERROR DE CONEXION");
            System.out.println("Mensaje: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
