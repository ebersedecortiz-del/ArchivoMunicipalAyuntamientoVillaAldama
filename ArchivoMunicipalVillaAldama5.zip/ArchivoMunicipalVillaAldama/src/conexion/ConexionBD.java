
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL =
            "jdbc:mysql://localhost:3306/archivo_municipal_villa_aldama";

    private static final String USUARIO = "root";
    private static final String CONTRASENA = "root";

    public static Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException(
                    "No se encontro el controlador JDBC de MySQL. "
                    + "Revisa el archivo mysql-connector-j en Modulepath.",
                    e
            );
        }

        return DriverManager.getConnection(URL, USUARIO, CONTRASENA);
    }
}
