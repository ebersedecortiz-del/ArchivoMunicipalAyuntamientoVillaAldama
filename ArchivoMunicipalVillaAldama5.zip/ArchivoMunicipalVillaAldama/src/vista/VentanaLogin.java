
package vista;

import modelo.Usuario;
import servicio.AutenticacionServicio;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.Arrays;

public class VentanaLogin extends JFrame {

    private final JTextField txtUsuario;
    private final JPasswordField txtContrasena;
    private final JButton btnIngresar;
    private final AutenticacionServicio autenticacion;

    public VentanaLogin() {

        autenticacion = new AutenticacionServicio();

        setTitle("Sistema de Archivo Municipal - Inicio de sesión");
        setSize(460, 340);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel principal = new JPanel(new BorderLayout(15, 15));
        principal.setBorder(BorderFactory.createEmptyBorder(
                25, 30, 25, 30
        ));

        JLabel titulo = new JLabel(
                "ARCHIVO MUNICIPAL",
                SwingConstants.CENTER
        );
        titulo.setFont(new Font("Serif", Font.BOLD, 23));

        JLabel subtitulo = new JLabel(
                "Sistema Integral de Gestión Documental",
                SwingConstants.CENTER
        );
        subtitulo.setFont(new Font("Serif", Font.PLAIN, 14));

        JPanel encabezado = new JPanel(new GridLayout(2, 1, 5, 5));
        encabezado.add(titulo);
        encabezado.add(subtitulo);

        JPanel formulario = new JPanel(new GridLayout(2, 2, 10, 15));

        JLabel lblUsuario = new JLabel("Nombre de usuario:");
        txtUsuario = new JTextField();

        JLabel lblContrasena = new JLabel("Contraseña:");
        txtContrasena = new JPasswordField();

        formulario.add(lblUsuario);
        formulario.add(txtUsuario);
        formulario.add(lblContrasena);
        formulario.add(txtContrasena);

        btnIngresar = new JButton("Iniciar sesión");
        btnIngresar.addActionListener(e -> iniciarSesion());

        txtContrasena.addActionListener(e -> iniciarSesion());

        JPanel pie = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pie.add(btnIngresar);

        principal.add(encabezado, BorderLayout.NORTH);
        principal.add(formulario, BorderLayout.CENTER);
        principal.add(pie, BorderLayout.SOUTH);

        add(principal);

        getRootPane().setDefaultButton(btnIngresar);
    }

    private void iniciarSesion() {

        String nombreUsuario = txtUsuario.getText().trim();
        char[] contrasena = txtContrasena.getPassword();

        if (nombreUsuario.isEmpty() || contrasena.length == 0) {
            Arrays.fill(contrasena, '\0');

            JOptionPane.showMessageDialog(
                    this,
                    "Escribe tu nombre de usuario y contraseña.",
                    "Datos obligatorios",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        btnIngresar.setEnabled(false);

        try {
            Usuario usuario = autenticacion.autenticar(
                    nombreUsuario,
                    contrasena
            );

            if (usuario == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Usuario o contraseña incorrectos, "
                                + "o cuenta inactiva.",
                        "Acceso denegado",
                        JOptionPane.ERROR_MESSAGE
                );

                txtContrasena.setText("");
                txtContrasena.requestFocusInWindow();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Inicio de sesión correcto.\n"
                                + "Bienvenido: " + usuario.getNombre()
                                + "\nRol: " + usuario.getRol(),
                        "Acceso autorizado",
                        JOptionPane.INFORMATION_MESSAGE
                );

                
              VentanaPrincipal principal =
                        new VentanaPrincipal(usuario);

                principal.setVisible(true);
                dispose();
                return;
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible consultar la base de datos.\n"
                            + "Verifica la conexión MySQL.",
                    "Error de conexión",
                    JOptionPane.ERROR_MESSAGE
            );

            ex.printStackTrace();

        } finally {
            Arrays.fill(contrasena, '\0');
            btnIngresar.setEnabled(true);
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            VentanaLogin ventana = new VentanaLogin();
            ventana.setVisible(true);
        });
    }
}
