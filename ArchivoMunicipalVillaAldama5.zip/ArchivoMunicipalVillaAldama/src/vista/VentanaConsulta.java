
package vista;

import modelo.Documento;
import modelo.Usuario;
import servicio.DocumentoServicio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;

import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class VentanaConsulta extends JFrame {

    private final Usuario usuario;
    private final DocumentoServicio documentoServicio =
            new DocumentoServicio();

    private JTable tablaDocumentos;
    private DefaultTableModel modeloTabla;
    private TableRowSorter<DefaultTableModel> ordenador;

    private JTextField txtBuscar;
    private JLabel lblTotal;

    public VentanaConsulta(Usuario usuario) {

        if (usuario == null || !usuario.isActivo()
                || !"CONSULTA".equalsIgnoreCase(usuario.getRol())) {

            throw new SecurityException(
                    "No tienes autorización para consultar documentos."
            );
        }

        this.usuario = usuario;

        setTitle("Consulta de documentos - Archivo Municipal");
        setSize(1100, 600);
        setMinimumSize(new Dimension(850, 450));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        construirInterfaz();
        cargarDocumentos();
    }

    private void construirInterfaz() {

        JPanel principal = new JPanel(new BorderLayout(12, 12));

        principal.setBorder(
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        // ENCABEZADO

        JLabel titulo = new JLabel(
                "CONSULTA DE DOCUMENTOS",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Serif", Font.BOLD, 23));

        JLabel subtitulo = new JLabel(
                "Archivo Municipal de Villa Aldama",
                SwingConstants.CENTER
        );

        subtitulo.setFont(new Font("Serif", Font.PLAIN, 16));

        JPanel encabezado = new JPanel(new GridLayout(2, 1, 5, 5));

        encabezado.add(titulo);
        encabezado.add(subtitulo);

        // INFORMACIÓN DEL USUARIO

        JLabel lblUsuario = new JLabel(
                "Usuario: " + usuario.getNombre()
                + "    |    Rol: CONSULTA"
        );

        // BUSCADOR

        txtBuscar = new JTextField(25);

        JButton btnBuscar = new JButton("Buscar");
        JButton btnActualizar = new JButton("Actualizar lista");

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));

        panelBusqueda.add(new JLabel("Buscar documento:"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnActualizar);

        JPanel panelSuperior = new JPanel(new BorderLayout(5, 8));

        panelSuperior.add(encabezado, BorderLayout.NORTH);
        panelSuperior.add(lblUsuario, BorderLayout.CENTER);
        panelSuperior.add(panelBusqueda, BorderLayout.SOUTH);

        // TABLA DE DOCUMENTOS

        String[] columnas = {
            "Folio interno",
            "Nombre",
            "Descripción",
            "ID categoría",
            "ID tipo",
            "ID área",
            "Fecha emisión",
            "Fecha recepción",
            "Palabras clave",
            "Estado"
        };

        modeloTabla = new DefaultTableModel(columnas, 0) {

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tablaDocumentos = new JTable(modeloTabla);

        tablaDocumentos.setRowHeight(25);
        tablaDocumentos.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tablaDocumentos.setAutoResizeMode(
                JTable.AUTO_RESIZE_OFF
        );

        ordenador = new TableRowSorter<>(modeloTabla);

        tablaDocumentos.setRowSorter(ordenador);

        JScrollPane desplazamiento =
                new JScrollPane(tablaDocumentos);

        // PIE DE VENTANA

        lblTotal = new JLabel("Documentos encontrados: 0");

        JButton btnCerrar = new JButton("Cerrar");

        JPanel pie = new JPanel(new BorderLayout());

        pie.add(lblTotal, BorderLayout.WEST);

        JPanel botonesPie = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
        );

        botonesPie.add(btnCerrar);

        pie.add(botonesPie, BorderLayout.EAST);

        // EVENTOS

        btnBuscar.addActionListener(e -> buscarDocumentos());

        txtBuscar.addActionListener(e -> buscarDocumentos());

        btnActualizar.addActionListener(e -> cargarDocumentos());

        btnCerrar.addActionListener(e -> dispose());

        // INTEGRACIÓN

        principal.add(panelSuperior, BorderLayout.NORTH);
        principal.add(desplazamiento, BorderLayout.CENTER);
        principal.add(pie, BorderLayout.SOUTH);

        setContentPane(principal);
    }

    private void cargarDocumentos() {

        try {

            List<Documento> documentos =
                    documentoServicio.listarDocumentos();

            modeloTabla.setRowCount(0);

            for (Documento documento : documentos) {

                Object[] fila = {

                    documento.getFolioInterno(),

                    documento.getNombre(),

                    documento.getDescripcion(),

                    documento.getIdCategoria(),

                    documento.getIdTipo(),

                    documento.getIdArea(),

                    convertirFecha(documento.getFechaEmision()),

                    convertirFecha(documento.getFechaRecepcion()),

                    documento.getPalabrasClave(),

                    documento.getEstado()
                };

                modeloTabla.addRow(fila);
            }

            ordenador.setRowFilter(null);

            txtBuscar.setText("");

            lblTotal.setText(
                    "Documentos encontrados: "
                    + modeloTabla.getRowCount()
            );

            if (documentos.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Actualmente no existen documentos registrados.",
                        "Consulta documental",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible consultar los documentos.\n"
                    + ex.getMessage(),
                    "Error de consulta",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void buscarDocumentos() {

        String texto = txtBuscar.getText().trim();

        if (texto.isEmpty()) {

            ordenador.setRowFilter(null);

        } else {

            ordenador.setRowFilter(
                    RowFilter.regexFilter(
                            "(?i)" + java.util.regex.Pattern.quote(texto)
                    )
            );
        }

        lblTotal.setText(
                "Documentos encontrados: "
                + tablaDocumentos.getRowCount()
        );
    }

    private String convertirFecha(LocalDate fecha) {

        if (fecha == null) {
            return "";
        }

        return fecha.toString();
    }
}
