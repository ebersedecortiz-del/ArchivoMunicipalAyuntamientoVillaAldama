
package vista;

import modelo.Usuario;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    private final Usuario usuario;

    public VentanaPrincipal(Usuario usuario) {

        if (usuario == null || !usuario.isActivo()) {
            throw new IllegalArgumentException(
                    "Se requiere un usuario autenticado y activo."
            );
        }

        this.usuario = usuario;

        setTitle("Archivo Municipal de Villa Aldama");
        setSize(760, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(650, 420));

        construirInterfaz();
    }

    private void construirInterfaz() {

        JPanel principal = new JPanel(new BorderLayout(15, 15));

        principal.setBorder(
                BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JLabel titulo = new JLabel(
                "SISTEMA INTEGRAL DE GESTIÓN DOCUMENTAL",
                SwingConstants.CENTER
        );

        titulo.setFont(new Font("Serif", Font.BOLD, 21));

        JLabel subtitulo = new JLabel(
                "Archivo Municipal de Villa Aldama",
                SwingConstants.CENTER
        );

        subtitulo.setFont(new Font("Serif", Font.PLAIN, 16));

        JPanel encabezado = new JPanel(new GridLayout(2, 1, 5, 5));

        encabezado.add(titulo);
        encabezado.add(subtitulo);

        // INFORMACIÓN DEL USUARIO

        JPanel informacion = new JPanel(new GridLayout(3, 1, 5, 5));

        informacion.add(new JLabel(
                "Usuario: " + usuario.getNombre()
        ));

        informacion.add(new JLabel(
                "Nombre de acceso: " + usuario.getNombreUsuario()
        ));

        informacion.add(new JLabel(
                "Rol: " + usuario.getRol()
        ));

        // IDENTIFICAR ROL

        JPanel botones = new JPanel(new GridLayout(0, 2, 15, 15));

        String rol = usuario.getRol() == null
                ? ""
                : usuario.getRol().trim().toUpperCase();

        // ADMINISTRADOR Y ARCHIVISTA

        if (rol.equals("ADMINISTRADOR")
                || rol.equals("ARCHIVISTA")) {

            JButton btnDocumentos = new JButton(
                    "Gestión de documentos"
            );

            btnDocumentos.addActionListener(
                    e -> abrirDocumentos()
            );

            botones.add(btnDocumentos);
        }

        // USUARIO CONSULTA

        if (rol.equals("CONSULTA")) {

            JButton btnConsulta = new JButton(
                    "Consulta de documentos"
            );

            btnConsulta.setEnabled(true);

            btnConsulta.setToolTipText(
                    "Consultar documentos en modo de solo lectura."
            );

            btnConsulta.addActionListener(
                    e -> abrirConsulta()
            );

            botones.add(btnConsulta);
        }

        // ADMINISTRACIÓN DE USUARIOS

        if (rol.equals("ADMINISTRADOR")) {

            JButton btnUsuarios = new JButton(
                    "Administrar usuarios"
            );

            btnUsuarios.addActionListener(e -> {

                try {

                    VentanaUsuarios ventanaUsuarios =
                            new VentanaUsuarios(usuario);

                    ventanaUsuarios.setLocationRelativeTo(this);
                    ventanaUsuarios.setVisible(true);

                } catch (SecurityException ex) {

                    JOptionPane.showMessageDialog(
                            this,
                            "No tienes permisos para administrar usuarios.",
                            "Acceso denegado",
                            JOptionPane.WARNING_MESSAGE
                    );

                } catch (RuntimeException ex) {

                    JOptionPane.showMessageDialog(
                            this,
                            "No fue posible abrir la administración "
                            + "de usuarios.\nDetalle: " + ex.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            });

            botones.add(btnUsuarios);
        }

        // CERRAR SESIÓN

        JButton btnCerrarSesion = new JButton("Cerrar sesión");

        btnCerrarSesion.addActionListener(
                e -> cerrarSesion()
        );

        JPanel pie = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
        );

        pie.add(btnCerrarSesion);

        // DISTRIBUCIÓN

        JPanel zonaCentral = new JPanel(
                new BorderLayout(10, 20)
        );

        zonaCentral.add(informacion, BorderLayout.NORTH);
        zonaCentral.add(botones, BorderLayout.CENTER);

        principal.add(encabezado, BorderLayout.NORTH);
        principal.add(zonaCentral, BorderLayout.CENTER);
        principal.add(pie, BorderLayout.SOUTH);

        setContentPane(principal);
    }

    // ABRIR GESTIÓN DOCUMENTAL

    private void abrirDocumentos() {

        if (!"ADMINISTRADOR".equalsIgnoreCase(usuario.getRol())
                && !"ARCHIVISTA".equalsIgnoreCase(usuario.getRol())) {

            JOptionPane.showMessageDialog(
                    this,
                    "No tienes autorización para gestionar documentos.",
                    "Acceso denegado",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        try {

            VentanaDocumentos ventana = new VentanaDocumentos();

            ventana.setLocationRelativeTo(this);
            ventana.setVisible(true);

        } catch (RuntimeException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible abrir la gestión de documentos.\n"
                    + "Detalle: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ABRIR CONSULTA DOCUMENTAL

    private void abrirConsulta() {

        if (!"CONSULTA".equalsIgnoreCase(usuario.getRol())) {

            JOptionPane.showMessageDialog(
                    this,
                    "No tienes autorización para consultar documentos.",
                    "Acceso denegado",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        try {

            VentanaConsulta ventana =
                    new VentanaConsulta(usuario);

            ventana.setLocationRelativeTo(this);
            ventana.setVisible(true);

        } catch (SecurityException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Acceso denegado: " + ex.getMessage(),
                    "Permisos",
                    JOptionPane.WARNING_MESSAGE
            );

        } catch (RuntimeException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "No fue posible abrir la consulta documental.\n"
                    + "Detalle: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // CERRAR SESIÓN

    private void cerrarSesion() {

        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Deseas cerrar la sesión actual?",
                "Cerrar sesión",
                JOptionPane.YES_NO_OPTION
        );

        if (respuesta == JOptionPane.YES_OPTION) {

            VentanaLogin login = new VentanaLogin();

            login.setVisible(true);

            dispose();
        }
    }
}
