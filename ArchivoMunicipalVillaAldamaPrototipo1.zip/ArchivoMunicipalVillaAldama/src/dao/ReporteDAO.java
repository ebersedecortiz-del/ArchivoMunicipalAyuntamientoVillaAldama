
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import conexion.ConexionBD;
import modelo.ReporteActividad;

public class ReporteDAO {

    /**
     * Consulta las actividades registradas en la bitácora.
     *
     * Permite filtrar por:
     * - Fecha inicial.
     * - Fecha final.
     * - Usuario.
     *
     * Los parámetros pueden ser null cuando no se desea
     * aplicar ese filtro.
     */
    public List<ReporteActividad> listarActividades(
            LocalDateTime fechaInicio,
            LocalDateTime fechaFin,
            Long idUsuario) throws SQLException {

        List<ReporteActividad> actividades = new ArrayList<>();

        StringBuilder sql = new StringBuilder("""
            SELECT
                b.id_evento,
                b.id_usuario,
                u.nombre AS nombre_usuario,
                u.nombre_usuario AS nombre_cuenta,
                u.rol,
                b.entidad,
                b.id_registro,
                b.accion,
                b.detalle,
                b.fecha_evento
            FROM bitacora b
            LEFT JOIN usuarios u
                ON b.id_usuario = u.id_usuario
            WHERE 1 = 1
            """);

        if (fechaInicio != null) {
            sql.append(" AND b.fecha_evento >= ?");
        }

        if (fechaFin != null) {
            sql.append(" AND b.fecha_evento <= ?");
        }

        if (idUsuario != null) {
            sql.append(" AND b.id_usuario = ?");
        }

        sql.append(" ORDER BY b.fecha_evento DESC");

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(
                 sql.toString())) {

            int parametro = 1;

            if (fechaInicio != null) {
                ps.setTimestamp(
                    parametro++,
                    Timestamp.valueOf(fechaInicio)
                );
            }

            if (fechaFin != null) {
                ps.setTimestamp(
                    parametro++,
                    Timestamp.valueOf(fechaFin)
                );
            }

            if (idUsuario != null) {
                ps.setLong(parametro++, idUsuario);
            }

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    ReporteActividad actividad =
                        new ReporteActividad();

                    actividad.setIdEvento(
                        rs.getLong("id_evento")
                    );

                    long idUsuarioResultado =
                        rs.getLong("id_usuario");

                    if (rs.wasNull()) {
                        actividad.setIdUsuario(null);
                    } else {
                        actividad.setIdUsuario(
                            idUsuarioResultado
                        );
                    }

                    actividad.setNombreUsuario(
                        rs.getString("nombre_usuario")
                    );

                    actividad.setNombreCuenta(
                        rs.getString("nombre_cuenta")
                    );

                    actividad.setRol(
                        rs.getString("rol")
                    );

                    actividad.setEntidad(
                        rs.getString("entidad")
                    );

                    long idRegistroResultado =
                        rs.getLong("id_registro");

                    if (rs.wasNull()) {
                        actividad.setIdRegistro(null);
                    } else {
                        actividad.setIdRegistro(
                            idRegistroResultado
                        );
                    }

                    actividad.setAccion(
                        rs.getString("accion")
                    );

                    actividad.setDetalle(
                        rs.getString("detalle")
                    );

                    Timestamp fecha =
                        rs.getTimestamp("fecha_evento");

                    if (fecha != null) {
                        actividad.setFechaEvento(
                            fecha.toLocalDateTime()
                        );
                    }

                    actividades.add(actividad);
                }
            }
        }

        return actividades;
    }
}
