
package dao;

import conexion.ConexionBD;
import modelo.ArchivoDigital;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class ArchivoDigitalDAO {

    /*
     * Registra los datos de un PDF utilizando
     * una conexión existente.
     *
     * La transacción será controlada por la clase
     * que registre el documento y guarde el PDF.
     */
    public long registrar(Connection conexion, ArchivoDigital archivo)
            throws SQLException {

        String sql = """
                INSERT INTO archivos_digitales (
                    id_documento,
                    nombre_original,
                    nombre_almacenado,
                    ruta_relativa,
                    tipo_mime,
                    tamano_bytes,
                    sha256,
                    cargado_por
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (PreparedStatement ps = conexion.prepareStatement(
                sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setLong(1, archivo.getIdDocumento());
            ps.setString(2, archivo.getNombreOriginal());
            ps.setString(3, archivo.getNombreAlmacenado());
            ps.setString(4, archivo.getRutaRelativa());

            String tipoMime = archivo.getTipoMime();

            if (tipoMime == null || tipoMime.isBlank()) {
                tipoMime = "application/pdf";
            }

            ps.setString(5, tipoMime);
            ps.setLong(6, archivo.getTamanoBytes());

            if (archivo.getSha256() != null) {
                ps.setString(7, archivo.getSha256());
            } else {
                ps.setNull(7, Types.CHAR);
            }

            if (archivo.getCargadoPor() != null) {
                ps.setLong(8, archivo.getCargadoPor());
            } else {
                ps.setNull(8, Types.BIGINT);
            }

            int filas = ps.executeUpdate();

            if (filas == 0) {
                throw new SQLException(
                        "No se pudo registrar el archivo digital.");
            }

            try (ResultSet rs = ps.getGeneratedKeys()) {

                if (rs.next()) {
                    long idGenerado = rs.getLong(1);
                    archivo.setIdArchivo(idGenerado);
                    return idGenerado;
                }
            }
        }

        throw new SQLException(
                "No se pudo obtener el identificador del archivo digital.");
    }

    /*
     * Consulta todos los archivos digitales
     * asociados a un documento.
     */
    public List<ArchivoDigital> listarPorDocumento(long idDocumento)
            throws SQLException {

        List<ArchivoDigital> archivos = new ArrayList<>();

        String sql = """
                SELECT
                    id_archivo,
                    id_documento,
                    nombre_original,
                    nombre_almacenado,
                    ruta_relativa,
                    tipo_mime,
                    tamano_bytes,
                    sha256,
                    fecha_carga,
                    cargado_por
                FROM archivos_digitales
                WHERE id_documento = ?
                ORDER BY fecha_carga DESC
                """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setLong(1, idDocumento);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    archivos.add(mapearArchivo(rs));
                }
            }
        }

        return archivos;
    }

    /*
     * Busca un archivo digital por su identificador.
     */
    public ArchivoDigital buscarPorId(long idArchivo)
            throws SQLException {

        String sql = """
                SELECT
                    id_archivo,
                    id_documento,
                    nombre_original,
                    nombre_almacenado,
                    ruta_relativa,
                    tipo_mime,
                    tamano_bytes,
                    sha256,
                    fecha_carga,
                    cargado_por
                FROM archivos_digitales
                WHERE id_archivo = ?
                """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setLong(1, idArchivo);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapearArchivo(rs);
                }
            }
        }

        return null;
    }

    /*
     * Convierte una fila de MySQL en un objeto ArchivoDigital.
     */
    private ArchivoDigital mapearArchivo(ResultSet rs)
            throws SQLException {

        ArchivoDigital archivo = new ArchivoDigital();

        archivo.setIdArchivo(rs.getLong("id_archivo"));
        archivo.setIdDocumento(rs.getLong("id_documento"));

        archivo.setNombreOriginal(
                rs.getString("nombre_original"));

        archivo.setNombreAlmacenado(
                rs.getString("nombre_almacenado"));

        archivo.setRutaRelativa(
                rs.getString("ruta_relativa"));

        archivo.setTipoMime(
                rs.getString("tipo_mime"));

        archivo.setTamanoBytes(
                rs.getLong("tamano_bytes"));

        archivo.setSha256(
                rs.getString("sha256"));

        archivo.setFechaCarga(
                rs.getTimestamp("fecha_carga"));

        long cargadoPor = rs.getLong("cargado_por");

        if (rs.wasNull()) {
            archivo.setCargadoPor(null);
        } else {
            archivo.setCargadoPor(cargadoPor);
        }

        return archivo;
    }
}
