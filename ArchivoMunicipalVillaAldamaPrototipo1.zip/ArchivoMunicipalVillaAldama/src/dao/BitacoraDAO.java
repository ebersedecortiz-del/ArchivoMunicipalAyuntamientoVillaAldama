
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import conexion.ConexionBD;
import modelo.Actividad;

public class BitacoraDAO {

    /**
     * Registra una actividad en la tabla bitacora.
     *
     * La fecha y hora se generan automáticamente en MySQL.
     *
     * @param actividad Datos del evento.
     * @return Identificador del evento registrado.
     */
    public long registrar(Actividad actividad) throws SQLException {

        if (actividad == null) {
            throw new IllegalArgumentException(
                "La actividad no puede ser nula."
            );
        }

        if (actividad.getEntidad() == null
                || actividad.getEntidad().isBlank()) {
            throw new IllegalArgumentException(
                "La entidad del evento es obligatoria."
            );
        }

        if (actividad.getAccion() == null
                || actividad.getAccion().isBlank()) {
            throw new IllegalArgumentException(
                "La acción del evento es obligatoria."
            );
        }

        String sql = """
            INSERT INTO bitacora
            (id_usuario, entidad, id_registro, accion, detalle)
            VALUES (?, ?, ?, ?, ?)
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(
                 sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            if (actividad.getIdUsuario() != null) {
                ps.setLong(1, actividad.getIdUsuario());
            } else {
                ps.setNull(1, java.sql.Types.BIGINT);
            }

            ps.setString(2, actividad.getEntidad());

            if (actividad.getIdRegistro() != null) {
                ps.setLong(3, actividad.getIdRegistro());
            } else {
                ps.setNull(3, java.sql.Types.BIGINT);
            }

            ps.setString(4, actividad.getAccion());
            ps.setString(5, actividad.getDetalle());

            int filas = ps.executeUpdate();

            if (filas == 0) {
                throw new SQLException(
                    "No se pudo registrar la actividad."
                );
            }

            try (ResultSet rs = ps.getGeneratedKeys()) {

                if (rs.next()) {
                    long idGenerado = rs.getLong(1);

                    actividad.setIdEvento(idGenerado);

                    // Recuperar la fecha y hora asignadas por MySQL.
                    String sqlFecha = """
                        SELECT fecha_evento
                        FROM bitacora
                        WHERE id_evento = ?
                        """;

                    try (PreparedStatement psFecha =
                             conexion.prepareStatement(sqlFecha)) {

                        psFecha.setLong(1, idGenerado);

                        try (ResultSet rsFecha = psFecha.executeQuery()) {
                            if (rsFecha.next()) {
                                Timestamp fecha = rsFecha.getTimestamp(
                                    "fecha_evento"
                                );

                                if (fecha != null) {
                                    actividad.setFechaEvento(
                                        fecha.toLocalDateTime()
                                    );
                                }
                            }
                        }
                    }

                    return idGenerado;
                }
            }
        }

        throw new SQLException(
            "No fue posible recuperar el identificador del evento."
        );
    }
}
