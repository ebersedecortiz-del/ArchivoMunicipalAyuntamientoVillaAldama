
package util;

import servicio.ActividadServicio;

public class PruebaBitacora {

    public static void main(String[] args) {

        ActividadServicio servicio = new ActividadServicio();

        try {

            long idEvento = servicio.registrarActividad(
                null,
                "PRUEBA_TECNICA",
                null,
                "VERIFICAR_REGISTRO",
                "Prueba de funcionamiento del modulo de bitacora."
            );

            System.out.println("--------------------------------");
            System.out.println("PRUEBA DE BITACORA EXITOSA");
            System.out.println("Identificador del evento: " + idEvento);
            System.out.println("--------------------------------");

        } catch (Exception e) {

            System.out.println("ERROR AL REGISTRAR LA ACTIVIDAD:");
            e.printStackTrace();

        }
    }
}
