
package util;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import modelo.Usuario;
import vista.VentanaReportes;

public class PruebaVentanaReportes {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            Usuario administrador = new Usuario();

            administrador.setIdUsuario(1);
            administrador.setNombre("Administrador de prueba");
            administrador.setNombreUsuario("admin_prueba");
            administrador.setRol("ADMINISTRADOR");
            administrador.setActivo(true);

            JFrame ventana = new JFrame(
                "Prueba - Centro de Reportes"
            );

            ventana.setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
            );

            ventana.setContentPane(
                new VentanaReportes(administrador)
            );

            ventana.setSize(1200, 750);
            ventana.setLocationRelativeTo(null);
            ventana.setVisible(true);
        });
    }
}
