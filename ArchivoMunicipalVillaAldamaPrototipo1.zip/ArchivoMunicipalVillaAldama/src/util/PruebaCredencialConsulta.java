
package util;

import dao.UsuarioDAO;
import modelo.Usuario;

import javax.swing.*;
import java.sql.SQLException;
import java.util.Arrays;

public class PruebaCredencialConsulta {

    public static void main(String[] args) {

        char[] contrasena = null;

        try {
            UsuarioDAO usuarioDAO = new UsuarioDAO();

            String nombreUsuario = "VictorOrtiz";

            Usuario usuario =
                    usuarioDAO.buscarPorNombreUsuario(nombreUsuario);

            if (usuario == null) {
                System.out.println("Usuario encontrado: false");
                return;
            }

            System.out.println("Usuario encontrado: true");
            System.out.println("Cuenta activa: " + usuario.isActivo());
            System.out.println("Rol: " + usuario.getRol());

            String hash =
                    usuarioDAO.obtenerHashContrasena(nombreUsuario);

            if (hash == null || hash.isBlank()) {
                System.out.println("Hash disponible: false");
                return;
            }

            System.out.println("Hash disponible: true");

            JPasswordField campo = new JPasswordField();

            int opcion = JOptionPane.showConfirmDialog(
                    null,
                    campo,
                    "Escribe la contraseña de VictorOrtiz",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (opcion != JOptionPane.OK_OPTION) {
                System.out.println("Prueba cancelada.");
                return;
            }

            contrasena = campo.getPassword();

            boolean coincide =
                    SeguridadContrasena.verificar(contrasena, hash);

            System.out.println(
                    "Contraseña coincide: " + coincide
            );

        } catch (SQLException ex) {

            System.out.println("Error al consultar MySQL.");
            ex.printStackTrace();

        } finally {

            if (contrasena != null) {
                Arrays.fill(contrasena, '\0');
            }
        }
    }
}
