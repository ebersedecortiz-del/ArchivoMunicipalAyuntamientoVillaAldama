
package util;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

import modelo.ReporteActividad;
import modelo.Usuario;

public class GeneradorReportePDF_Respaldo {

    private final PDFont fuenteNormal =
        new PDType1Font(Standard14Fonts.FontName.HELVETICA);

    private final PDFont fuenteNegrita =
        new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);

    private final PDFont fuenteTitulo =
        new PDType1Font(Standard14Fonts.FontName.TIMES_BOLD);

    private final DateTimeFormatter formatoFecha =
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    private final DateTimeFormatter formatoGeneracion =
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    private static final float MARGEN = 40;
    private static final float TAMANO_TEXTO = 9;
    private static final float ESPACIO_LINEA = 12;

    public void generarReporteActividades(
            List<ReporteActividad> actividades,
            String periodo,
            Usuario administrador,
            File destino) throws IOException {

        if (actividades == null) {
            throw new IllegalArgumentException(
                "La lista de actividades no puede ser nula."
            );
        }

        if (administrador == null) {
            throw new IllegalArgumentException(
                "No se identificó al administrador que genera el reporte."
            );
        }

        if (destino == null) {
            throw new IllegalArgumentException(
                "No se especificó el archivo de destino."
            );
        }

        try (PDDocument documento = new PDDocument()) {

            PDRectangle tamanoPagina = new PDRectangle(
                PDRectangle.A4.getHeight(),
                PDRectangle.A4.getWidth()
            );

            PDPage pagina = new PDPage(tamanoPagina);

            documento.addPage(pagina);

            PDPageContentStream contenido =
                new PDPageContentStream(documento, pagina);

            float anchoPagina = tamanoPagina.getWidth();
            float altoPagina = tamanoPagina.getHeight();

            float y = crearEncabezado(
                contenido,
                anchoPagina,
                altoPagina,
                actividades.size(),
                periodo,
                administrador
            );

            for (ReporteActividad actividad : actividades) {

                List<String> lineasDetalle = dividirTexto(
                    obtenerTexto(actividad.getDetalle()),
                    fuenteNormal,
                    TAMANO_TEXTO,
                    anchoPagina - (MARGEN * 2) - 15
                );

                float alturaBloque =
                    53 + (lineasDetalle.size() * ESPACIO_LINEA);

                if (y - alturaBloque < 45) {

                    contenido.close();

                    pagina = new PDPage(tamanoPagina);
                    documento.addPage(pagina);

                    contenido = new PDPageContentStream(
                        documento,
                        pagina
                    );

                    y = crearEncabezado(
                        contenido,
                        anchoPagina,
                        altoPagina,
                        actividades.size(),
                        periodo,
                        administrador
                    );
                }

                y = escribirActividad(
                    contenido,
                    actividad,
                    lineasDetalle,
                    y,
                    anchoPagina
                );
            }

            contenido.close();

            documento.save(destino);
        }
    }

    private float crearEncabezado(
            PDPageContentStream contenido,
            float anchoPagina,
            float altoPagina,
            int total,
            String periodo,
            Usuario administrador) throws IOException {

        // Fondo guinda institucional
        contenido.setNonStrokingColor(138, 22, 48);

        contenido.addRect(
            0,
            altoPagina - 105,
            anchoPagina,
            105
        );

        contenido.fill();

        escribirTexto(
            contenido,
            "SISTEMA INTEGRAL DE GESTION DOCUMENTAL",
            MARGEN,
            altoPagina - 42,
            fuenteTitulo,
            19,
            255,
            255,
            255
        );

        escribirTexto(
            contenido,
            "ARCHIVO MUNICIPAL",
            MARGEN,
            altoPagina - 65,
            fuenteNormal,
            11,
            255,
            255,
            255
        );

        escribirTexto(
            contenido,
            "REPORTE DE ACTIVIDADES DEL SISTEMA",
            MARGEN,
            altoPagina - 90,
            fuenteNegrita,
            12,
            255,
            255,
            255
        );

        float y = altoPagina - 130;

        escribirTexto(
            contenido,
            "Periodo consultado: " + limpiarTexto(periodo),
            MARGEN,
            y,
            fuenteNegrita,
            10,
            45,
            45,
            45
        );

        y -= 17;

        escribirTexto(
            contenido,
            "Generado por: "
                + limpiarTexto(administrador.getNombre()),
            MARGEN,
            y,
            fuenteNormal,
            9,
            45,
            45,
            45
        );

        y -= 15;

        escribirTexto(
            contenido,
            "Fecha de generacion: "
                + LocalDateTime.now().format(formatoGeneracion),
            MARGEN,
            y,
            fuenteNormal,
            9,
            45,
            45,
            45
        );

        y -= 15;

        escribirTexto(
            contenido,
            "Total de actividades: " + total,
            MARGEN,
            y,
            fuenteNegrita,
            9,
            45,
            45,
            45
        );

        y -= 18;

        contenido.setStrokingColor(190, 155, 85);

        contenido.setLineWidth(1);

        contenido.moveTo(MARGEN, y);
        contenido.lineTo(anchoPagina - MARGEN, y);

        contenido.stroke();

        return y - 20;
    }

    private float escribirActividad(
            PDPageContentStream contenido,
            ReporteActividad actividad,
            List<String> lineasDetalle,
            float y,
            float anchoPagina) throws IOException {

        // Identificador y fecha
        String fecha = actividad.getFechaEvento() != null
            ? actividad.getFechaEvento().format(formatoFecha)
            : "No disponible";

        escribirTexto(
            contenido,
            "EVENTO #" + actividad.getIdEvento(),
            MARGEN,
            y,
            fuenteNegrita,
            10,
            138,
            22,
            48
        );

        escribirTexto(
            contenido,
            "Fecha: " + fecha,
            anchoPagina - 220,
            y,
            fuenteNormal,
            9,
            45,
            45,
            45
        );

        y -= 15;

        // Usuario
        String usuario = obtenerTexto(
            actividad.getNombreUsuario()
        );

        String cuenta = obtenerTexto(
            actividad.getNombreCuenta()
        );

        String rol = obtenerTexto(
            actividad.getRol()
        );

        escribirTexto(
            contenido,
            "Usuario: " + usuario
                + " | Cuenta: " + cuenta
                + " | Rol: " + rol,
            MARGEN,
            y,
            fuenteNormal,
            TAMANO_TEXTO,
            45,
            45,
            45
        );

        y -= ESPACIO_LINEA;

        // Módulo y acción
        escribirTexto(
            contenido,
            "Modulo: " + obtenerTexto(actividad.getEntidad())
                + " | Accion: " + obtenerTexto(actividad.getAccion())
                + " | ID registro: "
                + obtenerTexto(actividad.getIdRegistro()),
            MARGEN,
            y,
            fuenteNormal,
            TAMANO_TEXTO,
            45,
            45,
            45
        );

        y -= ESPACIO_LINEA;

        // Detalle
        escribirTexto(
            contenido,
            "Detalle:",
            MARGEN,
            y,
            fuenteNegrita,
            TAMANO_TEXTO,
            45,
            45,
            45
        );

        y -= ESPACIO_LINEA;

        for (String linea : lineasDetalle) {

            escribirTexto(
                contenido,
                linea,
                MARGEN + 12,
                y,
                fuenteNormal,
                TAMANO_TEXTO,
                65,
                65,
                65
            );

            y -= ESPACIO_LINEA;
        }

        y -= 8;

        // Separador entre actividades
        contenido.setStrokingColor(220, 220, 220);

        contenido.setLineWidth(0.5f);

        contenido.moveTo(MARGEN, y);
        contenido.lineTo(anchoPagina - MARGEN, y);

        contenido.stroke();

        return y - 15;
    }

    private void escribirTexto(
            PDPageContentStream contenido,
            String texto,
            float x,
            float y,
            PDFont fuente,
            float tamano,
            int rojo,
            int verde,
            int azul) throws IOException {

        contenido.beginText();

        contenido.setFont(fuente, tamano);

        contenido.setNonStrokingColor(
            rojo,
            verde,
            azul
        );

        contenido.newLineAtOffset(x, y);

        contenido.showText(limpiarTexto(texto));

        contenido.endText();
    }

    private List<String> dividirTexto(
            String texto,
            PDFont fuente,
            float tamano,
            float anchoMaximo) throws IOException {

        List<String> lineas = new ArrayList<>();

        if (texto == null || texto.isBlank()) {
            lineas.add("Sin detalle registrado.");
            return lineas;
        }

        String[] palabras = limpiarTexto(texto).split("\\s+");

        StringBuilder lineaActual = new StringBuilder();

        for (String palabra : palabras) {

            String posibleLinea = lineaActual.length() == 0
                ? palabra
                : lineaActual + " " + palabra;

            float ancho = fuente.getStringWidth(posibleLinea)
                / 1000 * tamano;

            if (ancho > anchoMaximo && lineaActual.length() > 0) {

                lineas.add(lineaActual.toString());

                lineaActual = new StringBuilder(palabra);

            } else {

                lineaActual = new StringBuilder(posibleLinea);
            }
        }

        if (lineaActual.length() > 0) {
            lineas.add(lineaActual.toString());
        }

        return lineas;
    }

    private String obtenerTexto(Object valor) {

        return valor == null
            ? "No disponible"
            : String.valueOf(valor);
    }

    private String limpiarTexto(String texto) {

        if (texto == null) {
            return "";
        }

        return texto
            .replace("—", "-")
            .replace("–", "-")
            .replace("“", "\"")
            .replace("”", "\"")
            .replace("’", "'")
            .replace("‘", "'")
            .replace("•", "-");
    }
}
