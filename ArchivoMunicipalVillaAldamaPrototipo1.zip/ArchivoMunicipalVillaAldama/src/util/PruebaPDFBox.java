package util;

import org.apache.pdfbox.Loader;

public class PruebaPDFBox {

    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println("PRUEBA DE BIBLIOTECA PDFBOX");
        System.out.println("================================");

        System.out.println("PDFBox disponible: "
                + Loader.class.getName());

        System.out.println("La biblioteca se cargo correctamente.");
    }
}