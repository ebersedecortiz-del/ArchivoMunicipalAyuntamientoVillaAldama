
package util;

import java.io.File;
import java.nio.file.Path;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class PruebaGestorArchivosPDF {

    public static void main(String[] args) {

        GestorArchivosPDF gestor = new GestorArchivosPDF();

        JFileChooser selector = new JFileChooser();

        selector.setDialogTitle("Seleccionar documento PDF");

        selector.setFileFilter(
                new FileNameExtensionFilter(
                        "Archivos PDF (*.pdf)", "pdf"));

        int resultado = selector.showOpenDialog(null);

        if (resultado != JFileChooser.APPROVE_OPTION) {

            System.out.println("No se seleccionó ningún archivo.");
            return;
        }

        File archivoSeleccionado = selector.getSelectedFile();

        try {

            Path origen = archivoSeleccionado.toPath();

            System.out.println("================================");
            System.out.println("PRUEBA DE ALMACENAMIENTO PDF");
            System.out.println("================================");

            System.out.println(
                    "Archivo original: " + archivoSeleccionado.getName());

            String nombreAlmacenado = gestor.guardarPDF(origen);

            Path rutaGuardada =
                    gestor.obtenerRutaPDF(nombreAlmacenado);

            long tamano =
                    gestor.obtenerTamano(rutaGuardada);

            String sha256 =
                    gestor.calcularSHA256(rutaGuardada);

            System.out.println("Nombre almacenado: " + nombreAlmacenado);
            System.out.println("Ruta: " + rutaGuardada);
            System.out.println("Tamaño: " + tamano + " bytes");
            System.out.println("SHA-256: " + sha256);

            JOptionPane.showMessageDialog(
                    null,
                    "El PDF se almacenó correctamente.\n\n"
                    + "Nombre: " + nombreAlmacenado
                    + "\nTamaño: " + tamano + " bytes",
                    "Prueba exitosa",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "No fue posible almacenar el PDF:\n"
                    + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );

            e.printStackTrace();
        }
    }
}
