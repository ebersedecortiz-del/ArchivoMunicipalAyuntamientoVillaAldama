
package util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;

public class GestorArchivosPDF {

    private static final Path CARPETA_BASE =
            Paths.get("archivos_municipales", "documentos");

    /*
     * Devuelve la carpeta de almacenamiento.
     */
    public Path obtenerCarpetaBase() throws IOException {

        Files.createDirectories(CARPETA_BASE);

        return CARPETA_BASE.toAbsolutePath().normalize();
    }

    /*
     * Guarda una copia del PDF seleccionado.
     *
     * Devuelve el nombre interno del archivo.
     */
    public String guardarPDF(Path archivoSeleccionado)
            throws IOException {

        if (archivoSeleccionado == null
                || !Files.isRegularFile(archivoSeleccionado)) {

            throw new IOException(
                    "No se seleccionó un archivo válido.");
        }

        String nombreOriginal =
                archivoSeleccionado.getFileName().toString();

        if (!nombreOriginal.toLowerCase().endsWith(".pdf")) {
            throw new IOException(
                    "El archivo seleccionado no tiene extensión PDF.");
        }

        /*
         * Comprobamos que PDFBox pueda abrir el documento.
         */
        try (PDDocument documento =
                Loader.loadPDF(archivoSeleccionado.toFile())) {

            if (documento.isEncrypted()) {
                throw new IOException(
                        "No se permiten archivos PDF cifrados.");
            }
        } catch (IOException e) {
            throw new IOException(
                    "El archivo no es un PDF válido o no se puede abrir.",
                    e);
        }

        Path carpeta = obtenerCarpetaBase();

        String nombreAlmacenado =
                UUID.randomUUID().toString() + ".pdf";

        Path destino = carpeta.resolve(nombreAlmacenado);

        Files.copy(
                archivoSeleccionado,
                destino,
                StandardCopyOption.COPY_ATTRIBUTES);

        return nombreAlmacenado;
    }

    /*
     * Calcula el tamaño del archivo en bytes.
     */
    public long obtenerTamano(Path archivo) throws IOException {

        return Files.size(archivo);
    }

    /*
     * Calcula la huella SHA-256.
     */
    public String calcularSHA256(Path archivo)
            throws IOException {

        try {
            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");

            try (InputStream entrada = Files.newInputStream(archivo)) {

                byte[] buffer = new byte[8192];

                int bytesLeidos;

                while ((bytesLeidos = entrada.read(buffer)) != -1) {
                    digest.update(buffer, 0, bytesLeidos);
                }
            }

            byte[] resultado = digest.digest();

            StringBuilder hexadecimal = new StringBuilder();

            for (byte b : resultado) {
                hexadecimal.append(
                        String.format("%02x", b & 0xff));
            }

            return hexadecimal.toString();

        } catch (NoSuchAlgorithmException e) {

            throw new IOException(
                    "No fue posible calcular SHA-256.", e);
        }
    }

    /*
     * Recupera la ubicación de un PDF almacenado.
     */
    public Path obtenerRutaPDF(String nombreAlmacenado)
            throws IOException {

        if (nombreAlmacenado == null
                || !nombreAlmacenado.matches(
                        "[a-fA-F0-9-]{36}\\.pdf")) {

            throw new IOException(
                    "El nombre del archivo almacenado no es válido.");
        }

        Path ruta = obtenerCarpetaBase()
                .resolve(nombreAlmacenado)
                .normalize();

        if (!ruta.startsWith(obtenerCarpetaBase())) {
            throw new IOException(
                    "La ruta del archivo no es válida.");
        }

        return ruta;
    }
    /*
     * Elimina una copia almacenada cuando falla
     * el registro del documento en MySQL.
     */
    public void eliminarPDF(String nombreAlmacenado)
            throws IOException {

        Path ruta = obtenerRutaPDF(nombreAlmacenado);

        Files.deleteIfExists(ruta);
    }
}
