
package util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDPageContentStream.AppendMode;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import modelo.ReporteActividad;
import modelo.Usuario;

/**
 * Genera informes institucionales de actividades del Sistema Integral
 * de Gestion Documental y Archivo Municipal.
 *
 * Recursos esperados:
 * /recursos/escudo_villa_aldama.png
 * /recursos/times.ttf
 * /recursos/timesbd.ttf
 * /recursos/timesi.ttf
 * /recursos/timesbi.ttf
 */
public class GeneradorReportePDF {

    private static final int GUINDA_R = 138;
    private static final int GUINDA_G = 22;
    private static final int GUINDA_B = 48;

    private static final int DORADO_R = 190;
    private static final int DORADO_G = 155;
    private static final int DORADO_B = 85;

    private static final float MARGEN = 28f;
    private static final float TAMANO_TABLA = 6.5f;
    private static final float INTERLINEADO_TABLA = 8f;

    private static final DateTimeFormatter FORMATO_FECHA =
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    private static final DateTimeFormatter FORMATO_PORTADA =
        DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy, HH:mm:ss");

    private PDType0Font normal;
    private PDType0Font negrita;
    private PDType0Font cursiva;
    private PDType0Font negritaCursiva;

    /**
     * Genera el informe PDF institucional.
     */
    public void generarReporteActividades(
            List<ReporteActividad> actividades,
            String periodo,
            Usuario administrador,
            File destino) throws IOException {

        if (actividades == null) {
            throw new IllegalArgumentException(
                "La lista de actividades no puede ser nula.");
        }

        if (administrador == null) {
            throw new IllegalArgumentException(
                "No se identifico al administrador que genera el reporte.");
        }

        if (destino == null) {
            throw new IllegalArgumentException(
                "No se especifico el archivo de destino.");
        }

        String periodoSeguro = (periodo == null || periodo.isBlank())
            ? "No especificado" : periodo;

        try (PDDocument documento = new PDDocument()) {

            cargarFuentes(documento);

            PDImageXObject escudo = cargarEscudo(documento);

            crearPortada(
                documento,
                escudo,
                actividades,
                periodoSeguro,
                administrador
            );

            crearPaginasDetalle(
                documento,
                actividades,
                periodoSeguro
            );

            agregarPiesDePagina(documento);

            File carpeta = destino.getAbsoluteFile().getParentFile();

            if (carpeta != null && !carpeta.exists()
                    && !carpeta.mkdirs()) {
                throw new IOException(
                    "No fue posible crear la carpeta de destino del PDF.");
            }

            documento.save(destino);
        }
    }

    // =========================================================
    // CARGA DE RECURSOS
    // =========================================================

    private void cargarFuentes(PDDocument documento) throws IOException {

        normal = cargarFuente(documento, "/recursos/times.ttf");

        negrita = cargarFuente(documento, "/recursos/timesbd.ttf");

        cursiva = cargarFuente(documento, "/recursos/timesi.ttf");

        negritaCursiva = cargarFuente(documento, "/recursos/timesbi.ttf");
    }

    private PDType0Font cargarFuente(
            PDDocument documento,
            String ruta) throws IOException {

        InputStream entrada =
            GeneradorReportePDF.class.getResourceAsStream(ruta);

        if (entrada == null) {
            throw new IOException(
                "No se encontro el recurso de fuente: " + ruta
                + ". Verifica que el archivo este dentro de src/recursos.");
        }

        try (InputStream recurso = entrada) {
            return PDType0Font.load(documento, recurso);
        }
    }

    private PDImageXObject cargarEscudo(
            PDDocument documento) throws IOException {

        InputStream entrada =
            GeneradorReportePDF.class.getResourceAsStream(
                "/recursos/escudo_villa_aldama.png"
            );

        if (entrada == null) {
            throw new IOException(
                "No se encontro /recursos/escudo_villa_aldama.png.");
        }

        try (
            InputStream recurso = entrada;
            ByteArrayOutputStream salida = new ByteArrayOutputStream()
        ) {
            recurso.transferTo(salida);

            return PDImageXObject.createFromByteArray(
                documento,
                salida.toByteArray(),
                "escudo_villa_aldama"
            );
        }
    }

    // =========================================================
    // PORTADA INSTITUCIONAL
    // =========================================================


private void crearPortada(
        PDDocument documento,
        PDImageXObject escudo,
        List<ReporteActividad> actividades,
        String periodo,
        Usuario administrador) throws IOException {

    PDPage pagina = new PDPage(PDRectangle.A4);

    documento.addPage(pagina);

    float ancho = pagina.getMediaBox().getWidth();
    float alto = pagina.getMediaBox().getHeight();

    try (
        PDPageContentStream c =
            new PDPageContentStream(documento, pagina)
    ) {

        // ==========================================
        // FONDO GUINDA PROFUNDO
        // Color de referencia: #6A0531
        // ==========================================

        aplicarColorRelleno(c, 106, 5, 49);

        c.addRect(0, 0, ancho, alto);
        c.fill();

        // ==========================================
        // MARCO EXTERIOR DORADO
        // ==========================================

        aplicarColorTrazo(c, DORADO_R, DORADO_G, DORADO_B);

        c.setLineWidth(2.2f);
        c.addRect(30, 34, ancho - 60, alto - 68);
        c.stroke();

        // ==========================================
        // MARCO INTERIOR DORADO
        // ==========================================

        aplicarColorTrazo(c, 220, 190, 125);

        c.setLineWidth(0.9f);
        c.addRect(38, 42, ancho - 76, alto - 84);
        c.stroke();

        // ==========================================
        // BANDA SUPERIOR GUINDA
        // ==========================================

        aplicarColorRelleno(c, 138, 22, 48);

        c.addRect(40, alto - 155, ancho - 80, 105);
        c.fill();

        // Línea dorada.

        aplicarColorRelleno(c, DORADO_R, DORADO_G, DORADO_B);

        c.addRect(40, alto - 159, ancho - 80, 4);
        c.fill();

        // ==========================================
        // ESCUDO MUNICIPAL
        // ==========================================

        float imagenW = 112;
        float imagenH = 112;

        c.drawImage(
            escudo,
            (ancho - imagenW) / 2,
            alto - 300,
            imagenW,
            imagenH
        );

        // ==========================================
        // IDENTIDAD INSTITUCIONAL
        // ==========================================

        centrar(
            c,
            "ESTADOS UNIDOS MEXICANOS",
            alto - 330,
            negrita,
            9,
            230, 205, 155,
            ancho
        );

        centrar(
            c,
            "H. AYUNTAMIENTO DE VILLA ALDAMA",
            alto - 360,
            negrita,
            17,
            245, 225, 185,
            ancho
        );

        centrar(
            c,
            "VERACRUZ DE IGNACIO DE LA LLAVE",
            alto - 380,
            normal,
            11,
            235, 225, 215,
            ancho
        );

        // ==========================================
        // SEPARADOR DORADO
        // ==========================================

        aplicarColorTrazo(c, DORADO_R, DORADO_G, DORADO_B);

        c.setLineWidth(1.2f);
        c.moveTo(105, alto - 405);
        c.lineTo(ancho - 105, alto - 405);
        c.stroke();

        // ==========================================
        // NOMBRE DEL SISTEMA
        // ==========================================

        centrar(
            c,
            "SISTEMA INTEGRAL DE GESTION DOCUMENTAL",
            alto - 445,
            negrita,
            12,
            245, 235, 220,
            ancho
        );

        centrar(
            c,
            "Y ARCHIVO MUNICIPAL",
            alto - 463,
            negrita,
            12,
            245, 235, 220,
            ancho
        );

        // ==========================================
        // TITULO DEL INFORME
        // ==========================================

        centrar(
            c,
            "INFORME DE ACTIVIDADES DEL SISTEMA",
            alto - 520,
            negrita,
            16,
            225, 190, 120,
            ancho
        );

        centrar(
            c,
            "Periodo consultado",
            alto - 565,
            cursiva,
            11,
            235, 225, 215,
            ancho
        );

        centrar(
            c,
            limpiar(periodo),
            alto - 585,
            negrita,
            13,
            255, 245, 225,
            ancho
        );

        // ==========================================
        // DATOS DE ELABORACION
        // ==========================================

        String nombreAdmin = texto(administrador.getNombre());

        String cuentaAdmin = texto(
            administrador.getNombreUsuario()
        );

        centrar(
            c,
            "Generado por: " + nombreAdmin + " (" + cuentaAdmin + ")",
            145,
            normal,
            10,
            240, 230, 215,
            ancho
        );

        centrar(
            c,
            "Fecha de generacion: "
                + LocalDateTime.now().format(FORMATO_PORTADA),
            126,
            normal,
            10,
            240, 230, 215,
            ancho
        );

        centrar(
            c,
            "Total de actividades incluidas: " + actividades.size(),
            107,
            negrita,
            10,
            225, 190, 120,
            ancho
        );

        centrar(
            c,
            "DOCUMENTO DE USO INSTITUCIONAL",
            70,
            negrita,
            8,
            225, 190, 120,
            ancho
        );
    }
}

    // =========================================================
    // PAGINAS DE DETALLE
    // =========================================================

    private void crearPaginasDetalle(
            PDDocument documento,
            List<ReporteActividad> actividades,
            String periodo) throws IOException {

        PDRectangle horizontal = new PDRectangle(
            PDRectangle.A4.getHeight(),
            PDRectangle.A4.getWidth()
        );

        PDPage pagina = new PDPage(horizontal);

        documento.addPage(pagina);

        PDPageContentStream c =
            new PDPageContentStream(documento, pagina);

        float ancho = horizontal.getWidth();
        float alto = horizontal.getHeight();

        float y = crearEncabezadoDetalle(
            c, ancho, alto, periodo, actividades
        );

        float[] anchos = {
            34, 88, 68, 58, 65, 65, 52, 200, 110
        };

        String[] titulos = {
            "ID",
            "Usuario",
            "Cuenta",
            "Rol",
            "Modulo",
            "Accion",
            "ID registro",
            "Detalle",
            "Fecha y hora"
        };

        y = dibujarCabeceraTabla(
            c, MARGEN, y, anchos, titulos
        );

        if (actividades.isEmpty()) {

            escribirTexto(
                c,
                "No se encontraron actividades para los criterios seleccionados.",
                MARGEN + 8,
                y - 20,
                normal,
                10,
                70, 70, 70
            );

        } else {

            boolean alternar = false;

            for (ReporteActividad a : actividades) {

                String[] valores = {

                    String.valueOf(a.getIdEvento()),

                    texto(a.getNombreUsuario()),

                    texto(a.getNombreCuenta()),

                    texto(a.getRol()),

                    texto(a.getEntidad()),

                    texto(a.getAccion()),

                    a.getIdRegistro() == null
                        ? "-"
                        : String.valueOf(a.getIdRegistro()),

                    texto(a.getDetalle()),

                    a.getFechaEvento() == null
                        ? "No disponible"
                        : a.getFechaEvento().format(FORMATO_FECHA)
                };

                List<List<String>> celdas = new ArrayList<>();

                int maxLineas = 1;

                for (int i = 0; i < valores.length; i++) {

                    List<String> lineas = ajustarTexto(
                        valores[i],
                        normal,
                        TAMANO_TABLA,
                        anchos[i] - 7
                    );

                    celdas.add(lineas);

                    maxLineas = Math.max(
                        maxLineas,
                        lineas.size()
                    );
                }

                float altoFila = Math.max(
                    19,
                    maxLineas * INTERLINEADO_TABLA + 7
                );

                if (y - altoFila < 48) {

                    c.close();

                    pagina = new PDPage(horizontal);
                    documento.addPage(pagina);

                    c = new PDPageContentStream(
                        documento,
                        pagina
                    );

                    y = crearEncabezadoDetalle(
                        c, ancho, alto, periodo, actividades
                    );

                    y = dibujarCabeceraTabla(
                        c, MARGEN, y, anchos, titulos
                    );

                    alternar = false;
                }

                dibujarFila(
                    c,
                    MARGEN,
                    y,
                    anchos,
                    celdas,
                    altoFila,
                    alternar
                );

                y -= altoFila;

                alternar = !alternar;
            }
        }

        c.close();
    }

    // =========================================================
    // ENCABEZADO DE PAGINAS INTERIORES
    // =========================================================

    private float crearEncabezadoDetalle(
            PDPageContentStream c,
            float ancho,
            float alto,
            String periodo,
            List<ReporteActividad> actividades) throws IOException {

        aplicarColorRelleno(c, GUINDA_R, GUINDA_G, GUINDA_B);

        c.addRect(0, alto - 67, ancho, 67);
        c.fill();

        escribirTexto(
            c,
            "H. AYUNTAMIENTO DE VILLA ALDAMA, VERACRUZ",
            MARGEN,
            alto - 27,
            negrita,
            12,
            255, 255, 255
        );

        escribirTexto(
            c,
            "SISTEMA INTEGRAL DE GESTION DOCUMENTAL Y ARCHIVO MUNICIPAL",
            MARGEN,
            alto - 45,
            normal,
            9,
            255, 255, 255
        );

        escribirTexto(
            c,
            "INFORME DE ACTIVIDADES | Periodo: " + limpiar(periodo),
            MARGEN,
            alto - 59,
            normal,
            8,
            255, 255, 255
        );

        Set<Long> usuarios = new HashSet<>();
        Set<String> modulos = new HashSet<>();

        for (ReporteActividad a : actividades) {

            if (a.getIdUsuario() != null) {
                usuarios.add(a.getIdUsuario());
            }

            if (a.getEntidad() != null
                    && !a.getEntidad().isBlank()) {
                modulos.add(a.getEntidad());
            }
        }

        float y = alto - 91;

        escribirTexto(
            c,
            "RESUMEN ESTADISTICO",
            MARGEN,
            y,
            negrita,
            9,
            GUINDA_R, GUINDA_G, GUINDA_B
        );

        y -= 15;

        escribirTexto(
            c,
            "Total de actividades: " + actividades.size()
                + "     Usuarios involucrados: " + usuarios.size()
                + "     Modulos involucrados: " + modulos.size(),
            MARGEN,
            y,
            normal,
            8,
            55, 55, 55
        );

        y -= 17;

        aplicarColorTrazo(c, DORADO_R, DORADO_G, DORADO_B);

        c.setLineWidth(1f);
        c.moveTo(MARGEN, y);
        c.lineTo(ancho - MARGEN, y);
        c.stroke();

        return y - 8;
    }

    // =========================================================
    // TABLA DE ACTIVIDADES
    // =========================================================

    private float dibujarCabeceraTabla(
            PDPageContentStream c,
            float x,
            float y,
            float[] anchos,
            String[] titulos) throws IOException {

        float alto = 23;
        float total = sumar(anchos);

        aplicarColorRelleno(c, GUINDA_R, GUINDA_G, GUINDA_B);

        c.addRect(x, y - alto, total, alto);
        c.fill();

        float actualX = x;

        for (int i = 0; i < titulos.length; i++) {

            escribirTexto(
                c,
                titulos[i],
                actualX + 3,
                y - 15,
                negrita,
                7,
                255, 255, 255
            );

            actualX += anchos[i];
        }

        return y - alto;
    }

    private void dibujarFila(
            PDPageContentStream c,
            float x,
            float y,
            float[] anchos,
            List<List<String>> celdas,
            float alto,
            boolean alternar) throws IOException {

        float total = sumar(anchos);

        if (alternar) {
            aplicarColorRelleno(c, 248, 245, 238);
        } else {
            aplicarColorRelleno(c, 255, 255, 255);
        }

        c.addRect(x, y - alto, total, alto);
        c.fill();

        aplicarColorTrazo(c, 218, 213, 204);

        c.setLineWidth(0.35f);
        c.addRect(x, y - alto, total, alto);
        c.stroke();

        float actualX = x;

        for (int i = 0; i < anchos.length; i++) {

            float textoY = y - 10;

            for (String linea : celdas.get(i)) {

                escribirTexto(
                    c,
                    linea,
                    actualX + 3,
                    textoY,
                    normal,
                    TAMANO_TABLA,
                    45, 45, 45
                );

                textoY -= INTERLINEADO_TABLA;
            }

            actualX += anchos[i];
        }

        // Divisiones verticales.
        actualX = x;

        for (float ancho : anchos) {

            actualX += ancho;

            c.moveTo(actualX, y);
            c.lineTo(actualX, y - alto);
        }

        c.stroke();
    }

    // =========================================================
    // PIES DE PAGINA Y NUMERACION
    // =========================================================

    private void agregarPiesDePagina(
            PDDocument documento) throws IOException {

        int total = documento.getNumberOfPages();

        for (int i = 0; i < total; i++) {

            PDPage pagina = documento.getPage(i);

            PDRectangle caja = pagina.getMediaBox();

            float ancho = caja.getWidth();

            try (
                PDPageContentStream c =
                    new PDPageContentStream(
                        documento,
                        pagina,
                        AppendMode.APPEND,
                        true,
                        true
                    )
            ) {

                aplicarColorTrazo(c, DORADO_R, DORADO_G, DORADO_B);

                c.setLineWidth(0.6f);
                c.moveTo(MARGEN, 35);
                c.lineTo(ancho - MARGEN, 35);
                c.stroke();

                escribirTexto(
                    c,
                    "H. AYUNTAMIENTO DE VILLA ALDAMA | DOCUMENTO INSTITUCIONAL",
                    MARGEN,
                    23,
                    normal,
                    7,
                    95, 85, 75
                );

                String paginaTexto =
                    "Pagina " + (i + 1) + " de " + total;

                float anchoTexto =
                    negrita.getStringWidth(paginaTexto) / 1000 * 7;

                escribirTexto(
                    c,
                    paginaTexto,
                    ancho - MARGEN - anchoTexto,
                    23,
                    negrita,
                    7,
                    GUINDA_R,
                    GUINDA_G,
                    GUINDA_B
                );
            }
        }
    }

    // =========================================================
    // METODOS AUXILIARES
    // =========================================================

    private void centrar(
            PDPageContentStream c,
            String texto,
            float y,
            PDType0Font fuente,
            float tamano,
            int r,
            int g,
            int b,
            float anchoPagina) throws IOException {

        String seguro = limpiar(texto);

        float anchoTexto =
            fuente.getStringWidth(seguro) / 1000 * tamano;

        escribirTexto(
            c,
            seguro,
            (anchoPagina - anchoTexto) / 2,
            y,
            fuente,
            tamano,
            r,
            g,
            b
        );
    }

    private void escribirTexto(
            PDPageContentStream c,
            String texto,
            float x,
            float y,
            PDType0Font fuente,
            float tamano,
            int r,
            int g,
            int b) throws IOException {

        c.beginText();

        c.setFont(fuente, tamano);

        aplicarColorRelleno(c, r, g, b);

        c.newLineAtOffset(x, y);

        c.showText(limpiar(texto));

        c.endText();
    }

    private List<String> ajustarTexto(
            String texto,
            PDType0Font fuente,
            float tamano,
            float anchoMaximo) throws IOException {

        List<String> lineas = new ArrayList<>();

        String limpio = limpiar(texto)
            .replace('\n', ' ')
            .replace('\r', ' ')
            .trim();

        if (limpio.isEmpty()) {
            limpio = "-";
        }

        StringBuilder actual = new StringBuilder();

        for (String palabra : limpio.split("\\s+")) {

            String candidata = actual.length() == 0
                ? palabra
                : actual + " " + palabra;

            float ancho =
                fuente.getStringWidth(candidata) / 1000 * tamano;

            if (ancho > anchoMaximo && actual.length() > 0) {

                lineas.add(actual.toString());

                actual = new StringBuilder(palabra);

            } else {

                actual = new StringBuilder(candidata);
            }
        }

        if (actual.length() > 0) {
            lineas.add(actual.toString());
        }

        return lineas;
    }

    private float sumar(float[] valores) {

        float total = 0;

        for (float valor : valores) {
            total += valor;
        }

        return total;
    }

    // =========================================================
    // CONVERSION DE COLORES RGB PARA PDFBOX
    // =========================================================

    /**
     * Aplica un color de relleno RGB.
     * Convierte los valores tradicionales 0-255 al rango 0-1.
     */
    private void aplicarColorRelleno(
            PDPageContentStream c,
            int r,
            int g,
            int b) throws IOException {

        c.setNonStrokingColor(
            r / 255f,
            g / 255f,
            b / 255f
        );
    }

    /**
     * Aplica un color de trazo RGB.
     * Convierte los valores tradicionales 0-255 al rango 0-1.
     */
    private void aplicarColorTrazo(
            PDPageContentStream c,
            int r,
            int g,
            int b) throws IOException {

        c.setStrokingColor(
            r / 255f,
            g / 255f,
            b / 255f
        );
    }

    private String texto(Object valor) {

        return valor == null || String.valueOf(valor).isBlank()
            ? "No disponible"
            : String.valueOf(valor);
    }

    private String limpiar(String valor) {

        if (valor == null) {
            return "";
        }

        return valor
            .replace('\t', ' ')
            .replace('\r', ' ')
            .replace('\n', ' ')
            .replace("—", "-")
            .replace("–", "-")
            .replace("•", "-")
            .replace("“", "\"")
            .replace("”", "\"")
            .replace("’", "'")
            .replace("‘", "'");
    }
}
