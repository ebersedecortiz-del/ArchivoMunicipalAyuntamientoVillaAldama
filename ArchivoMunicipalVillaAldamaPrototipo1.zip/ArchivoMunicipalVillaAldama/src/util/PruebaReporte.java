
package util;

import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;

import dao.ReporteDAO;
import modelo.ReporteActividad;

public class PruebaReporte {

    public static void main(String[] args) {

        ReporteDAO reporteDAO = new ReporteDAO();

        DateTimeFormatter formato =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        try {

            System.out.println("====================================");
            System.out.println(" PRUEBA DEL MODULO DE REPORTES");
            System.out.println("====================================");

            // Consultar todas las actividades.
            List<ReporteActividad> actividades =
                reporteDAO.listarActividades(null, null, null);

            if (actividades.isEmpty()) {

                System.out.println(
                    "No existen actividades registradas en la bitacora."
                );

            } else {

                System.out.println(
                    "Total de actividades encontradas: "
                    + actividades.size()
                );

                System.out.println("------------------------------------");

                for (ReporteActividad actividad : actividades) {

                    System.out.println(
                        "ID evento: " + actividad.getIdEvento()
                    );

                    System.out.println(
                        "Usuario: "
                        + (actividad.getNombreUsuario() != null
                            ? actividad.getNombreUsuario()
                            : "Sin usuario asociado")
                    );

                    System.out.println(
                        "Cuenta: "
                        + (actividad.getNombreCuenta() != null
                            ? actividad.getNombreCuenta()
                            : "No disponible")
                    );

                    System.out.println(
                        "Rol: "
                        + (actividad.getRol() != null
                            ? actividad.getRol()
                            : "No disponible")
                    );

                    System.out.println(
                        "Entidad: " + actividad.getEntidad()
                    );

                    System.out.println(
                        "Accion: " + actividad.getAccion()
                    );

                    System.out.println(
                        "ID registro: "
                        + (actividad.getIdRegistro() != null
                            ? actividad.getIdRegistro()
                            : "No aplica")
                    );

                    System.out.println(
                        "Detalle: " + actividad.getDetalle()
                    );

                    System.out.println(
                        "Fecha: "
                        + (actividad.getFechaEvento() != null
                            ? actividad.getFechaEvento().format(formato)
                            : "No disponible")
                    );

                    System.out.println("------------------------------------");
                }
            }

            System.out.println("PRUEBA FINALIZADA.");

        } catch (SQLException e) {

            System.err.println(
                "ERROR AL CONSULTAR LOS REPORTES:"
            );

            e.printStackTrace();
        }
    }
}
