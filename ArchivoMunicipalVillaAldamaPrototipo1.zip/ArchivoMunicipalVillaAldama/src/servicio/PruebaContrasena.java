
package servicio;

import dao.UsuarioDAO;
import util.SeguridadContrasena;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import java.sql.SQLException;
import java.util.Arrays;

public class PruebaContrasena {

    public static void main(String[] args) {

        String nombreUsuario = "VictorOrtiz";

        JPasswordField campoContrasena = new JPasswordField(20);

        int resultado = JOptionPane.showConfirmDialog(
                null,
                campoContrasena,
                "Verificar contraseña de VictorOrtiz",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (resultado != JOptionPane.OK_OPTION) {
            return;
        }

        char[] contrasena = campoContrasena.getPassword();

        try {
            UsuarioDAO usuarioDAO = new UsuarioDAO();

            String hash = usuarioDAO.obtenerHashContrasena(
                    nombreUsuario
            );

            if (hash == null || hash.isBlank()) {
                JOptionPane.showMessageDialog(
                        null,
                        "No se encontró un hash para el usuario."
                );
                return;
            }

            boolean coincide = SeguridadContrasena.verificar(
                    contrasena,
                    hash
            );

            if (coincide) {
                JOptionPane.showMessageDialog(
                        null,
                        "RESULTADO: CORRECTO\n"
                        + "La contraseña coincide con el hash "
                        + "almacenado para VictorOrtiz."
                );
            } else {
                JOptionPane.showMessageDialog(
                        null,
                        "RESULTADO: NO COINCIDE\n"
                        + "La contraseña introducida no corresponde "
                        + "al hash almacenado."
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error al consultar MySQL:\n" + ex.getMessage()
            );

            ex.printStackTrace();

        } finally {
            Arrays.fill(contrasena, '\0');
        }
    }
}
