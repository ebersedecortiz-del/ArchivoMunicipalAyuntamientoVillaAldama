
package servicio;

import java.sql.SQLException;

import dao.BitacoraDAO;
import modelo.Actividad;

public class ActividadServicio {

    private final BitacoraDAO bitacoraDAO = new BitacoraDAO();

    /**
     * Registra una actividad realizada dentro del sistema.
     *
     * @param idUsuario Usuario que realizó la operación.
     *                  Puede ser null para eventos sin usuario identificado.
     * @param entidad Módulo o entidad relacionada.
     * @param idRegistro Identificador del registro afectado.
     *                   Puede ser null si no corresponde.
     * @param accion Operación realizada.
     * @param detalle Descripción adicional del evento.
     * @return Identificador del evento registrado.
     */
    public long registrarActividad(
            Long idUsuario,
            String entidad,
            Long idRegistro,
            String accion,
            String detalle) throws SQLException {

        if (entidad == null || entidad.isBlank()) {
            throw new IllegalArgumentException(
                "Debe especificarse la entidad de la actividad."
            );
        }

        if (entidad.trim().length() > 80) {
            throw new IllegalArgumentException(
                "La entidad no puede superar los 80 caracteres."
            );
        }

        if (accion == null || accion.isBlank()) {
            throw new IllegalArgumentException(
                "Debe especificarse la acción realizada."
            );
        }

        if (accion.trim().length() > 50) {
            throw new IllegalArgumentException(
                "La acción no puede superar los 50 caracteres."
            );
        }

        if (idUsuario != null && idUsuario <= 0) {
            throw new IllegalArgumentException(
                "El identificador del usuario no es válido."
            );
        }

        if (idRegistro != null && idRegistro <= 0) {
            throw new IllegalArgumentException(
                "El identificador del registro no es válido."
            );
        }

        Actividad actividad = new Actividad();

        actividad.setIdUsuario(idUsuario);
        actividad.setEntidad(entidad.trim());
        actividad.setIdRegistro(idRegistro);
        actividad.setAccion(accion.trim());
        actividad.setDetalle(detalle);

        return bitacoraDAO.registrar(actividad);
    }
}
