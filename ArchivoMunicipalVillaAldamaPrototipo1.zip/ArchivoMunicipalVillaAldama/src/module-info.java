
module ArchivoMunicipalVillaAldama {

    requires java.sql;
    requires java.desktop;

    requires org.apache.pdfbox;
    requires org.apache.pdfbox.io;
    requires org.apache.fontbox;
    requires org.apache.commons.logging;

}
