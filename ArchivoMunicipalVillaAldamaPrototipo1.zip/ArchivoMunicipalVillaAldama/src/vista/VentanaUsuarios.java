
package vista;

import dao.UsuarioDAO;
import modelo.Usuario;
import util.SeguridadContrasena;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class VentanaUsuarios extends JPanel {

    private final Usuario usuarioSesion;
    private final UsuarioDAO usuarioDAO;

    private JTable tablaUsuarios;
    private DefaultTableModel modeloTabla;

    private List<Usuario> usuariosActuales;

    private JLabel lblTotal;

    public VentanaUsuarios(Usuario usuarioSesion) {

        if (usuarioSesion == null
                || !usuarioSesion.isActivo()
                || !"ADMINISTRADOR".equalsIgnoreCase(
                    usuarioSesion.getRol())) {

            throw new SecurityException(
                "Solo un administrador activo puede administrar usuarios."
            );
        }

        this.usuarioSesion = usuarioSesion;
        this.usuarioDAO = new UsuarioDAO();

        setLayout(new BorderLayout(10, 10));
        setBackground(Color.WHITE);

        setBorder(
            BorderFactory.createEmptyBorder(
                15, 15, 15, 15
            )
        );

        construirInterfaz();
        cargarUsuarios();
    }

    // ==========================================
    // CONSTRUIR INTERFAZ
    // ==========================================

    private void construirInterfaz() {

        // ENCABEZADO

        JPanel panelSuperior = new JPanel(
            new BorderLayout(5, 5)
        );

        panelSuperior.setBackground(Color.WHITE);

        JLabel titulo = new JLabel(
            "ADMINISTRACIÓN DE USUARIOS",
            SwingConstants.CENTER
        );

        titulo.setFont(
            new Font("Serif", Font.BOLD, 23)
        );

        JLabel subtitulo = new JLabel(
            "Gestión de cuentas, roles y permisos",
            SwingConstants.CENTER
        );

        subtitulo.setFont(
            new Font("Serif", Font.PLAIN, 15)
        );

        JLabel lblAdministrador = new JLabel(
            "Administrador: " + usuarioSesion.getNombre()
        );

        JPanel encabezado = new JPanel(
            new GridLayout(2, 1, 5, 5)
        );

        encabezado.setBackground(Color.WHITE);

        encabezado.add(titulo);
        encabezado.add(subtitulo);

        panelSuperior.add(
            encabezado,
            BorderLayout.NORTH
        );

        panelSuperior.add(
            lblAdministrador,
            BorderLayout.SOUTH
        );

        // TABLA

        modeloTabla = new DefaultTableModel(
            new Object[]{
                "ID",
                "Nombre",
                "Usuario",
                "Correo",
                "Rol",
                "Área",
                "Estado"
            }, 0
        ) {

            @Override
            public boolean isCellEditable(
                    int fila, int columna) {

                return false;
            }
        };

        tablaUsuarios = new JTable(modeloTabla);

        tablaUsuarios.setSelectionMode(
            ListSelectionModel.SINGLE_SELECTION
        );

        tablaUsuarios.setAutoCreateRowSorter(true);
        tablaUsuarios.setRowHeight(25);

        JScrollPane desplazamiento =
                new JScrollPane(tablaUsuarios);

        // BOTONES

        JButton btnNuevo =
                new JButton("Nuevo usuario");

        JButton btnModificar =
                new JButton("Modificar");

        JButton btnDesactivar =
                new JButton("Desactivar cuenta");

        JButton btnActualizar =
                new JButton("Actualizar lista");

        btnNuevo.addActionListener(
            e -> registrarUsuario()
        );

        btnModificar.addActionListener(
            e -> modificarUsuario()
        );

        btnDesactivar.addActionListener(
            e -> desactivarUsuario()
        );

        btnActualizar.addActionListener(
            e -> cargarUsuarios()
        );

        JPanel panelBotones = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 8, 8)
        );

        panelBotones.setBackground(Color.WHITE);

        panelBotones.add(btnNuevo);
        panelBotones.add(btnModificar);
        panelBotones.add(btnDesactivar);
        panelBotones.add(btnActualizar);

        // PIE

        lblTotal = new JLabel(
            "Usuarios registrados: 0"
        );

        JLabel nota = new JLabel(
            "Las cuentas se desactivan sin eliminar su registro."
        );

        JPanel panelInferior = new JPanel(
            new BorderLayout(5, 5)
        );

        panelInferior.setBackground(Color.WHITE);

        panelInferior.add(
            lblTotal,
            BorderLayout.NORTH
        );

        panelInferior.add(
            panelBotones,
            BorderLayout.CENTER
        );

        panelInferior.add(
            nota,
            BorderLayout.SOUTH
        );

        // DISTRIBUCIÓN

        add(panelSuperior, BorderLayout.NORTH);
        add(desplazamiento, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);
    }

    // ==========================================
    // CARGAR USUARIOS
    // ==========================================

    private void cargarUsuarios() {

        try {

            usuariosActuales = usuarioDAO.listarTodos();

            modeloTabla.setRowCount(0);

            for (Usuario usuario : usuariosActuales) {

                modeloTabla.addRow(new Object[]{

                    usuario.getIdUsuario(),
                    usuario.getNombre(),
                    usuario.getNombreUsuario(),

                    usuario.getCorreo() == null
                        ? ""
                        : usuario.getCorreo(),

                    usuario.getRol(),

                    usuario.getIdArea() == null
                        ? "Sin asignar"
                        : usuario.getIdArea(),

                    usuario.isActivo()
                        ? "ACTIVO"
                        : "INACTIVO"
                });
            }

            lblTotal.setText(
                "Usuarios registrados: "
                + usuariosActuales.size()
            );

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible cargar los usuarios.\n"
                + e.getMessage(),
                "Error de base de datos",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ==========================================
    // REGISTRAR USUARIO
    // ==========================================

    private void registrarUsuario() {

        JTextField txtNombre = new JTextField();
        JTextField txtNombreUsuario = new JTextField();
        JTextField txtCorreo = new JTextField();

        JComboBox<String> cmbRol = new JComboBox<>(
            new String[]{
                "ARCHIVISTA",
                "CONSULTA",
                "ADMINISTRADOR"
            }
        );

        JPasswordField txtContrasena =
                new JPasswordField();

        JPasswordField txtConfirmacion =
                new JPasswordField();

        JPanel panel = new JPanel(
            new GridLayout(0, 1, 5, 5)
        );

        panel.add(new JLabel("Nombre completo:"));
        panel.add(txtNombre);

        panel.add(new JLabel("Nombre de usuario:"));
        panel.add(txtNombreUsuario);

        panel.add(
            new JLabel("Correo electrónico (opcional):")
        );

        panel.add(txtCorreo);

        panel.add(new JLabel("Rol:"));
        panel.add(cmbRol);

        panel.add(
            new JLabel("Contraseña (mínimo 12 caracteres):")
        );

        panel.add(txtContrasena);

        panel.add(
            new JLabel("Confirmar contraseña:")
        );

        panel.add(txtConfirmacion);

        int resultado = JOptionPane.showConfirmDialog(
            this,
            panel,
            "Registrar usuario",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (resultado != JOptionPane.OK_OPTION) {

            limpiarContrasenas(
                txtContrasena,
                txtConfirmacion
            );

            return;
        }

        char[] contrasena =
                txtContrasena.getPassword();

        char[] confirmacion =
                txtConfirmacion.getPassword();

        try {

            String nombre =
                    txtNombre.getText().trim();

            String nombreUsuario =
                    txtNombreUsuario.getText().trim();

            String correo =
                    txtCorreo.getText().trim();

            String rol =
                    (String) cmbRol.getSelectedItem();

            if (nombre.isEmpty()
                    || nombreUsuario.isEmpty()) {

                mostrarAviso(
                    "El nombre y el nombre de usuario son obligatorios."
                );

                return;
            }

            if (nombreUsuario.length() < 3) {

                mostrarAviso(
                    "El nombre de usuario debe tener al menos 3 caracteres."
                );

                return;
            }

            if (correo.length() > 180) {

                mostrarAviso(
                    "El correo no puede superar los 180 caracteres."
                );

                return;
            }

            if (contrasena.length < 12) {

                mostrarAviso(
                    "La contraseña debe tener al menos 12 caracteres."
                );

                return;
            }

            if (!Arrays.equals(
                    contrasena,
                    confirmacion)) {

                mostrarAviso(
                    "Las contraseñas no coinciden."
                );

                return;
            }

            Usuario nuevo = new Usuario();

            nuevo.setNombre(nombre);
            nuevo.setNombreUsuario(nombreUsuario);

            nuevo.setCorreo(
                correo.isEmpty() ? null : correo
            );

            nuevo.setRol(rol);
            nuevo.setIdArea(null);
            nuevo.setActivo(true);

            String hash =
                    SeguridadContrasena.generarHash(
                        contrasena
                    );

            usuarioDAO.registrar(nuevo, hash);

            JOptionPane.showMessageDialog(
                this,
                "El usuario se registró correctamente.",
                "Registro completado",
                JOptionPane.INFORMATION_MESSAGE
            );

            cargarUsuarios();

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible registrar al usuario.\n"
                + "Comprueba que el nombre de usuario y el correo "
                + "no estén duplicados.\n\n"
                + e.getMessage(),
                "Error de registro",
                JOptionPane.ERROR_MESSAGE
            );

        } catch (IllegalArgumentException e) {

            JOptionPane.showMessageDialog(
                this,
                "No se pudo generar el hash de la contraseña.\n"
                + e.getMessage(),
                "Error de contraseña",
                JOptionPane.ERROR_MESSAGE
            );

        } finally {

            Arrays.fill(contrasena, '\0');
            Arrays.fill(confirmacion, '\0');

            limpiarContrasenas(
                txtContrasena,
                txtConfirmacion
            );
        }
    }

    // ==========================================
    // MODIFICAR USUARIO
    // ==========================================

    private void modificarUsuario() {

        Usuario seleccionado =
                obtenerUsuarioSeleccionado();

        if (seleccionado == null) {

            mostrarAviso(
                "Selecciona una fila de la tabla para modificar un usuario."
            );

            return;
        }

        JTextField txtNombre = new JTextField(
            seleccionado.getNombre()
        );

        JTextField txtCorreo = new JTextField(
            seleccionado.getCorreo() == null
                ? ""
                : seleccionado.getCorreo()
        );

        JComboBox<String> cmbRol = new JComboBox<>(
            new String[]{
                "ADMINISTRADOR",
                "ARCHIVISTA",
                "CONSULTA"
            }
        );

        cmbRol.setSelectedItem(
            seleccionado.getRol()
        );

        JPanel panel = new JPanel(
            new GridLayout(0, 1, 5, 5)
        );

        panel.add(
            new JLabel("Nombre completo:")
        );

        panel.add(txtNombre);

        panel.add(
            new JLabel("Nombre de usuario (no modificable):")
        );

        panel.add(
            new JLabel(seleccionado.getNombreUsuario())
        );

        panel.add(
            new JLabel("Correo electrónico (opcional):")
        );

        panel.add(txtCorreo);

        panel.add(
            new JLabel("Rol:")
        );

        panel.add(cmbRol);

        int resultado = JOptionPane.showConfirmDialog(
            this,
            panel,
            "Modificar usuario",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (resultado != JOptionPane.OK_OPTION) {
            return;
        }

        String nombre =
                txtNombre.getText().trim();

        String correo =
                txtCorreo.getText().trim();

        String rolNuevo =
                (String) cmbRol.getSelectedItem();

        if (nombre.isEmpty()) {

            mostrarAviso(
                "El nombre es obligatorio."
            );

            return;
        }

        if (correo.length() > 180) {

            mostrarAviso(
                "El correo no puede superar los 180 caracteres."
            );

            return;
        }

        if (seleccionado.getIdUsuario()
                == usuarioSesion.getIdUsuario()
                && !Objects.equals(
                    seleccionado.getRol(),
                    rolNuevo)) {

            mostrarAviso(
                "No puedes cambiar tu propio rol desde esta ventana."
            );

            return;
        }

        seleccionado.setNombre(nombre);

        seleccionado.setCorreo(
            correo.isEmpty() ? null : correo
        );

        seleccionado.setRol(rolNuevo);

        try {

            usuarioDAO.actualizarDatos(seleccionado);

            JOptionPane.showMessageDialog(
                this,
                "Los datos del usuario se actualizaron.",
                "Actualización completada",
                JOptionPane.INFORMATION_MESSAGE
            );

            cargarUsuarios();

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible modificar al usuario.\n"
                + e.getMessage(),
                "Error de actualización",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ==========================================
    // DESACTIVAR USUARIO
    // ==========================================

    private void desactivarUsuario() {

        Usuario seleccionado =
                obtenerUsuarioSeleccionado();

        if (seleccionado == null) {

            mostrarAviso(
                "Selecciona una cuenta antes de desactivarla."
            );

            return;
        }

        if (seleccionado.getIdUsuario()
                == usuarioSesion.getIdUsuario()) {

            mostrarAviso(
                "No puedes desactivar tu propia cuenta desde esta ventana."
            );

            return;
        }

        if (!seleccionado.isActivo()) {

            mostrarAviso(
                "Esta cuenta ya está inactiva."
            );

            return;
        }

        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Deseas desactivar la cuenta de "
            + seleccionado.getNombreUsuario()
            + "?\nEl registro se conservará en la base de datos.",
            "Confirmar desactivación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            usuarioDAO.desactivar(
                seleccionado.getIdUsuario()
            );

            JOptionPane.showMessageDialog(
                this,
                "La cuenta fue desactivada.",
                "Operación completada",
                JOptionPane.INFORMATION_MESSAGE
            );

            cargarUsuarios();

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible desactivar la cuenta.\n"
                + e.getMessage(),
                "Error de base de datos",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ==========================================
    // OBTENER FILA SELECCIONADA
    // ==========================================

    private Usuario obtenerUsuarioSeleccionado() {

        int filaVista =
                tablaUsuarios.getSelectedRow();

        if (filaVista == -1) {
            return null;
        }

        int filaModelo =
                tablaUsuarios.convertRowIndexToModel(
                    filaVista
                );

        if (usuariosActuales == null
                || filaModelo < 0
                || filaModelo >= usuariosActuales.size()) {

            return null;
        }

        return usuariosActuales.get(filaModelo);
    }

    // ==========================================
    // MOSTRAR AVISOS
    // ==========================================

    private void mostrarAviso(String mensaje) {

        JOptionPane.showMessageDialog(
            this,
            mensaje,
            "Validación",
            JOptionPane.WARNING_MESSAGE
        );
    }

    // ==========================================
    // LIMPIAR CONTRASEÑAS
    // ==========================================

    private void limpiarContrasenas(
            JPasswordField campo1,
            JPasswordField campo2) {

        campo1.setText("");
        campo2.setText("");
    }
}
