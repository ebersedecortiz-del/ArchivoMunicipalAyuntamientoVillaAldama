
package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

public class VisorPDF extends JDialog {

    private PDDocument documentoPDF;
    private PDFRenderer renderizador;

    private int paginaActual = 0;
    private float zoom = 1.0f;

    private JLabel lblPagina;
    private JLabel lblImagen;

    private JButton btnAnterior;
    private JButton btnSiguiente;
    private JButton btnMenos;
    private JButton btnMas;

    public VisorPDF(Window propietario, File archivo)
            throws IOException {

        super(
            propietario,
            "Visualizador de documentos PDF",
            ModalityType.APPLICATION_MODAL
        );

        documentoPDF = Loader.loadPDF(archivo);

        renderizador = new PDFRenderer(documentoPDF);

        construirInterfaz();

        mostrarPagina();

        setSize(1000, 750);
        setLocationRelativeTo(propietario);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        addWindowListener(new java.awt.event.WindowAdapter() {

            @Override
            public void windowClosed(
                    java.awt.event.WindowEvent e) {

                cerrarDocumento();
            }
        });
    }

    private void construirInterfaz() {

        setLayout(new BorderLayout(8, 8));

        JPanel barraHerramientas =
                new JPanel(new FlowLayout(FlowLayout.CENTER));

        btnAnterior = new JButton("Página anterior");
        btnSiguiente = new JButton("Página siguiente");

        btnMenos = new JButton("-");
        btnMas = new JButton("+");

        lblPagina = new JLabel();

        barraHerramientas.add(btnAnterior);
        barraHerramientas.add(btnSiguiente);
        barraHerramientas.add(new JLabel("   Zoom: "));
        barraHerramientas.add(btnMenos);
        barraHerramientas.add(btnMas);
        barraHerramientas.add(new JLabel("   "));
        barraHerramientas.add(lblPagina);

        lblImagen = new JLabel();

        lblImagen.setHorizontalAlignment(
                SwingConstants.CENTER);

        JScrollPane desplazamiento =
                new JScrollPane(lblImagen);

        add(barraHerramientas, BorderLayout.NORTH);
        add(desplazamiento, BorderLayout.CENTER);

        btnAnterior.addActionListener(e -> {

            if (paginaActual > 0) {
                paginaActual--;
                mostrarPagina();
            }
        });

        btnSiguiente.addActionListener(e -> {

            if (paginaActual
                    < documentoPDF.getNumberOfPages() - 1) {

                paginaActual++;
                mostrarPagina();
            }
        });

        btnMenos.addActionListener(e -> {

            if (zoom > 0.50f) {
                zoom -= 0.25f;
                mostrarPagina();
            }
        });

        btnMas.addActionListener(e -> {

            if (zoom < 2.50f) {
                zoom += 0.25f;
                mostrarPagina();
            }
        });
    }

    private void mostrarPagina() {

        try {

            BufferedImage imagen =
                    renderizador.renderImage(
                        paginaActual,
                        zoom
                    );

            ImageIcon icono = new ImageIcon(
                    imagen.getScaledInstance(
                        imagen.getWidth(),
                        imagen.getHeight(),
                        Image.SCALE_SMOOTH
                    )
            );

            lblImagen.setIcon(icono);

            lblPagina.setText(
                "Página " + (paginaActual + 1)
                + " de " + documentoPDF.getNumberOfPages()
                + " | " + Math.round(zoom * 100) + "%"
            );

            btnAnterior.setEnabled(paginaActual > 0);

            btnSiguiente.setEnabled(
                paginaActual
                < documentoPDF.getNumberOfPages() - 1
            );

            btnMenos.setEnabled(zoom > 0.50f);
            btnMas.setEnabled(zoom < 2.50f);

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible visualizar la página:\n"
                + e.getMessage(),
                "Error al visualizar PDF",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void cerrarDocumento() {

        if (documentoPDF != null) {

            try {
                documentoPDF.close();
                documentoPDF = null;

            } catch (IOException e) {
                System.err.println(
                    "Error al cerrar PDF: " + e.getMessage()
                );
            }
        }
    }

    public static void abrir(Window propietario, File archivo) {

        try {

            VisorPDF visor =
                    new VisorPDF(propietario, archivo);

            visor.setVisible(true);

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                propietario,
                "No fue posible abrir el documento PDF:\n"
                + e.getMessage(),
                "Error al abrir PDF",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
