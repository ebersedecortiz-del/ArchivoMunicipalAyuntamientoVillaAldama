
package vista;

import conexion.ConexionBD;
import dao.CatalogoDAO;
import dao.ArchivoDigitalDAO;
import modelo.Documento;
import modelo.Usuario;
import modelo.OpcionCatalogo;
import modelo.ArchivoDigital;
import servicio.DocumentoServicio;
import servicio.ActividadServicio;
import util.GestorArchivosPDF;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.function.Consumer;

public class VentanaDocumentos extends JPanel {

    // ==========================================
    // CAMPOS DEL FORMULARIO
    // ==========================================

    private final JTextField txtFolio = new JTextField(25);
    private final JTextField txtNombre = new JTextField(25);
    private final JTextField txtFechaEmision = new JTextField(15);
    private final JTextField txtFechaRecepcion = new JTextField(15);
    private final JTextField txtExpediente = new JTextField(25);
    private final JTextField txtPalabrasClave = new JTextField(25);

    private final JTextArea txtDescripcion =
            new JTextArea(3, 25);

    private final JComboBox<OpcionCatalogo> cmbCategoria =
            new JComboBox<>();

    private final JComboBox<OpcionCatalogo> cmbTipo =
            new JComboBox<>();

    private final JComboBox<OpcionCatalogo> cmbArea =
            new JComboBox<>();

    private final JLabel lblNomenclatura =
            new JLabel("Selecciona un área.");

    private final JLabel lblEstado =
            new JLabel("Modo: registro de documento");

    private final JCheckBox chkFechaRecepcion =
            new JCheckBox("Registrar fecha de recepción");

    // ==========================================
    // TABLA DE DOCUMENTOS
    // ==========================================

    private final DefaultTableModel modeloTabla =
            new DefaultTableModel(
                new Object[]{
                    "ID",
                    "Folio interno",
                    "Nombre",
                    "Fecha de emisión",
                    "Estado"
                }, 0) {

        @Override
        public boolean isCellEditable(
                int fila, int columna) {
            return false;
        }
    };

    private final JTable tablaDocumentos =
            new JTable(modeloTabla);

    // ==========================================
    // SERVICIOS Y DAO
    // ==========================================

    private final DocumentoServicio documentoServicio =
            new DocumentoServicio();

    private final ActividadServicio actividadServicio =
            new ActividadServicio();

    private final CatalogoDAO catalogoDAO =
            new CatalogoDAO();

    private final ArchivoDigitalDAO archivoDigitalDAO =
            new ArchivoDigitalDAO();

    private Documento documentoEnEdicion = null;

    // Usuario autenticado que realiza las operaciones.
    private final Usuario usuarioSesion;

    // ==========================================
    // ADMINISTRACIÓN DE ARCHIVOS PDF
    // ==========================================

    private final GestorArchivosPDF gestorArchivosPDF =
            new GestorArchivosPDF();

    private Path pdfSeleccionado = null;

    private final JLabel lblArchivoPDF =
            new JLabel("No hay ningún PDF seleccionado.");

    private final JButton btnAdjuntarPDF =
            new JButton("Adjuntar PDF");

    private final JButton btnQuitarPDF =
            new JButton("Quitar PDF");

    // ==========================================
    // BOTONES
    // ==========================================

    private final JButton btnRegistrar =
            new JButton("Registrar documento");

    private final JButton btnModificar =
            new JButton("Cargar selección para modificar");

    private final JButton btnGuardarCambios =
            new JButton("Guardar modificación");

    private final JButton btnConsultar =
            new JButton("Consultar documentos");

    private final JButton btnLimpiar =
            new JButton("Limpiar / cancelar edición");

    private final JButton btnConexion =
            new JButton("Probar conexión");

    private final JButton btnVisualizarPDF =
            new JButton("Visualizar PDF");

    // ==========================================
    // CONSTRUCTOR
    // ==========================================

    public VentanaDocumentos(Usuario usuarioSesion) {

        if (usuarioSesion == null || !usuarioSesion.isActivo()) {
            throw new SecurityException(
                "Debes iniciar sesión con un usuario activo."
            );
        }

        String rol = usuarioSesion.getRol() == null
                ? ""
                : usuarioSesion.getRol().trim().toUpperCase();

        if (!rol.equals("ADMINISTRADOR")
                && !rol.equals("ARCHIVISTA")) {

            throw new SecurityException(
                "No tienes autorización para gestionar documentos."
            );
        }

        this.usuarioSesion = usuarioSesion;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        construirInterfaz();
        configurarEventos();
        cargarCatalogos();
        consultarDocumentos();
        actualizarEstadoBotones();
    }

    // ==========================================
    // SELECCIONAR ARCHIVO PDF
    // ==========================================

    private void seleccionarPDF() {

        JFileChooser selector = new JFileChooser();

        selector.setDialogTitle(
            "Seleccionar documento PDF"
        );

        selector.setFileFilter(
            new FileNameExtensionFilter(
                "Archivos PDF (*.pdf)",
                "pdf"
            )
        );

        int resultado = selector.showOpenDialog(this);

        if (resultado != JFileChooser.APPROVE_OPTION) {
            return;
        }

        Path archivo = selector.getSelectedFile().toPath();

        if (!archivo.getFileName().toString()
                .toLowerCase().endsWith(".pdf")) {

            JOptionPane.showMessageDialog(
                this,
                "Selecciona un archivo con extensión PDF.",
                "Archivo no válido",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        pdfSeleccionado = archivo;

        lblArchivoPDF.setText(
            archivo.getFileName().toString()
        );

        btnQuitarPDF.setEnabled(true);
    }

    // ==========================================
    // QUITAR PDF SELECCIONADO
    // ==========================================

    private void quitarPDF() {

        if (pdfSeleccionado == null) {
            return;
        }

        int respuesta = JOptionPane.showConfirmDialog(
            this,
            "¿Deseas quitar el PDF seleccionado?",
            "Confirmar acción",
            JOptionPane.YES_NO_OPTION
        );

        if (respuesta == JOptionPane.YES_OPTION) {

            pdfSeleccionado = null;

            lblArchivoPDF.setText(
                "No hay ningún PDF seleccionado."
            );

            btnQuitarPDF.setEnabled(false);
        }
    }

    // ==========================================
    // CONSTRUIR INTERFAZ
    // ==========================================

    private void construirInterfaz() {

        JPanel principal =
                new JPanel(new BorderLayout(10, 10));

        principal.setBorder(
            BorderFactory.createEmptyBorder(
                15, 15, 15, 15
            )
        );

        JLabel titulo = new JLabel(
            "GESTIÓN DOCUMENTAL Y ARCHIVO MUNICIPAL",
            SwingConstants.CENTER
        );

        titulo.setFont(
            new Font("Serif", Font.BOLD, 24)
        );

        principal.add(titulo, BorderLayout.NORTH);

        JPanel centro =
                new JPanel(new BorderLayout(10, 10));

        // ======================================
        // FORMULARIO
        // ======================================

        JPanel formulario =
                new JPanel(new GridBagLayout());

        formulario.setBorder(
            BorderFactory.createTitledBorder(
                "Registro de documento"
            )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets = new Insets(5, 7, 5, 7);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        int fila = 0;

        // Folio automático
        txtFolio.setEditable(false);
        txtFolio.setBackground(new Color(235, 235, 235));
        txtFolio.setText("Se generará al guardar");

        agregarCampo(
            formulario, gbc, fila++,
            "Folio interno automático:",
            txtFolio
        );

        // Nombre
        agregarCampo(
            formulario, gbc, fila++,
            "Nombre del documento:",
            txtNombre
        );

        // Área administrativa
        agregarCampo(
            formulario, gbc, fila++,
            "Área administrativa:",
            cmbArea
        );

        // Nomenclatura
        agregarCampo(
            formulario, gbc, fila++,
            "Clave auxiliar:",
            lblNomenclatura
        );

        // Categoría
        agregarCampo(
            formulario, gbc, fila++,
            "Categoría documental:",
            cmbCategoria
        );

        // Tipo
        agregarCampo(
            formulario, gbc, fila++,
            "Tipo documental:",
            cmbTipo
        );

        // Fecha de emisión
        agregarCampo(
            formulario, gbc, fila++,
            "Fecha de emisión:",
            crearSelectorFecha(
                txtFechaEmision, false
            )
        );

        // Fecha de recepción
        JPanel panelRecepcion =
                new JPanel(new BorderLayout(5, 5));

        panelRecepcion.add(
            chkFechaRecepcion,
            BorderLayout.NORTH
        );

        panelRecepcion.add(
            crearSelectorFecha(
                txtFechaRecepcion, true
            ),
            BorderLayout.CENTER
        );

        agregarCampo(
            formulario, gbc, fila++,
            "Fecha de recepción:",
            panelRecepcion
        );

        // Expediente
        agregarCampo(
            formulario, gbc, fila++,
            "ID de expediente (opcional):",
            txtExpediente
        );

        // Palabras clave
        agregarCampo(
            formulario, gbc, fila++,
            "Palabras clave:",
            txtPalabrasClave
        );

        // Descripción
        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.weightx = 0;

        formulario.add(
            new JLabel("Descripción:"),
            gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);

        formulario.add(
            new JScrollPane(txtDescripcion),
            gbc
        );

        // ======================================
        // ARCHIVO PDF
        // ======================================

        fila++;

        JPanel panelPDF =
                new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));

        panelPDF.add(btnAdjuntarPDF);
        panelPDF.add(btnQuitarPDF);
        panelPDF.add(lblArchivoPDF);

        agregarCampo(
            formulario,
            gbc,
            fila++,
            "Documento digital (PDF):",
            panelPDF
        );

     // Desplazamiento independiente del formulario
        JScrollPane scrollFormulario = new JScrollPane(
            formulario,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );

        scrollFormulario.setBorder(BorderFactory.createEmptyBorder());
        scrollFormulario.setPreferredSize(new java.awt.Dimension(900, 280));

        centro.add(scrollFormulario, BorderLayout.NORTH);

        // ======================================
        // TABLA
        // ======================================

        JPanel panelTabla =
                new JPanel(new BorderLayout());

        panelTabla.setBorder(
            BorderFactory.createTitledBorder(
                "Documentos registrados"
            )
        );

        tablaDocumentos.setAutoCreateRowSorter(true);

        tablaDocumentos.setSelectionMode(
            ListSelectionModel.SINGLE_SELECTION
        );

        tablaDocumentos.setRowHeight(25);

        JScrollPane scrollTabla = new JScrollPane(
            tablaDocumentos,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
        );

        scrollTabla.setPreferredSize(
            new Dimension(900, 220)
        );

        panelTabla.add(
            scrollTabla,
            BorderLayout.CENTER
        );

        centro.add(
            panelTabla,
            BorderLayout.CENTER
        );

        principal.add(
            centro,
            BorderLayout.CENTER
        );

        // ======================================
        // BOTONES
        // ======================================

        JPanel panelBotones =
                new JPanel(
                    new FlowLayout(
                        FlowLayout.CENTER, 8, 5
                    )
                );

        panelBotones.add(btnRegistrar);
        panelBotones.add(btnVisualizarPDF);
        panelBotones.add(btnModificar);
        panelBotones.add(btnGuardarCambios);
        panelBotones.add(btnConsultar);
        panelBotones.add(btnLimpiar);
        panelBotones.add(btnConexion);

        JPanel panelInferior =
                new JPanel(new BorderLayout());

        panelInferior.add(
            lblEstado,
            BorderLayout.NORTH
        );

        panelInferior.add(
            panelBotones,
            BorderLayout.CENTER
        );

        principal.add(
            panelInferior,
            BorderLayout.SOUTH
        );

        add(principal, BorderLayout.CENTER);
    }

    // ==========================================
    // AGREGAR CAMPO AL FORMULARIO
    // ==========================================

    private void agregarCampo(
            JPanel panel,
            GridBagConstraints gbc,
            int fila,
            String etiqueta,
            Component campo) {

        gbc.gridy = fila;
        gbc.gridx = 0;
        gbc.weightx = 0;

        panel.add(
            new JLabel(etiqueta),
            gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        panel.add(campo, gbc);
    }

    // ==========================================
    // SELECTOR DE FECHAS
    // ==========================================

    private JPanel crearSelectorFecha(
            JTextField campo,
            boolean recepcion) {

        JPanel panel =
                new JPanel(new BorderLayout(5, 0));

        campo.setEditable(false);
        campo.setBackground(Color.WHITE);
        campo.setText("");

        JButton btnCalendario =
                new JButton("Elegir fecha");

        JButton btnLimpiarFecha =
                new JButton("X");

        panel.add(
            campo,
            BorderLayout.CENTER
        );

        panel.add(
            btnCalendario,
            BorderLayout.EAST
        );

        panel.add(
            btnLimpiarFecha,
            BorderLayout.WEST
        );

        btnCalendario.addActionListener(e -> {

            if (recepcion && !chkFechaRecepcion.isSelected()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Primero activa la fecha de recepción.",
                    "Fecha opcional",
                    JOptionPane.INFORMATION_MESSAGE
                );

                return;
            }

            LocalDate inicial = LocalDate.now();

            if (!campo.getText().isBlank()) {
                inicial = LocalDate.parse(campo.getText());
            }

            abrirCalendario(
                inicial,
                fecha -> {

                    campo.setText(fecha.toString());

                    if (recepcion) {
                        validarFechaRecepcionVisual();
                    }
                }
            );
        });

        btnLimpiarFecha.addActionListener(e -> {
            campo.setText("");
        });

        return panel;
    }

    // ==========================================
    // CALENDARIO GRÁFICO
    // ==========================================

    private void abrirCalendario(
            LocalDate fechaInicial,
            Consumer<LocalDate> seleccion) {

        JDialog dialogo = new JDialog(
            SwingUtilities.getWindowAncestor(this),
            "Seleccionar fecha",
            Dialog.ModalityType.APPLICATION_MODAL
        );

        dialogo.setSize(340, 330);
        dialogo.setLocationRelativeTo(this);
        dialogo.setLayout(new BorderLayout(5, 5));

        YearMonth[] mesActual = {
            YearMonth.from(fechaInicial)
        };

        JPanel encabezado =
                new JPanel(new BorderLayout());

        JButton anterior = new JButton("<");
        JButton siguiente = new JButton(">");

        JLabel etiquetaMes =
                new JLabel("", SwingConstants.CENTER);

        etiquetaMes.setFont(
            new Font("Serif", Font.BOLD, 17)
        );

        encabezado.add(anterior, BorderLayout.WEST);
        encabezado.add(etiquetaMes, BorderLayout.CENTER);
        encabezado.add(siguiente, BorderLayout.EAST);

        JPanel dias =
                new JPanel(new GridLayout(0, 7, 3, 3));

        JPanel calendario =
                new JPanel(new BorderLayout(5, 5));

        calendario.setBorder(
            BorderFactory.createEmptyBorder(
                8, 8, 8, 8
            )
        );

        calendario.add(
            encabezado,
            BorderLayout.NORTH
        );

        calendario.add(
            dias,
            BorderLayout.CENTER
        );

        dialogo.add(
            calendario,
            BorderLayout.CENTER
        );

        String[] nombresDias = {
            "L", "M", "M", "J", "V", "S", "D"
        };

        Runnable dibujarCalendario = () -> {

            dias.removeAll();

            etiquetaMes.setText(
                mesActual[0].getMonth()
                    .getDisplayName(
                        java.time.format.TextStyle.FULL,
                        new java.util.Locale("es", "MX")
                    )
                + " "
                + mesActual[0].getYear()
            );

            for (String nombreDia : nombresDias) {

                JLabel etiqueta =
                        new JLabel(
                            nombreDia,
                            SwingConstants.CENTER
                        );

                etiqueta.setFont(
                    new Font("SansSerif", Font.BOLD, 12)
                );

                dias.add(etiqueta);
            }

            LocalDate primerDia =
                    mesActual[0].atDay(1);

            int desplazamiento =
                    primerDia.getDayOfWeek().getValue() - 1;

            for (int i = 0; i < desplazamiento; i++) {
                dias.add(new JLabel(""));
            }

            for (int dia = 1;
                    dia <= mesActual[0].lengthOfMonth();
                    dia++) {

                final LocalDate fecha =
                        mesActual[0].atDay(dia);

                JButton botonDia =
                        new JButton(String.valueOf(dia));

                botonDia.setMargin(
                    new Insets(3, 3, 3, 3)
                );

                if (fecha.equals(LocalDate.now())) {

                    botonDia.setFont(
                        new Font("SansSerif", Font.BOLD, 12)
                    );
                }

                botonDia.addActionListener(e -> {
                    seleccion.accept(fecha);
                    dialogo.dispose();
                });

                dias.add(botonDia);
            }

            dias.revalidate();
            dias.repaint();
        };

        anterior.addActionListener(e -> {
            mesActual[0] = mesActual[0].minusMonths(1);
            dibujarCalendario.run();
        });

        siguiente.addActionListener(e -> {
            mesActual[0] = mesActual[0].plusMonths(1);
            dibujarCalendario.run();
        });

        dibujarCalendario.run();

        dialogo.setVisible(true);
    }

    // ==========================================
    // CONFIGURAR EVENTOS
    // ==========================================

    private void configurarEventos() {

        btnRegistrar.addActionListener(
            e -> registrarDocumento()
        );

        btnModificar.addActionListener(
            e -> cargarSeleccionParaModificar()
        );

        btnGuardarCambios.addActionListener(
            e -> guardarModificacion()
        );

        // La consulta manual sí se registra en bitácora.
        btnConsultar.addActionListener(
            e -> consultarDocumentos(true)
        );

        btnLimpiar.addActionListener(
            e -> limpiarFormulario()
        );

        btnConexion.addActionListener(
            e -> probarConexion()
        );

        btnAdjuntarPDF.addActionListener(
            e -> seleccionarPDF()
        );

        btnQuitarPDF.addActionListener(
            e -> quitarPDF()
        );

        btnVisualizarPDF.addActionListener(
            e -> visualizarPDF()
        );

        cmbArea.addActionListener(
            e -> actualizarNomenclatura()
        );

        chkFechaRecepcion.addActionListener(e -> {

            txtFechaRecepcion.setEnabled(
                chkFechaRecepcion.isSelected()
            );

            if (!chkFechaRecepcion.isSelected()) {
                txtFechaRecepcion.setText("");
            }
        });

        txtFechaRecepcion.setEnabled(false);
        btnQuitarPDF.setEnabled(false);
    }

    // ==========================================
    // ACTUALIZAR NOMENCLATURA
    // ==========================================

    private void actualizarNomenclatura() {

        OpcionCatalogo area =
                (OpcionCatalogo) cmbArea.getSelectedItem();

        if (area == null) {

            lblNomenclatura.setText(
                "Selecciona un área."
            );

            return;
        }

        String clave = area.getClave();

        if (clave == null || clave.isBlank()) {

            lblNomenclatura.setText(
                "Sin clave auxiliar asignada."
            );

            return;
        }

        lblNomenclatura.setText(
            clave + " - Folio automático al guardar"
        );
    }

    // ==========================================
    // CARGAR CATÁLOGOS
    // ==========================================

    private void cargarCatalogos() {

        try {

            cmbCategoria.removeAllItems();
            cmbTipo.removeAllItems();
            cmbArea.removeAllItems();

            List<OpcionCatalogo> categorias =
                    catalogoDAO.listarCategorias();

            List<OpcionCatalogo> tipos =
                    catalogoDAO.listarTiposDocumentales();

            List<OpcionCatalogo> areas =
                    catalogoDAO.listarAreas();

            for (OpcionCatalogo opcion : categorias) {
                cmbCategoria.addItem(opcion);
            }

            for (OpcionCatalogo opcion : tipos) {
                cmbTipo.addItem(opcion);
            }

            for (OpcionCatalogo opcion : areas) {
                cmbArea.addItem(opcion);
            }

            cmbCategoria.setSelectedIndex(-1);
            cmbTipo.setSelectedIndex(-1);
            cmbArea.setSelectedIndex(-1);

            actualizarNomenclatura();

            if (categorias.isEmpty()
                    || tipos.isEmpty()
                    || areas.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Uno o más catálogos están vacíos.\n"
                    + "Verifica las categorías, tipos documentales "
                    + "y áreas administrativas en MySQL.",
                    "Catálogos pendientes",
                    JOptionPane.WARNING_MESSAGE
                );
            }

        } catch (SQLException e) {

            mostrarErrorBaseDatos(e);
        }

        actualizarEstadoBotones();
    }

    // ==========================================
    // ESTADO DE BOTONES
    // ==========================================

    private void actualizarEstadoBotones() {

        boolean catalogosDisponibles =
                cmbCategoria.getItemCount() > 0
                && cmbTipo.getItemCount() > 0
                && cmbArea.getItemCount() > 0;

        btnRegistrar.setEnabled(
            catalogosDisponibles
            && documentoEnEdicion == null
        );

        btnModificar.setEnabled(
            documentoEnEdicion == null
            && tablaDocumentos.getRowCount() > 0
        );

        btnGuardarCambios.setEnabled(
            catalogosDisponibles
            && documentoEnEdicion != null
        );

        btnLimpiar.setEnabled(true);
    }

    // ==========================================
    // LEER FORMULARIO
    // ==========================================

    private Documento leerFormulario() {

        Documento documento = new Documento();

        // El folio no se captura manualmente.
        if (documentoEnEdicion != null) {

            documento.setFolioInterno(
                documentoEnEdicion.getFolioInterno()
            );
        }

        documento.setNombre(
            txtNombre.getText().trim()
        );

        documento.setDescripcion(
            textoONull(txtDescripcion.getText())
        );

        documento.setPalabrasClave(
            textoONull(txtPalabrasClave.getText())
        );

        OpcionCatalogo categoria =
                (OpcionCatalogo) cmbCategoria.getSelectedItem();

        OpcionCatalogo tipo =
                (OpcionCatalogo) cmbTipo.getSelectedItem();

        OpcionCatalogo area =
                (OpcionCatalogo) cmbArea.getSelectedItem();

        if (categoria == null
                || tipo == null
                || area == null) {

            throw new IllegalArgumentException(
                "Selecciona una categoría, un tipo documental "
                + "y un área administrativa."
            );
        }

        documento.setIdCategoria(categoria.getId());
        documento.setIdTipo(tipo.getId());
        documento.setIdArea(area.getId());

        if (txtFechaEmision.getText().isBlank()) {

            throw new IllegalArgumentException(
                "Selecciona la fecha de emisión."
            );
        }

        documento.setFechaEmision(
            LocalDate.parse(txtFechaEmision.getText())
        );

        if (chkFechaRecepcion.isSelected()
                && !txtFechaRecepcion.getText().isBlank()) {

            documento.setFechaRecepcion(
                LocalDate.parse(txtFechaRecepcion.getText())
            );

        } else {

            documento.setFechaRecepcion(null);
        }

        String expediente =
                txtExpediente.getText().trim();

        if (!expediente.isEmpty()) {

            long idExpediente =
                    Long.parseLong(expediente);

            if (idExpediente <= 0) {

                throw new IllegalArgumentException(
                    "El ID de expediente debe ser positivo."
                );
            }

            documento.setIdExpediente(idExpediente);

        } else {

            documento.setIdExpediente(null);
        }

        documento.setEstado("REGISTRADO");

        if (documentoEnEdicion != null) {

            // Al modificar, se conserva el usuario que lo registró.
            documento.setCreadoPor(
                documentoEnEdicion.getCreadoPor()
            );

        } else {

            // Al registrar, se guarda el ID del usuario autenticado.
            documento.setCreadoPor(
                usuarioSesion.getIdUsuario()
            );
        }

        return documento;
    }

    // ==========================================
    // REGISTRAR DOCUMENTO
    // ==========================================

    private void registrarDocumento() {

        if (documentoEnEdicion != null) {
            return;
        }

        String nombrePDFGuardado = null;

        try {

            // 1. Leer y validar los datos del formulario.
            Documento documento = leerFormulario();

            long idGenerado;

            // ======================================
            // CASO A: REGISTRAR SIN PDF
            // ======================================

            if (pdfSeleccionado == null) {

                idGenerado =
                        documentoServicio.registrarDocumento(documento);

            } else {

                // ======================================
                // CASO B: REGISTRAR CON PDF
                // ======================================

                // 2. Guardar una copia del PDF.
                nombrePDFGuardado =
                        gestorArchivosPDF.guardarPDF(pdfSeleccionado);

                // 3. Recuperar la ubicación del archivo.
                Path rutaGuardada =
                        gestorArchivosPDF.obtenerRutaPDF(
                            nombrePDFGuardado
                        );

                // 4. Construir los datos del archivo digital.
                ArchivoDigital archivo = new ArchivoDigital();

                archivo.setNombreOriginal(
                    pdfSeleccionado.getFileName().toString()
                );

                archivo.setNombreAlmacenado(
                    nombrePDFGuardado
                );

                archivo.setRutaRelativa(
                    java.nio.file.Paths.get(
                        "archivos_municipales",
                        "documentos",
                        nombrePDFGuardado
                    ).toString().replace("\\", "/")
                );

                archivo.setTipoMime("application/pdf");

                archivo.setTamanoBytes(
                    gestorArchivosPDF.obtenerTamano(rutaGuardada)
                );

                archivo.setSha256(
                    gestorArchivosPDF.calcularSHA256(rutaGuardada)
                );

                archivo.setCargadoPor(
                    usuarioSesion.getIdUsuario()
                );

                // 5. Registrar documento y PDF en MySQL.
                idGenerado =
                        documentoServicio.registrarDocumento(
                            documento,
                            archivo
                        );
            }

            // ======================================
            // REGISTRO EXITOSO
            // ======================================

            // Registrar el alta del documento en la bitácora.
            registrarActividadAuditoria(
                "DOCUMENTOS",
                idGenerado,
                "REGISTRO_DOCUMENTO",
                "Se registró el documento: "
                    + documento.getNombre()
                    + ". Folio: "
                    + documento.getFolioInterno()
            );

            // Registrar el PDF cuando se guardó junto con el documento.
            if (nombrePDFGuardado != null) {

                registrarActividadAuditoria(
                    "DOCUMENTOS",
                    idGenerado,
                    "ADJUNTAR_PDF",
                    "Se adjuntó el archivo PDF: "
                        + nombrePDFGuardado
                );
            }

            String mensaje =
                    "Documento registrado correctamente.\n\n"
                    + "ID: " + idGenerado
                    + "\nFolio interno: "
                    + documento.getFolioInterno();

            if (nombrePDFGuardado != null) {

                mensaje +=
                        "\n\nPDF adjuntado correctamente."
                        + "\nArchivo: "
                        + nombrePDFGuardado;
            }

            JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Registro exitoso",
                JOptionPane.INFORMATION_MESSAGE
            );

            limpiarFormulario();
            consultarDocumentos();

        } catch (NumberFormatException e) {

            eliminarPDFSiExiste(nombrePDFGuardado);

            JOptionPane.showMessageDialog(
                this,
                "El ID de expediente debe ser un número válido.",
                "Dato incorrecto",
                JOptionPane.ERROR_MESSAGE
            );

        } catch (IllegalArgumentException e) {

            eliminarPDFSiExiste(nombrePDFGuardado);

            mostrarValidacion(e);

        } catch (IOException e) {

            eliminarPDFSiExiste(nombrePDFGuardado);

            JOptionPane.showMessageDialog(
                this,
                "No fue posible procesar el archivo PDF:\n"
                    + e.getMessage(),
                "Error con el PDF",
                JOptionPane.ERROR_MESSAGE
            );

        } catch (SQLException e) {

            eliminarPDFSiExiste(nombrePDFGuardado);

            mostrarErrorBaseDatos(e);
        }
    }

    // ==========================================
    // ELIMINAR PDF SI EL REGISTRO FALLA
    // ==========================================

    private void eliminarPDFSiExiste(String nombreAlmacenado) {

        if (nombreAlmacenado == null) {
            return;
        }

        try {

            gestorArchivosPDF.eliminarPDF(nombreAlmacenado);

        } catch (IOException e) {

            System.err.println(
                "No se pudo eliminar el PDF temporal: "
                    + e.getMessage()
            );
        }
    }

    // ==========================================
    // CARGAR DOCUMENTO PARA MODIFICAR
    // ==========================================

    private void cargarSeleccionParaModificar() {

        int filaVista =
                tablaDocumentos.getSelectedRow();

        if (filaVista < 0) {

            JOptionPane.showMessageDialog(
                this,
                "Selecciona un documento de la tabla.",
                "Documento no seleccionado",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int filaModelo =
                tablaDocumentos.convertRowIndexToModel(
                    filaVista
                );

        try {

            long idDocumento =
                    Long.parseLong(
                        modeloTabla.getValueAt(
                            filaModelo, 0
                        ).toString()
                    );

            List<Documento> documentos =
                    documentoServicio.listarDocumentos();

            Documento encontrado = null;

            for (Documento documento : documentos) {

                if (documento.getIdDocumento() == idDocumento) {
                    encontrado = documento;
                    break;
                }
            }

            if (encontrado == null) {

                throw new SQLException(
                    "El documento seleccionado ya no existe."
                );
            }

            documentoEnEdicion = encontrado;

            txtFolio.setText(
                encontrado.getFolioInterno()
            );

            txtNombre.setText(
                encontrado.getNombre()
            );

            txtFechaEmision.setText(
                encontrado.getFechaEmision() == null
                    ? ""
                    : encontrado.getFechaEmision().toString()
            );

            txtFechaRecepcion.setText(
                encontrado.getFechaRecepcion() == null
                    ? ""
                    : encontrado.getFechaRecepcion().toString()
            );

            chkFechaRecepcion.setSelected(
                encontrado.getFechaRecepcion() != null
            );

            txtFechaRecepcion.setEnabled(
                chkFechaRecepcion.isSelected()
            );

            txtExpediente.setText(
                encontrado.getIdExpediente() == null
                    ? ""
                    : encontrado.getIdExpediente().toString()
            );

            txtPalabrasClave.setText(
                encontrado.getPalabrasClave() == null
                    ? ""
                    : encontrado.getPalabrasClave()
            );

            txtDescripcion.setText(
                encontrado.getDescripcion() == null
                    ? ""
                    : encontrado.getDescripcion()
            );

            seleccionarCatalogo(
                cmbCategoria,
                encontrado.getIdCategoria()
            );

            seleccionarCatalogo(
                cmbTipo,
                encontrado.getIdTipo()
            );

            seleccionarCatalogo(
                cmbArea,
                encontrado.getIdArea()
            );

            txtFolio.setEditable(false);

            lblEstado.setText(
                "Modo: modificación de documento"
            );

            actualizarEstadoBotones();

            JOptionPane.showMessageDialog(
                this,
                "Documento cargado para modificación.\n"
                    + "El folio interno permanecerá sin cambios.",
                "Edición de documento",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (SQLException | NumberFormatException e) {

            mostrarErrorBaseDatos(
                e instanceof SQLException
                    ? (SQLException) e
                    : new SQLException(e.getMessage())
            );
        }
    }

    // ==========================================
    // SELECCIONAR CATÁLOGO
    // ==========================================

    private void seleccionarCatalogo(
            JComboBox<OpcionCatalogo> combo,
            long idBuscado) {

        for (int i = 0; i < combo.getItemCount(); i++) {

            OpcionCatalogo opcion =
                    combo.getItemAt(i);

            if (opcion.getId() == idBuscado) {

                combo.setSelectedIndex(i);
                return;
            }
        }

        combo.setSelectedIndex(-1);
    }

    // ==========================================
    // GUARDAR MODIFICACIÓN
    // ==========================================

    private void guardarModificacion() {

        if (documentoEnEdicion == null) {
            return;
        }

        int confirmacion =
                JOptionPane.showConfirmDialog(
                    this,
                    "¿Deseas guardar los cambios?\n\n"
                        + "Folio: "
                        + documentoEnEdicion.getFolioInterno(),
                    "Confirmar modificación",
                    JOptionPane.YES_NO_OPTION
                );

        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            Documento actualizado = leerFormulario();

            actualizado.setIdDocumento(
                documentoEnEdicion.getIdDocumento()
            );

            actualizado.setFolioInterno(
                documentoEnEdicion.getFolioInterno()
            );

            actualizado.setCreadoPor(
                documentoEnEdicion.getCreadoPor()
            );

            actualizado.setEstado(
                documentoEnEdicion.getEstado()
            );

            boolean modificado =
                    documentoServicio.actualizarDocumento(
                        actualizado
                    );

            if (modificado) {

                // Registrar la modificación en la bitácora.
                registrarActividadAuditoria(
                    "DOCUMENTOS",
                    actualizado.getIdDocumento(),
                    "MODIFICACION_DOCUMENTO",
                    "Se modificó el documento: "
                        + actualizado.getNombre()
                        + ". Folio: "
                        + actualizado.getFolioInterno()
                );

                JOptionPane.showMessageDialog(
                    this,
                    "Documento actualizado correctamente.",
                    "Modificación exitosa",
                    JOptionPane.INFORMATION_MESSAGE
                );

                limpiarFormulario();
                consultarDocumentos();

            } else {

                JOptionPane.showMessageDialog(
                    this,
                    "No se modificó ningún registro.",
                    "Sin cambios",
                    JOptionPane.WARNING_MESSAGE
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                this,
                "El ID de expediente debe ser válido.",
                "Dato incorrecto",
                JOptionPane.ERROR_MESSAGE
            );

        } catch (IllegalArgumentException e) {

            mostrarValidacion(e);

        } catch (SQLException e) {

            mostrarErrorBaseDatos(e);
        }
    }

    // ==========================================
    // CONSULTAR DOCUMENTOS
    // ==========================================

    private void consultarDocumentos() {

        // Consulta automática sin generar un evento
        // adicional en la bitácora.
        consultarDocumentos(false);
    }

    private void consultarDocumentos(boolean registrarConsulta) {

        try {

            List<Documento> documentos =
                    documentoServicio.listarDocumentos();

            modeloTabla.setRowCount(0);

            for (Documento documento : documentos) {

                modeloTabla.addRow(
                    new Object[]{
                        documento.getIdDocumento(),
                        documento.getFolioInterno(),
                        documento.getNombre(),
                        documento.getFechaEmision(),
                        documento.getEstado()
                    }
                );
            }

            actualizarEstadoBotones();

            // Registrar únicamente las consultas solicitadas
            // directamente mediante el botón del usuario.
            if (registrarConsulta) {

                registrarActividadAuditoria(
                    "DOCUMENTOS",
                    null,
                    "CONSULTA_DOCUMENTOS",
                    "Se realizó una consulta general de documentos."
                );
            }

        } catch (SQLException e) {

            mostrarErrorBaseDatos(e);
        }
    }

    // ==========================================
    // VISUALIZAR PDF DEL DOCUMENTO SELECCIONADO
    // ==========================================

    private void visualizarPDF() {

        int filaVista = tablaDocumentos.getSelectedRow();

        if (filaVista < 0) {

            JOptionPane.showMessageDialog(
                this,
                "Selecciona un documento de la tabla.",
                "Documento no seleccionado",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int filaModelo = tablaDocumentos.convertRowIndexToModel(
            filaVista
        );

        try {

            long idDocumento = Long.parseLong(
                modeloTabla.getValueAt(filaModelo, 0).toString()
            );

            List<ArchivoDigital> archivos =
                    archivoDigitalDAO.listarPorDocumento(idDocumento);

            if (archivos == null || archivos.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Este documento no tiene ningún PDF adjunto.",
                    "PDF no disponible",
                    JOptionPane.INFORMATION_MESSAGE
                );

                return;
            }

            ArchivoDigital archivoSeleccionado;

            // Si existe un solo PDF, se selecciona automáticamente.
            if (archivos.size() == 1) {

                archivoSeleccionado = archivos.get(0);

            } else {

                // Si existen varios PDF, permite elegir uno.
                String[] opciones = new String[archivos.size()];

                for (int i = 0; i < archivos.size(); i++) {

                    opciones[i] = (i + 1) + ". "
                        + archivos.get(i).getNombreOriginal();
                }

                String seleccion = (String) JOptionPane.showInputDialog(
                    this,
                    "Selecciona el archivo que deseas visualizar:",
                    "Archivos PDF disponibles",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
                );

                if (seleccion == null) {
                    return;
                }

                int indice = -1;

                for (int i = 0; i < opciones.length; i++) {

                    if (opciones[i].equals(seleccion)) {
                        indice = i;
                        break;
                    }
                }

                if (indice < 0) {
                    return;
                }

                archivoSeleccionado = archivos.get(indice);
            }

            // Recuperar la ubicación del PDF.
            Path rutaPDF = gestorArchivosPDF.obtenerRutaPDF(
                archivoSeleccionado.getNombreAlmacenado()
            );

            if (!java.nio.file.Files.isRegularFile(rutaPDF)) {

                JOptionPane.showMessageDialog(
                    this,
                    "No se encontró el archivo PDF en la ubicación esperada:\n"
                        + rutaPDF,
                    "Archivo no encontrado",
                    JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            // Abrir el visor PDF del sistema.
            VisorPDF.abrir(
                SwingUtilities.getWindowAncestor(this),
                rutaPDF.toFile()
            );

            // Registrar la visualización del archivo PDF.
            registrarActividadAuditoria(
                "DOCUMENTOS",
                idDocumento,
                "VISUALIZAR_PDF",
                "Se visualizó el archivo PDF: "
                    + archivoSeleccionado.getNombreOriginal()
            );

        } catch (SQLException e) {

            mostrarErrorBaseDatos(e);

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible visualizar el PDF.\n\n"
                    + e.getMessage(),
                "Error al abrir PDF",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ==========================================
    // REGISTRAR ACTIVIDAD EN LA BITÁCORA
    // ==========================================

    private void registrarActividadAuditoria(
            String entidad,
            Long idRegistro,
            String accion,
            String detalle) {

        try {

            actividadServicio.registrarActividad(
                usuarioSesion.getIdUsuario(),
                entidad,
                idRegistro,
                accion,
                detalle
            );

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "La operación se completó, pero no fue posible "
                    + "registrarla en la bitácora.\n"
                    + "Informa al administrador del sistema.",
                "Advertencia de auditoría",
                JOptionPane.WARNING_MESSAGE
            );

            e.printStackTrace();
        }
    }

    // ==========================================
    // LIMPIAR FORMULARIO
    // ==========================================

    private void limpiarFormulario() {

        documentoEnEdicion = null;

        pdfSeleccionado = null;

        lblArchivoPDF.setText(
            "No hay ningún PDF seleccionado."
        );

        btnQuitarPDF.setEnabled(false);

        txtFolio.setText(
            "Se generará al guardar"
        );

        txtFolio.setEditable(false);

        txtNombre.setText("");
        txtFechaEmision.setText("");
        txtFechaRecepcion.setText("");
        txtExpediente.setText("");
        txtPalabrasClave.setText("");
        txtDescripcion.setText("");

        chkFechaRecepcion.setSelected(false);
        txtFechaRecepcion.setEnabled(false);

        cmbCategoria.setSelectedIndex(-1);
        cmbTipo.setSelectedIndex(-1);
        cmbArea.setSelectedIndex(-1);

        actualizarNomenclatura();

        tablaDocumentos.clearSelection();

        lblEstado.setText(
            "Modo: registro de documento"
        );

        actualizarEstadoBotones();

        txtNombre.requestFocus();
    }

    // ==========================================
    // VALIDAR FECHA DE RECEPCIÓN VISUAL
    // ==========================================

    private void validarFechaRecepcionVisual() {

        if (txtFechaRecepcion.getText().isBlank()
                || txtFechaEmision.getText().isBlank()) {
            return;
        }

        LocalDate emision =
                LocalDate.parse(txtFechaEmision.getText());

        LocalDate recepcion =
                LocalDate.parse(txtFechaRecepcion.getText());

        if (recepcion.isBefore(emision)) {

            JOptionPane.showMessageDialog(
                this,
                "La recepción no puede ser anterior "
                    + "a la emisión.",
                "Fecha incorrecta",
                JOptionPane.WARNING_MESSAGE
            );

            txtFechaRecepcion.setText("");
        }
    }

    // ==========================================
    // UTILIDADES
    // ==========================================

    private String textoONull(String texto) {

        if (texto == null || texto.isBlank()) {
            return null;
        }

        return texto.trim();
    }

    private void mostrarValidacion(
            IllegalArgumentException e) {

        JOptionPane.showMessageDialog(
            this,
            e.getMessage(),
            "Validación",
            JOptionPane.WARNING_MESSAGE
        );
    }

    // ==========================================
    // PROBAR CONEXIÓN
    // ==========================================

    private void probarConexion() {

        try (Connection conexion =
                ConexionBD.conectar()) {

            JOptionPane.showMessageDialog(
                this,
                "Conexión exitosa con MySQL.\n"
                    + "Base de datos: "
                    + conexion.getCatalog(),
                "Conexión",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (SQLException e) {

            mostrarErrorBaseDatos(e);
        }
    }

    // ==========================================
    // MOSTRAR ERROR DE BASE DE DATOS
    // ==========================================

    private void mostrarErrorBaseDatos(SQLException e) {

        JOptionPane.showMessageDialog(
            this,
            "No fue posible completar la operación.\n\n"
                + "Detalle: " + e.getMessage(),
            "Error de base de datos",
            JOptionPane.ERROR_MESSAGE
        );
    }

}
