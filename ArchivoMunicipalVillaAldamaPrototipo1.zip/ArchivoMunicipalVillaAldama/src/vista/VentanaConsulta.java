
package vista;

import dao.ArchivoDigitalDAO;
import modelo.ArchivoDigital;
import modelo.Documento;
import modelo.Usuario;
import servicio.DocumentoServicio;
import util.GestorArchivosPDF;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.awt.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.regex.Pattern;

public class VentanaConsulta extends JPanel {

    private final Usuario usuario;

    private final DocumentoServicio documentoServicio =
            new DocumentoServicio();

    private final ArchivoDigitalDAO archivoDigitalDAO =
            new ArchivoDigitalDAO();

    private final GestorArchivosPDF gestorArchivosPDF =
            new GestorArchivosPDF();

    private JTable tablaDocumentos;
    private DefaultTableModel modeloTabla;
    private TableRowSorter<DefaultTableModel> ordenador;

    private JTextField txtBuscar;
    private JLabel lblTotal;

    private JButton btnVerPDF;

    public VentanaConsulta(Usuario usuario) {

        if (usuario == null || !usuario.isActivo()) {

            throw new SecurityException(
                "Debes iniciar sesión con un usuario activo."
            );
        }

        String rol = usuario.getRol() == null
                ? ""
                : usuario.getRol().trim().toUpperCase();

        if (!rol.equals("ADMINISTRADOR")
                && !rol.equals("ARCHIVISTA")
                && !rol.equals("CONSULTA")) {

            throw new SecurityException(
                "No tienes autorización para consultar documentos."
            );
        }

        this.usuario = usuario;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        construirInterfaz();
        cargarDocumentos();
    }

    // ==========================================
    // CONSTRUIR INTERFAZ
    // ==========================================

    private void construirInterfaz() {

        JPanel principal = new JPanel(
            new BorderLayout(12, 12)
        );

        principal.setBackground(Color.WHITE);

        principal.setBorder(
            BorderFactory.createEmptyBorder(
                15, 15, 15, 15
            )
        );

        JLabel titulo = new JLabel(
            "CONSULTA DE DOCUMENTOS",
            SwingConstants.CENTER
        );

        titulo.setFont(
            new Font("Serif", Font.BOLD, 23)
        );

        JLabel subtitulo = new JLabel(
            "Archivo Municipal de Villa Aldama",
            SwingConstants.CENTER
        );

        subtitulo.setFont(
            new Font("Serif", Font.PLAIN, 16)
        );

        JPanel encabezado = new JPanel(
            new GridLayout(2, 1, 5, 5)
        );

        encabezado.setBackground(Color.WHITE);

        encabezado.add(titulo);
        encabezado.add(subtitulo);

        JLabel lblUsuario = new JLabel(
            "Usuario: " + usuario.getNombre()
            + "    |    Rol: " + usuario.getRol()
        );

        // BUSCADOR

        txtBuscar = new JTextField(25);

        JButton btnBuscar = new JButton("Buscar");
        JButton btnActualizar = new JButton("Actualizar lista");

        JPanel panelBusqueda = new JPanel(
            new FlowLayout(FlowLayout.LEFT)
        );

        panelBusqueda.setBackground(Color.WHITE);

        panelBusqueda.add(
            new JLabel("Buscar documento:")
        );

        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnActualizar);

        JPanel panelSuperior = new JPanel(
            new BorderLayout(5, 8)
        );

        panelSuperior.setBackground(Color.WHITE);

        panelSuperior.add(
            encabezado,
            BorderLayout.NORTH
        );

        panelSuperior.add(
            lblUsuario,
            BorderLayout.CENTER
        );

        panelSuperior.add(
            panelBusqueda,
            BorderLayout.SOUTH
        );

        // ======================================
        // TABLA DE DOCUMENTOS
        // ======================================

        String[] columnas = {
            "ID documento",
            "Folio interno",
            "Nombre",
            "Descripción",
            "ID categoría",
            "ID tipo",
            "ID área",
            "Fecha emisión",
            "Fecha recepción",
            "Palabras clave",
            "Estado"
        };

        modeloTabla = new DefaultTableModel(
            columnas, 0
        ) {

            @Override
            public boolean isCellEditable(
                    int fila, int columna) {

                return false;
            }
        };

        tablaDocumentos = new JTable(modeloTabla);

        tablaDocumentos.setRowHeight(25);

        tablaDocumentos.setSelectionMode(
            ListSelectionModel.SINGLE_SELECTION
        );

        tablaDocumentos.setAutoResizeMode(
            JTable.AUTO_RESIZE_OFF
        );

        // Ocultar el ID sin eliminarlo del modelo.
        tablaDocumentos.getColumnModel()
                .getColumn(0).setMinWidth(0);

        tablaDocumentos.getColumnModel()
                .getColumn(0).setMaxWidth(0);

        tablaDocumentos.getColumnModel()
                .getColumn(0).setPreferredWidth(0);

        ordenador = new TableRowSorter<>(modeloTabla);

        tablaDocumentos.setRowSorter(ordenador);

        JScrollPane desplazamiento =
                new JScrollPane(tablaDocumentos);

        // ======================================
        // PIE DE PANTALLA
        // ======================================

        lblTotal = new JLabel(
            "Documentos encontrados: 0"
        );

        JButton btnActualizarPie =
                new JButton("Actualizar lista");

        btnVerPDF = new JButton("Ver PDF");

        JPanel pie = new JPanel(
            new BorderLayout()
        );

        pie.setBackground(Color.WHITE);

        pie.add(
            lblTotal,
            BorderLayout.WEST
        );

        JPanel botonesPie = new JPanel(
            new FlowLayout(FlowLayout.RIGHT)
        );

        botonesPie.setBackground(Color.WHITE);

        botonesPie.add(btnVerPDF);
        botonesPie.add(btnActualizarPie);

        pie.add(
            botonesPie,
            BorderLayout.EAST
        );

        // ======================================
        // EVENTOS
        // ======================================

        btnBuscar.addActionListener(
            e -> buscarDocumentos()
        );

        txtBuscar.addActionListener(
            e -> buscarDocumentos()
        );

        btnActualizar.addActionListener(
            e -> cargarDocumentos()
        );

        btnActualizarPie.addActionListener(
            e -> cargarDocumentos()
        );

        btnVerPDF.addActionListener(
            e -> verPDFSeleccionado()
        );

        // ======================================
        // INTEGRACIÓN
        // ======================================

        principal.add(
            panelSuperior,
            BorderLayout.NORTH
        );

        principal.add(
            desplazamiento,
            BorderLayout.CENTER
        );

        principal.add(
            pie,
            BorderLayout.SOUTH
        );

        add(principal, BorderLayout.CENTER);
    }

    // ==========================================
    // CARGAR DOCUMENTOS
    // ==========================================

    private void cargarDocumentos() {

        try {

            List<Documento> documentos =
                    documentoServicio.listarDocumentos();

            modeloTabla.setRowCount(0);

            for (Documento documento : documentos) {

                Object[] fila = {

                    documento.getIdDocumento(),
                    documento.getFolioInterno(),
                    documento.getNombre(),
                    documento.getDescripcion(),
                    documento.getIdCategoria(),
                    documento.getIdTipo(),
                    documento.getIdArea(),
                    convertirFecha(documento.getFechaEmision()),
                    convertirFecha(documento.getFechaRecepcion()),
                    documento.getPalabrasClave(),
                    documento.getEstado()
                };

                modeloTabla.addRow(fila);
            }

            ordenador.setRowFilter(null);

            txtBuscar.setText("");

            actualizarTotal();

            if (documentos.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Actualmente no existen documentos registrados.",
                    "Consulta documental",
                    JOptionPane.INFORMATION_MESSAGE
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible consultar los documentos.\n"
                + ex.getMessage(),
                "Error de consulta",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ==========================================
    // BUSCAR DOCUMENTOS
    // ==========================================

    private void buscarDocumentos() {

        String texto = txtBuscar.getText().trim();

        if (texto.isEmpty()) {

            ordenador.setRowFilter(null);

        } else {

            ordenador.setRowFilter(
                RowFilter.regexFilter(
                    "(?i)" + Pattern.quote(texto)
                )
            );
        }

        actualizarTotal();
    }

    // ==========================================
    // VISUALIZAR PDF DEL DOCUMENTO SELECCIONADO
    // ==========================================

    private void verPDFSeleccionado() {

        int filaVista = tablaDocumentos.getSelectedRow();

        if (filaVista == -1) {

            JOptionPane.showMessageDialog(
                this,
                "Primero selecciona un documento de la tabla.",
                "Documento no seleccionado",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        try {

            // Convertir la fila visible a la fila original.
            int filaModelo =
                    tablaDocumentos.convertRowIndexToModel(
                            filaVista
                    );

            // Recuperar el ID oculto del documento.
            long idDocumento = Long.parseLong(
                modeloTabla.getValueAt(filaModelo, 0).toString()
            );

            // Consultar los PDF relacionados.
            List<ArchivoDigital> archivos =
                    archivoDigitalDAO.listarPorDocumento(
                            idDocumento
                    );

            if (archivos.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "El documento seleccionado no tiene "
                    + "ningún archivo PDF asociado.",
                    "Sin archivo digital",
                    JOptionPane.INFORMATION_MESSAGE
                );

                return;
            }

            ArchivoDigital archivoSeleccionado;

            // Si hay varios PDF, permitir elegir uno.
            if (archivos.size() == 1) {

                archivoSeleccionado = archivos.get(0);

            } else {

                String[] opciones =
                        new String[archivos.size()];

                for (int i = 0; i < archivos.size(); i++) {

                    opciones[i] =
                            archivos.get(i).getNombreOriginal();
                }

                int opcion = JOptionPane.showOptionDialog(
                    this,
                    "Selecciona el archivo que deseas visualizar:",
                    "Archivos PDF asociados",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
                );

                if (opcion < 0) {
                    return;
                }

                archivoSeleccionado = archivos.get(opcion);
            }

            // Recuperar la ruta segura del PDF.
            Path rutaPDF = gestorArchivosPDF.obtenerRutaPDF(
                    archivoSeleccionado.getNombreAlmacenado()
            );

            if (!Files.isRegularFile(rutaPDF)) {

                JOptionPane.showMessageDialog(
                    this,
                    "El registro existe en MySQL, pero no se "
                    + "encontró el archivo PDF en la carpeta "
                    + "de almacenamiento.\n\n"
                    + rutaPDF,
                    "Archivo no encontrado",
                    JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            // Abrir el visualizador integrado.
            VisorPDF.abrir(
                SwingUtilities.getWindowAncestor(this),
                rutaPDF.toFile()
            );

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible consultar el archivo PDF:\n"
                + ex.getMessage(),
                "Error de base de datos",
                JOptionPane.ERROR_MESSAGE
            );

        } catch (IOException ex) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible abrir el archivo PDF:\n"
                + ex.getMessage(),
                "Error al abrir PDF",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ==========================================
    // ACTUALIZAR TOTAL
    // ==========================================

    private void actualizarTotal() {

        lblTotal.setText(
            "Documentos encontrados: "
            + tablaDocumentos.getRowCount()
        );
    }

    // ==========================================
    // CONVERTIR FECHA
    // ==========================================

    private String convertirFecha(LocalDate fecha) {

        if (fecha == null) {
            return "";
        }

        return fecha.toString();
    }
}
