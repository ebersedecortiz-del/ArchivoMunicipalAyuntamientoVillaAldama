
package vista;

import modelo.Usuario; 
import servicio.AutenticacionServicio;
import servicio.ActividadServicio;

import javax.swing.*;
import javax.swing.border.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.function.Consumer;

public class VentanaLogin extends JPanel {

    private static final Color GUINDA = new Color(112, 0, 25);
    private static final Color DORADO = new Color(184, 154, 90);
    private static final Color MARFIL = new Color(247, 242, 234);
    private static final Color TEXTO = new Color(65, 59, 56);
    private static final Color GRIS = new Color(125, 119, 114);
    private static final Color BLANCO = Color.WHITE;

    private final JTextField txtUsuario;
    private final JPasswordField txtContrasena;
    private final JButton btnIngresar;
    private final JButton btnMostrarContrasena;

    private final AutenticacionServicio autenticacion;
    private final Consumer<Usuario> alAutenticar;
    private final ActividadServicio actividadServicio;

    private final char caracterContrasena;
    private boolean contrasenaVisible = false;

    // Constructor integrado con VentanaAplicacion
    public VentanaLogin(Consumer<Usuario> alAutenticar) {

    	autenticacion = new AutenticacionServicio();
    	actividadServicio = new ActividadServicio();
    	this.alAutenticar = alAutenticar;

        setLayout(new BorderLayout());
        setBackground(MARFIL);

        caracterContrasena = new JPasswordField().getEchoChar();

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(MARFIL);

        // ENCABEZADO INSTITUCIONAL
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(GUINDA);
        encabezado.setBorder(
            BorderFactory.createEmptyBorder(18, 25, 18, 25)
        );

        JPanel identidad = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 12, 0)
        );
        identidad.setOpaque(false);

        JLabel escudo = crearEscudo(58, 68);

        JPanel textosInstitucionales = new JPanel(
            new GridLayout(2, 1, 0, 4)
        );
        textosInstitucionales.setOpaque(false);

        JLabel nombreAyuntamiento = new JLabel(
            "H. AYUNTAMIENTO DE VILLA ALDAMA"
        );
        nombreAyuntamiento.setForeground(BLANCO);
        nombreAyuntamiento.setFont(
            new Font("Times New Roman", Font.BOLD, 16)
        );

        JLabel nombreSistema = new JLabel("ARCHIVO MUNICIPAL");
        nombreSistema.setForeground(new Color(225, 205, 164));
        nombreSistema.setFont(
            new Font("Times New Roman", Font.PLAIN, 14)
        );

        textosInstitucionales.add(nombreAyuntamiento);
        textosInstitucionales.add(nombreSistema);

        identidad.add(escudo);
        identidad.add(textosInstitucionales);
        encabezado.add(identidad, BorderLayout.CENTER);

        JPanel lineaDorada = new JPanel();
        lineaDorada.setBackground(DORADO);
        lineaDorada.setPreferredSize(new Dimension(10, 3));

        JPanel parteSuperior = new JPanel(new BorderLayout());
        parteSuperior.add(encabezado, BorderLayout.CENTER);
        parteSuperior.add(lineaDorada, BorderLayout.SOUTH);

        // CONTENIDO CENTRAL
        JPanel centro = new JPanel(new GridBagLayout());
        centro.setBackground(MARFIL);
        centro.setBorder(
            BorderFactory.createEmptyBorder(20, 35, 20, 35)
        );

        JPanel tarjeta = new JPanel(new BorderLayout(0, 18));
        tarjeta.setBackground(BLANCO);
        tarjeta.setBorder(new CompoundBorder(
            new LineBorder(new Color(225, 218, 207), 1, true),
            BorderFactory.createEmptyBorder(25, 32, 25, 32)
        ));
        tarjeta.setPreferredSize(new Dimension(390, 465));

        // ICONO Y TITULOS
        JPanel panelUsuario = new JPanel(
            new GridLayout(2, 1, 0, 8)
        );
        panelUsuario.setOpaque(false);

        JLabel iconoUsuario = new JLabel(
            new IconoUsuario(78),
            SwingConstants.CENTER
        );

        JLabel titulo = new JLabel(
            "Bienvenido",
            SwingConstants.CENTER
        );
        titulo.setFont(
            new Font("Times New Roman", Font.BOLD, 25)
        );
        titulo.setForeground(GUINDA);

        JLabel subtitulo = new JLabel(
            "Ingrese sus credenciales para continuar",
            SwingConstants.CENTER
        );
        subtitulo.setFont(
            new Font("Times New Roman", Font.PLAIN, 14)
        );
        subtitulo.setForeground(GRIS);

        JPanel textosAcceso = new JPanel(
            new GridLayout(2, 1, 0, 5)
        );
        textosAcceso.setOpaque(false);
        textosAcceso.add(titulo);
        textosAcceso.add(subtitulo);

        panelUsuario.add(iconoUsuario);
        panelUsuario.add(textosAcceso);

        // FORMULARIO
        JPanel formulario = new JPanel();
        formulario.setOpaque(false);
        formulario.setLayout(
            new BoxLayout(formulario, BoxLayout.Y_AXIS)
        );

        JLabel lblUsuario = crearEtiqueta("Nombre de usuario");
        lblUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);

        txtUsuario = new JTextField();
        configurarCampo(txtUsuario);

        JLabel lblContrasena = crearEtiqueta("Contraseña");
        lblContrasena.setAlignmentX(Component.CENTER_ALIGNMENT);

        txtContrasena = new JPasswordField();
        configurarCampo(txtContrasena);

        JPanel panelContrasena = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 0, 0)
        );
        panelContrasena.setOpaque(false);
        panelContrasena.add(txtContrasena);

        // BOTON MOSTRAR / OCULTAR
        btnMostrarContrasena = new JButton("Mostrar contraseña");
        btnMostrarContrasena.setFont(
            new Font("Times New Roman", Font.PLAIN, 12)
        );
        btnMostrarContrasena.setForeground(GUINDA);
        btnMostrarContrasena.setBackground(BLANCO);
        btnMostrarContrasena.setBorderPainted(false);
        btnMostrarContrasena.setFocusPainted(false);
        btnMostrarContrasena.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );
        btnMostrarContrasena.addActionListener(
            e -> alternarVisibilidadContrasena()
        );

        JPanel panelMostrar = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 0, 0)
        );
        panelMostrar.setOpaque(false);
        panelMostrar.add(btnMostrarContrasena);

        // ORGANIZACION VERTICAL
        formulario.add(lblUsuario);
        formulario.add(Box.createVerticalStrut(7));
        formulario.add(txtUsuario);
        formulario.add(Box.createVerticalStrut(18));
        formulario.add(lblContrasena);
        formulario.add(Box.createVerticalStrut(7));
        formulario.add(panelContrasena);
        formulario.add(Box.createVerticalStrut(5));
        formulario.add(panelMostrar);

        // BOTON DE ACCESO
        btnIngresar = new JButton("INICIAR SESIÓN");
        btnIngresar.setFont(
            new Font("Times New Roman", Font.BOLD, 16)
        );
        btnIngresar.setForeground(BLANCO);
        btnIngresar.setBackground(GUINDA);
        btnIngresar.setFocusPainted(false);
        btnIngresar.setBorder(
            BorderFactory.createCompoundBorder(
                new LineBorder(DORADO, 1, true),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
            )
        );
        btnIngresar.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );
        btnIngresar.setPreferredSize(new Dimension(300, 48));
        btnIngresar.addActionListener(e -> iniciarSesion());

        txtContrasena.addActionListener(e -> iniciarSesion());
        txtUsuario.addActionListener(
            e -> txtContrasena.requestFocusInWindow()
        );

        JPanel panelBoton = new JPanel(new BorderLayout());
        panelBoton.setOpaque(false);
        panelBoton.add(btnIngresar, BorderLayout.CENTER);

        // CONTENIDO DE LA TARJETA
        JPanel contenidoTarjeta = new JPanel(
            new BorderLayout(0, 15)
        );
        contenidoTarjeta.setOpaque(false);
        contenidoTarjeta.add(panelUsuario, BorderLayout.NORTH);
        contenidoTarjeta.add(formulario, BorderLayout.CENTER);
        contenidoTarjeta.add(panelBoton, BorderLayout.SOUTH);

        JLabel aviso = new JLabel(
            "Acceso exclusivo para personal autorizado",
            SwingConstants.CENTER
        );
        aviso.setFont(
            new Font("Times New Roman", Font.ITALIC, 12)
        );
        aviso.setForeground(GRIS);

        JPanel parteInferior = new JPanel(
            new BorderLayout(0, 10)
        );
        parteInferior.setOpaque(false);
        parteInferior.add(contenidoTarjeta, BorderLayout.CENTER);
        parteInferior.add(aviso, BorderLayout.SOUTH);

        tarjeta.add(parteInferior, BorderLayout.CENTER);
        centro.add(tarjeta);

        // PIE INSTITUCIONAL
        JPanel pie = new JPanel(new BorderLayout());
        pie.setBackground(MARFIL);
        pie.setBorder(
            BorderFactory.createEmptyBorder(8, 10, 15, 10)
        );

        JLabel sistema = new JLabel(
            "Sistema Integral de Gestión Documental y Archivo Municipal",
            SwingConstants.CENTER
        );
        sistema.setFont(
            new Font("Times New Roman", Font.PLAIN, 12)
        );
        sistema.setForeground(GRIS);

        pie.add(sistema, BorderLayout.CENTER);

        // INTEGRACION GENERAL
        principal.add(parteSuperior, BorderLayout.NORTH);
        principal.add(centro, BorderLayout.CENTER);
        principal.add(pie, BorderLayout.SOUTH);

        add(principal, BorderLayout.CENTER);

        // El contenedor principal controla el comportamiento
        // del botón predeterminado.
        SwingUtilities.invokeLater(() -> {
            if (SwingUtilities.getRootPane(this) != null) {
                SwingUtilities.getRootPane(this)
                    .setDefaultButton(btnIngresar);
            }
        });
    }

    private JLabel crearEtiqueta(String texto) {

        JLabel etiqueta = new JLabel(texto);
        etiqueta.setFont(
            new Font("Times New Roman", Font.BOLD, 14)
        );
        etiqueta.setForeground(TEXTO);

        return etiqueta;
    }

    private void configurarCampo(JTextField campo) {

        campo.setFont(
            new Font("Times New Roman", Font.PLAIN, 15)
        );
        campo.setForeground(TEXTO);
        campo.setBackground(BLANCO);

        campo.setPreferredSize(new Dimension(300, 40));
        campo.setMinimumSize(new Dimension(300, 40));
        campo.setMaximumSize(new Dimension(300, 40));

        campo.setBorder(new CompoundBorder(
            new LineBorder(new Color(210, 203, 194), 1, true),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));

        campo.setAlignmentX(Component.CENTER_ALIGNMENT);
    }

    private JLabel crearEscudo(int ancho, int alto) {

        JLabel etiqueta = new JLabel();
        etiqueta.setPreferredSize(new Dimension(ancho, alto));
        etiqueta.setHorizontalAlignment(SwingConstants.CENTER);

        java.net.URL recurso = getClass().getResource(
            "/recursos/escudo_villa_aldama.png"
        );

        if (recurso != null) {

            try {

                Image imagen = ImageIO.read(recurso);

                if (imagen != null) {

                    Image escalada = imagen.getScaledInstance(
                        ancho, alto, Image.SCALE_SMOOTH
                    );

                    etiqueta.setIcon(new ImageIcon(escalada));
                }

            } catch (java.io.IOException ex) {

                System.err.println(
                    "No se pudo cargar el escudo: " + ex.getMessage()
                );
            }

        } else {

            etiqueta.setText("ESCUDO");
            etiqueta.setForeground(BLANCO);
            etiqueta.setFont(
                new Font("Times New Roman", Font.BOLD, 10)
            );
        }

        return etiqueta;
    }

    private void alternarVisibilidadContrasena() {

        if (contrasenaVisible) {

            txtContrasena.setEchoChar(caracterContrasena);
            btnMostrarContrasena.setText("Mostrar contraseña");
            contrasenaVisible = false;

        } else {

            txtContrasena.setEchoChar((char) 0);
            btnMostrarContrasena.setText("Ocultar contraseña");
            contrasenaVisible = true;
        }

        txtContrasena.requestFocusInWindow();
    }

    // AUTENTICACION

private void iniciarSesion() {

    String nombreUsuario = txtUsuario.getText().trim();
    char[] contrasena = txtContrasena.getPassword();

    if (nombreUsuario.isEmpty() || contrasena.length == 0) {

        Arrays.fill(contrasena, '\0');

        JOptionPane.showMessageDialog(
            this,
            "Escribe tu nombre de usuario y contraseña.",
            "Datos obligatorios",
            JOptionPane.WARNING_MESSAGE
        );

        return;
    }

    btnIngresar.setEnabled(false);

    try {

        Usuario usuario = autenticacion.autenticar(
            nombreUsuario,
            contrasena
        );

        if (usuario == null) {

            // Registrar intento de acceso rechazado.
            try {

                actividadServicio.registrarActividad(
                    null,
                    "SESIONES",
                    null,
                    "ACCESO_DENEGADO",
                    "Intento de inicio de sesión rechazado."
                );

            } catch (SQLException errorBitacora) {

                System.err.println(
                    "No se pudo registrar el intento de acceso."
                );

                errorBitacora.printStackTrace();
            }

            JOptionPane.showMessageDialog(
                this,
                "Usuario o contraseña incorrectos, "
                    + "o cuenta inactiva.",
                "Acceso denegado",
                JOptionPane.ERROR_MESSAGE
            );

            txtContrasena.setText("");
            txtContrasena.requestFocusInWindow();

        } else {

            // Registrar el inicio de sesión exitoso.
            try {

                actividadServicio.registrarActividad(
                    usuario.getIdUsuario(),
                    "SESIONES",
                    null,
                    "INICIO_SESION",
                    "Inicio de sesión exitoso."
                );

                txtContrasena.setText("");

                // Comunicar el usuario autenticado a VentanaAplicacion.
                if (alAutenticar != null) {
                    alAutenticar.accept(usuario);
                }

            } catch (SQLException errorBitacora) {

                JOptionPane.showMessageDialog(
                    this,
                    "Las credenciales son correctas, pero no fue "
                        + "posible registrar el inicio de sesión "
                        + "en la bitácora.\n"
                        + "Por seguridad, no se abrirá la sesión.",
                    "Error de registro de actividad",
                    JOptionPane.ERROR_MESSAGE
                );

                errorBitacora.printStackTrace();
            }
        }

    } catch (SQLException ex) {

        JOptionPane.showMessageDialog(
            this,
            "No fue posible consultar la base de datos.\n"
                + "Verifica la conexión MySQL.",
            "Error de conexión",
            JOptionPane.ERROR_MESSAGE
        );

        ex.printStackTrace();

    } finally {

        Arrays.fill(contrasena, '\0');
        btnIngresar.setEnabled(true);
    }
}

    // ICONO CIRCULAR DE USUARIO
    private static class IconoUsuario implements Icon {

        private final int tamano;

        public IconoUsuario(int tamano) {
            this.tamano = tamano;
        }

        @Override
        public int getIconWidth() {
            return tamano;
        }

        @Override
        public int getIconHeight() {
            return tamano;
        }

        @Override
        public void paintIcon(
            Component componente,
            Graphics g,
            int x,
            int y
        ) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setColor(new Color(247, 242, 234));
            g2.fill(new Ellipse2D.Double(
                x, y, tamano, tamano
            ));

            g2.setColor(GUINDA);

            // CABEZA
            g2.fill(new Ellipse2D.Double(
                x + tamano * 0.37,
                y + tamano * 0.20,
                tamano * 0.26,
                tamano * 0.26
            ));

            // CUERPO
            g2.fill(new Ellipse2D.Double(
                x + tamano * 0.19,
                y + tamano * 0.54,
                tamano * 0.62,
                tamano * 0.37
            ));

            // BORDE DORADO
            g2.setColor(DORADO);
            g2.setStroke(new BasicStroke(2.5f));

            g2.draw(new Ellipse2D.Double(
                x + 1,
                y + 1,
                tamano - 2,
                tamano - 2
            ));

            g2.dispose();
        }
    }
}
