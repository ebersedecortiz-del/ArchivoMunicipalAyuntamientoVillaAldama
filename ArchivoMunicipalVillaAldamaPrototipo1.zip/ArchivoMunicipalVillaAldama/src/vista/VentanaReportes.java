
package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerDateModel;
import javax.swing.table.DefaultTableModel;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;

import util.GeneradorReportePDF;

import dao.ReporteDAO;
import dao.UsuarioDAO;
import modelo.ReporteActividad;
import modelo.Usuario;

public class VentanaReportes extends JPanel {

    private static final long serialVersionUID = 1L;

    // Colores institucionales
    private final Color GUINDA = new Color(138, 22, 48);
    private final Color GUINDA_OSCURO = new Color(105, 15, 36);
    private final Color DORADO = new Color(190, 155, 85);
    private final Color MARFIL = new Color(250, 248, 242);
    private final Color BLANCO = Color.WHITE;
    private final Color TEXTO = new Color(55, 55, 55);
    private final Color GRIS = new Color(230, 230, 230);

    // Acceso a datos
    private final ReporteDAO reporteDAO = new ReporteDAO();
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    // Usuario de la sesión
    private final Usuario usuarioActual;

    // Filtros
    private JComboBox<String> cmbTipoReporte;
    private JComboBox<String> cmbPeriodo;
    private JComboBox<String> cmbUsuarios;

    private JSpinner spnFechaInicio;
    private JSpinner spnFechaFin;

    // Botones
 
    private JButton btnConsultar;
    private JButton btnLimpiar;
    private JButton btnExportarPDF;

    // Tabla
    private JTable tablaReportes;
    private DefaultTableModel modeloTabla;

    // Estadísticas
    private JLabel lblTotalActividades;
    private JLabel lblUsuariosInvolucrados;
    private JLabel lblModulosRegistrados;

    // Usuarios de la base de datos
    private List<Usuario> usuarios = new ArrayList<>();
 // Actividades correspondientes a la consulta actual
    private List<ReporteActividad> actividadesActuales = new ArrayList<>();
    
    // Formato de fecha
    private final DateTimeFormatter formatoFecha =
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public VentanaReportes(Usuario usuarioActual) {

        this.usuarioActual = usuarioActual;

        if (usuarioActual == null
                || usuarioActual.getRol() == null
                || !usuarioActual.getRol().equalsIgnoreCase("ADMINISTRADOR")) {

            throw new IllegalArgumentException(
                "El módulo de reportes es exclusivo del administrador."
            );
        }

        setLayout(new BorderLayout(15, 15));
        setBackground(MARFIL);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        construirInterfaz();

        cargarUsuarios();

        actualizarControlesFecha();

        consultarActividades();
    }

    // =====================================================
    // CONSTRUCCIÓN GENERAL
    // =====================================================


private void construirInterfaz() {

    // Panel que contiene toda la interfaz
    JPanel contenidoGeneral = new JPanel(new BorderLayout(15, 15));

    contenidoGeneral.setBackground(MARFIL);

    contenidoGeneral.setBorder(
        BorderFactory.createEmptyBorder(20, 20, 20, 20)
    );

    // Encabezado institucional
    contenidoGeneral.add(
        crearEncabezado(),
        BorderLayout.NORTH
    );

    // Panel central
    JPanel centro = new JPanel(new BorderLayout(12, 12));

    centro.setBackground(MARFIL);

    centro.add(
        crearPanelFiltros(),
        BorderLayout.NORTH
    );

    JPanel contenido = new JPanel(new BorderLayout(10, 10));

    contenido.setBackground(MARFIL);

    contenido.add(
        crearPanelEstadisticas(),
        BorderLayout.NORTH
    );

    contenido.add(
        crearPanelResultados(),
        BorderLayout.CENTER
    );

    centro.add(
        contenido,
        BorderLayout.CENTER
    );

    contenidoGeneral.add(
        centro,
        BorderLayout.CENTER
    );

    // Barra de desplazamiento general
    JScrollPane scrollGeneral = new JScrollPane(
        contenidoGeneral,
        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    scrollGeneral.setBorder(
        BorderFactory.createEmptyBorder()
    );

    scrollGeneral.getVerticalScrollBar().setUnitIncrement(20);

    // Se agrega toda la interfaz desplazable
    add(scrollGeneral, BorderLayout.CENTER);
}


    private JPanel crearEncabezado() {

        JPanel panel = new JPanel(new BorderLayout());

        panel.setBackground(GUINDA);

        panel.setBorder(
            BorderFactory.createEmptyBorder(18, 20, 18, 20)
        );

        JLabel titulo = new JLabel("CENTRO DE REPORTES");

        titulo.setFont(
            new Font("Times New Roman", Font.BOLD, 25)
        );

        titulo.setForeground(BLANCO);

        JLabel subtitulo = new JLabel(
            "Sistema Integral de Gestión Documental y Archivo Municipal"
        );

        subtitulo.setFont(
            new Font("Times New Roman", Font.PLAIN, 14)
        );

        subtitulo.setForeground(BLANCO);

        JPanel textos = new JPanel(new BorderLayout(0, 5));

        textos.setOpaque(false);

        textos.add(titulo, BorderLayout.NORTH);
        textos.add(subtitulo, BorderLayout.CENTER);

        panel.add(textos, BorderLayout.CENTER);

        return panel;
    }

    // =====================================================
    // FILTROS
    // =====================================================

    private JPanel crearPanelFiltros() {

        JPanel panel = new JPanel(new GridBagLayout());

        panel.setBackground(BLANCO);

        panel.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GRIS),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
            )
        );

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(5, 7, 5, 7);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Tipo de reporte
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.30;

        panel.add(crearEtiqueta("Tipo de reporte"), gbc);

        // Periodo
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0.35;

        panel.add(crearEtiqueta("Periodo"), gbc);

        // Usuario
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.weightx = 0.35;

        panel.add(crearEtiqueta("Usuario"), gbc);

        cmbTipoReporte = new JComboBox<>(
            new String[] {
                "General de actividades",
                "Actividad por usuario"
            }
        );

        cmbPeriodo = new JComboBox<>(
            new String[] {
                "Todo el historial",
                "Últimos 7 días",
                "Mes actual",
                "Trimestre actual",
                "Semestre actual",
                "Año actual",
                "Personalizado"
            }
        );

        cmbUsuarios = new JComboBox<>();

        cmbTipoReporte.setFont(
            new Font("Times New Roman", Font.PLAIN, 14)
        );

        cmbPeriodo.setFont(
            new Font("Times New Roman", Font.PLAIN, 14)
        );

        cmbUsuarios.setFont(
            new Font("Times New Roman", Font.PLAIN, 14)
        );

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(cmbTipoReporte, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(cmbPeriodo, gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        panel.add(cmbUsuarios, gbc);

        // Fechas personalizadas
        gbc.gridx = 0;
        gbc.gridy = 2;

        panel.add(crearEtiqueta("Fecha inicial"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;

        panel.add(crearEtiqueta("Fecha final"), gbc);

        spnFechaInicio = crearSelectorFecha();
        spnFechaFin = crearSelectorFecha();

        gbc.gridx = 0;
        gbc.gridy = 3;

        panel.add(spnFechaInicio, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;

        panel.add(spnFechaFin, gbc);


     // Botones
        btnConsultar = crearBoton("Consultar", GUINDA);
        btnLimpiar = crearBoton("Limpiar", GUINDA_OSCURO);
        btnExportarPDF = crearBoton("Exportar PDF", DORADO);

        // Panel de botones
        JPanel botones = new JPanel(
            new FlowLayout(FlowLayout.RIGHT)
        );

        botones.setBackground(BLANCO);

        botones.add(btnExportarPDF);
        botones.add(btnConsultar);
        botones.add(btnLimpiar);

        // Inicialmente se deshabilita hasta tener resultados
        btnExportarPDF.setEnabled(false);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 3;
        gbc.weightx = 1;

        panel.add(botones, gbc);

        // Eventos
        cmbPeriodo.addActionListener(e -> actualizarControlesFecha());

        cmbTipoReporte.addActionListener(e -> actualizarFiltroUsuario());

        btnConsultar.addActionListener(e -> consultarActividades());

        
        btnLimpiar.addActionListener(e -> limpiarFiltros());
        
        btnExportarPDF.addActionListener(e -> exportarReportePDF());

        actualizarFiltroUsuario();

        return panel;
    }

    private JSpinner crearSelectorFecha() {

        JSpinner spinner = new JSpinner(
            new SpinnerDateModel(
                new Date(),
                null,
                null,
                Calendar.DAY_OF_MONTH
            )
        );

        JSpinner.DateEditor editor =
            new JSpinner.DateEditor(spinner, "dd/MM/yyyy");

        spinner.setEditor(editor);

        spinner.setPreferredSize(
            new Dimension(180, 28)
        );

        return spinner;
    }

    private void actualizarControlesFecha() {

        if (spnFechaInicio == null || spnFechaFin == null) {
            return;
        }

        boolean personalizado =
            "Personalizado".equals(cmbPeriodo.getSelectedItem());

        spnFechaInicio.setEnabled(personalizado);
        spnFechaFin.setEnabled(personalizado);
    }

    private void actualizarFiltroUsuario() {

        if (cmbUsuarios == null || cmbTipoReporte == null) {
            return;
        }

        boolean individual =
            "Actividad por usuario".equals(
                cmbTipoReporte.getSelectedItem()
            );

        cmbUsuarios.setEnabled(individual);
    }

    // =====================================================
    // ESTADÍSTICAS
    // =====================================================

    private JPanel crearPanelEstadisticas() {

        JPanel panel = new JPanel(new GridBagLayout());

        panel.setBackground(MARFIL);

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.insets = new Insets(4, 4, 4, 4);

        lblTotalActividades = new JLabel("0", JLabel.CENTER);
        lblUsuariosInvolucrados = new JLabel("0", JLabel.CENTER);
        lblModulosRegistrados = new JLabel("0", JLabel.CENTER);

        gbc.gridx = 0;
        gbc.gridy = 0;

        panel.add(
            crearTarjetaEstadistica(
                "ACTIVIDADES ENCONTRADAS",
                lblTotalActividades
            ),
            gbc
        );

        gbc.gridx = 1;

        panel.add(
            crearTarjetaEstadistica(
                "USUARIOS INVOLUCRADOS",
                lblUsuariosInvolucrados
            ),
            gbc
        );

        gbc.gridx = 2;

        panel.add(
            crearTarjetaEstadistica(
                "MÓDULOS REGISTRADOS",
                lblModulosRegistrados
            ),
            gbc
        );

        return panel;
    }

    private JPanel crearTarjetaEstadistica(
            String titulo,
            JLabel valor) {

        JPanel tarjeta = new JPanel(new BorderLayout(5, 8));

        tarjeta.setBackground(BLANCO);

        tarjeta.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(DORADO),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
            )
        );

        JLabel etiqueta = new JLabel(titulo, JLabel.CENTER);

        etiqueta.setFont(
            new Font("Times New Roman", Font.BOLD, 13)
        );

        etiqueta.setForeground(TEXTO);

        valor.setFont(
            new Font("Times New Roman", Font.BOLD, 25)
        );

        valor.setForeground(GUINDA);

        tarjeta.add(etiqueta, BorderLayout.NORTH);
        tarjeta.add(valor, BorderLayout.CENTER);

        return tarjeta;
    }

    private void actualizarEstadisticas(
            List<ReporteActividad> actividades) {

        Set<Long> usuariosUnicos = new HashSet<>();
        Set<String> modulosUnicos = new HashSet<>();

        for (ReporteActividad actividad : actividades) {

            if (actividad.getIdUsuario() != null) {
                usuariosUnicos.add(actividad.getIdUsuario());
            }

            if (actividad.getEntidad() != null) {
                modulosUnicos.add(actividad.getEntidad());
            }
        }

        lblTotalActividades.setText(
            String.valueOf(actividades.size())
        );

        lblUsuariosInvolucrados.setText(
            String.valueOf(usuariosUnicos.size())
        );

        lblModulosRegistrados.setText(
            String.valueOf(modulosUnicos.size())
        );
    }

    // =====================================================
    // TABLA DE RESULTADOS
    // =====================================================

    private JPanel crearPanelResultados() {

        JPanel panel = new JPanel(new BorderLayout(10, 10));

        panel.setBackground(BLANCO);

        panel.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(GRIS),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)
            )
        );

        JLabel titulo = crearEtiqueta("Historial de actividades");

        panel.add(titulo, BorderLayout.NORTH);

        String[] columnas = {
            "ID",
            "Usuario",
            "Cuenta",
            "Rol",
            "Módulo",
            "Acción",
            "ID registro",
            "Detalle",
            "Fecha y hora"
        };

        modeloTabla = new DefaultTableModel(columnas, 0) {

            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        tablaReportes = new JTable(modeloTabla);

        tablaReportes.setFont(
            new Font("Times New Roman", Font.PLAIN, 13)
        );

        tablaReportes.setRowHeight(25);
        tablaReportes.setAutoResizeMode(
            JTable.AUTO_RESIZE_OFF
        );

        tablaReportes.setAutoCreateRowSorter(true);

        tablaReportes.getTableHeader().setFont(
            new Font("Times New Roman", Font.BOLD, 13)
        );

        tablaReportes.getTableHeader().setBackground(GUINDA);
        tablaReportes.getTableHeader().setForeground(BLANCO);

        int[] anchos = {
            55, 130, 110, 110, 110, 160, 90, 300, 155
        };

        for (int i = 0; i < anchos.length; i++) {

            tablaReportes.getColumnModel()
                .getColumn(i)
                .setPreferredWidth(anchos[i]);
        }

        JScrollPane scrollTabla = new JScrollPane(tablaReportes);

        panel.add(scrollTabla, BorderLayout.CENTER);

        return panel;
    }

    // =====================================================
    // CARGA DE USUARIOS
    // =====================================================

    private void cargarUsuarios() {

        try {

            usuarios = usuarioDAO.listarTodos();

            cmbUsuarios.removeAllItems();

            cmbUsuarios.addItem("Selecciona un usuario");

            for (Usuario usuario : usuarios) {

                String texto = usuario.getNombre()
                    + " - "
                    + usuario.getRol()
                    + " - "
                    + usuario.getNombreUsuario();

                cmbUsuarios.addItem(texto);
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible cargar los usuarios.\n"
                + e.getMessage(),
                "Error de consulta",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =====================================================
    // CONSULTA PRINCIPAL
    // =====================================================

    private void consultarActividades() {

        try {

            LocalDateTime fechaInicio = null;
            LocalDateTime fechaFin = null;

            String periodo = (String) cmbPeriodo.getSelectedItem();

            LocalDate hoy = LocalDate.now();

            switch (periodo) {

                case "Últimos 7 días":

                    fechaInicio = hoy.minusDays(6).atStartOfDay();

                    fechaFin = hoy.atTime(23, 59, 59);

                    break;

                case "Mes actual":

                    fechaInicio = hoy
                        .with(TemporalAdjusters.firstDayOfMonth())
                        .atStartOfDay();

                    fechaFin = hoy.atTime(23, 59, 59);

                    break;

                case "Trimestre actual":

                    int mesInicioTrimestre =
                        ((hoy.getMonthValue() - 1) / 3) * 3 + 1;

                    fechaInicio = LocalDate.of(
                        hoy.getYear(),
                        mesInicioTrimestre,
                        1
                    ).atStartOfDay();

                    fechaFin = hoy.atTime(23, 59, 59);

                    break;

                case "Semestre actual":

                    int mesInicioSemestre =
                        hoy.getMonthValue() <= 6 ? 1 : 7;

                    fechaInicio = LocalDate.of(
                        hoy.getYear(),
                        mesInicioSemestre,
                        1
                    ).atStartOfDay();

                    fechaFin = hoy.atTime(23, 59, 59);

                    break;

                case "Año actual":

                    fechaInicio = LocalDate.of(
                        hoy.getYear(),
                        1,
                        1
                    ).atStartOfDay();

                    fechaFin = hoy.atTime(23, 59, 59);

                    break;

                case "Personalizado":

                    LocalDate inicio = convertirFecha(
                        (Date) spnFechaInicio.getValue()
                    );

                    LocalDate fin = convertirFecha(
                        (Date) spnFechaFin.getValue()
                    );

                    if (inicio.isAfter(fin)) {

                        JOptionPane.showMessageDialog(
                            this,
                            "La fecha inicial no puede ser posterior "
                            + "a la fecha final.",
                            "Fechas no válidas",
                            JOptionPane.WARNING_MESSAGE
                        );

                        return;
                    }

                    fechaInicio = inicio.atStartOfDay();

                    fechaFin = fin.atTime(LocalTime.of(23, 59, 59));

                    break;

                case "Todo el historial":

                    fechaInicio = null;
                    fechaFin = null;

                    break;

                default:

                    fechaInicio = null;
                    fechaFin = null;

                    break;
            }

            Long idUsuario = null;

            boolean reporteIndividual =
                "Actividad por usuario".equals(
                    cmbTipoReporte.getSelectedItem()
                );

            if (reporteIndividual) {

                int indice = cmbUsuarios.getSelectedIndex();

                if (indice <= 0) {

                    JOptionPane.showMessageDialog(
                        this,
                        "Selecciona un usuario para generar "
                        + "el reporte individual.",
                        "Usuario requerido",
                        JOptionPane.WARNING_MESSAGE
                    );

                    return;
                }

                idUsuario = usuarios.get(indice - 1).getIdUsuario();
            }

            List<ReporteActividad> actividades =
                reporteDAO.listarActividades(
                    fechaInicio,
                    fechaFin,
                    idUsuario
                );

            modeloTabla.setRowCount(0);

            List<ReporteActividad> actividadesOperativas =
                new ArrayList<>();

            for (ReporteActividad actividad : actividades) {

                // Excluir eventos técnicos de prueba
                if (actividad.getEntidad() != null
                        && actividad.getEntidad().equalsIgnoreCase(
                            "PRUEBA_TECNICA"
                        )) {

                    continue;
                }

                actividadesOperativas.add(actividad);

                String nombre = actividad.getNombreUsuario() != null
                    ? actividad.getNombreUsuario()
                    : "Sin usuario asociado";

                String cuenta = actividad.getNombreCuenta() != null
                    ? actividad.getNombreCuenta()
                    : "No disponible";

                String rol = actividad.getRol() != null
                    ? actividad.getRol()
                    : "No disponible";

                String entidad = actividad.getEntidad() != null
                    ? actividad.getEntidad()
                    : "No disponible";

                String accion = actividad.getAccion() != null
                    ? actividad.getAccion()
                    : "No disponible";

                String idRegistro = actividad.getIdRegistro() != null
                    ? String.valueOf(actividad.getIdRegistro())
                    : "—";

                String detalle = actividad.getDetalle() != null
                    ? actividad.getDetalle()
                    : "Sin detalle";

                String fecha = actividad.getFechaEvento() != null
                    ? actividad.getFechaEvento().format(formatoFecha)
                    : "No disponible";

                modeloTabla.addRow(new Object[] {
                    actividad.getIdEvento(),
                    nombre,
                    cuenta,
                    rol,
                    entidad,
                    accion,
                    idRegistro,
                    detalle,
                    fecha
                });
            }

            actualizarEstadisticas(actividadesOperativas);
            
         // Guardar los resultados actuales para la exportación PDF
            actividadesActuales = new ArrayList<>(actividadesOperativas);

            // Habilitar exportación únicamente cuando existan resultados
            btnExportarPDF.setEnabled(!actividadesActuales.isEmpty());

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                this,
                "No fue posible consultar las actividades.\n"
                + e.getMessage(),
                "Error de consulta",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =====================================================
    // CONVERSIÓN Y LIMPIEZA
    // =====================================================

    private LocalDate convertirFecha(Date fecha) {

        return fecha.toInstant()
            .atZone(ZoneId.systemDefault())
            .toLocalDate();
    }

    private void limpiarFiltros() {

        cmbTipoReporte.setSelectedIndex(0);
        cmbPeriodo.setSelectedIndex(0);

        if (cmbUsuarios.getItemCount() > 0) {
            cmbUsuarios.setSelectedIndex(0);
        }

        spnFechaInicio.setValue(new Date());
        spnFechaFin.setValue(new Date());

        actualizarControlesFecha();
        actualizarFiltroUsuario();

        consultarActividades();
    }

    // =====================================================
    // COMPONENTES AUXILIARES
    // =====================================================

    private JLabel crearEtiqueta(String texto) {

        JLabel etiqueta = new JLabel(texto);

        etiqueta.setFont(
            new Font("Times New Roman", Font.BOLD, 15)
        );

        etiqueta.setForeground(TEXTO);

        return etiqueta;
    }

    private JButton crearBoton(String texto, Color color) {

        JButton boton = new JButton(texto);

        boton.setFont(
            new Font("Times New Roman", Font.BOLD, 14)
        );

        boton.setForeground(BLANCO);
        boton.setBackground(color);
        boton.setFocusPainted(false);
        boton.setBorderPainted(false);
        boton.setOpaque(true);

        boton.setPreferredSize(
            new Dimension(125, 34)
        );

        return boton;
    }
    

 // =====================================================
 // EXPORTACIÓN DEL INFORME INSTITUCIONAL EN PDF
 // =====================================================

 private void exportarReportePDF() {

     if (actividadesActuales == null || actividadesActuales.isEmpty()) {

         JOptionPane.showMessageDialog(
             this,
             "No existen actividades para exportar.",
             "Sin resultados",
             JOptionPane.WARNING_MESSAGE
         );

         return;
     }

     JFileChooser selector = new JFileChooser();

     selector.setDialogTitle("Guardar informe institucional");

     selector.setFileFilter(
         new FileNameExtensionFilter(
             "Documento PDF (*.pdf)",
             "pdf"
         )
     );

     String fechaArchivo = LocalDateTime.now().format(
         DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")
     );

     selector.setSelectedFile(
         new File("Informe_Actividades_" + fechaArchivo + ".pdf")
     );

     int resultado = selector.showSaveDialog(this);

     if (resultado != JFileChooser.APPROVE_OPTION) {
         return;
     }

     File destino = selector.getSelectedFile();

     // Asegurar que el archivo tenga extensión PDF
     if (!destino.getName().toLowerCase().endsWith(".pdf")) {

         destino = new File(
             destino.getAbsolutePath() + ".pdf"
         );
     }

     // Evitar sobrescribir archivos sin autorización
     if (destino.exists()) {

         int confirmacion = JOptionPane.showConfirmDialog(
             this,
             "El archivo ya existe.\n¿Deseas reemplazarlo?",
             "Confirmar reemplazo",
             JOptionPane.YES_NO_OPTION,
             JOptionPane.WARNING_MESSAGE
         );

         if (confirmacion != JOptionPane.YES_OPTION) {
             return;
         }
     }

     try {

         GeneradorReportePDF generador = new GeneradorReportePDF();

         generador.generarReporteActividades(
             actividadesActuales,
             obtenerDescripcionReporte(),
             usuarioActual,
             destino
         );

         JOptionPane.showMessageDialog(
             this,
             "El informe institucional se generó correctamente.\n\n"
             + "Archivo: " + destino.getAbsolutePath(),
             "Exportación completada",
             JOptionPane.INFORMATION_MESSAGE
         );

     } catch (IOException e) {

         JOptionPane.showMessageDialog(
             this,
             "No fue posible generar el documento PDF.\n\n"
             + e.getMessage(),
             "Error de exportación",
             JOptionPane.ERROR_MESSAGE
         );

         e.printStackTrace();

     } catch (Exception e) {

         JOptionPane.showMessageDialog(
             this,
             "Ocurrió un error al generar el informe.\n\n"
             + e.getMessage(),
             "Error",
             JOptionPane.ERROR_MESSAGE
         );

         e.printStackTrace();
     }
 }


 // =====================================================
 // DESCRIPCIÓN DE LOS FILTROS DEL INFORME
 // =====================================================

 private String obtenerDescripcionReporte() {

     String tipo = String.valueOf(
         cmbTipoReporte.getSelectedItem()
     );

     String periodo = String.valueOf(
         cmbPeriodo.getSelectedItem()
     );

     String descripcion = tipo + " | Periodo: " + periodo;

     if ("Actividad por usuario".equals(tipo)) {

         int indice = cmbUsuarios.getSelectedIndex();

         if (indice > 0 && indice <= usuarios.size()) {

             Usuario seleccionado = usuarios.get(indice - 1);

             descripcion +=
                 " | Usuario: "
                 + seleccionado.getNombre()
                 + " ("
                 + seleccionado.getNombreUsuario()
                 + ")";
         }
     }

     if ("Personalizado".equals(periodo)) {

         LocalDate inicio = convertirFecha(
             (Date) spnFechaInicio.getValue()
         );

         LocalDate fin = convertirFecha(
             (Date) spnFechaFin.getValue()
         );

         DateTimeFormatter formato = 
             DateTimeFormatter.ofPattern("dd/MM/yyyy");

         descripcion +=
             " | Del "
             + inicio.format(formato)
             + " al "
             + fin.format(formato);
     }

     return descripcion;
 }

}
