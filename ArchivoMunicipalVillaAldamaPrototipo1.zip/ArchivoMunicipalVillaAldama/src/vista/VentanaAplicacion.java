
package vista;

import modelo.Usuario;  

import servicio.ActividadServicio;

import java.sql.SQLException;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class VentanaAplicacion extends JFrame {

    // COLORES INSTITUCIONALES
    private static final Color GUINDA = new Color(112, 0, 25);
    private static final Color GUINDA_OSCURO = new Color(82, 0, 18);
    private static final Color GUINDA_CLARO = new Color(139, 43, 65);
    private static final Color DORADO = new Color(184, 154, 90);
    private static final Color MARFIL = new Color(247, 242, 234);
    private static final Color BLANCO = Color.WHITE;
    private static final Color TEXTO = new Color(65, 59, 56);
    private static final Color GRIS = new Color(125, 119, 114);

    // IDENTIFICADORES
    private static final String INICIO = "INICIO";
    private static final String LOGIN = "LOGIN";
    private static final String SISTEMA = "SISTEMA";

    // COMPONENTES PRINCIPALES
    private final CardLayout layoutPrincipal;
    private final JPanel contenedorPrincipal;

    private CardLayout layoutTrabajo;
    private JPanel areaTrabajo;

    private JPanel menuLateral;
    private JPanel panelSistema;

    private Usuario usuarioActual;
    
    private final ActividadServicio actividadServicio =
            new ActividadServicio();

    private final Map<String, JPanel> pantallas =
            new LinkedHashMap<>();

    public VentanaAplicacion() {

        setTitle(
            "Sistema Integral de Gestión Documental - Villa Aldama"
        );

        setSize(1200, 760);
        setMinimumSize(new Dimension(1000, 650));

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {

                salirAplicacion();
            }
        });

        setLocationRelativeTo(null);

        layoutPrincipal = new CardLayout();
        contenedorPrincipal = new JPanel(layoutPrincipal);

        VentanaInicio pantallaInicio =
                new VentanaInicio(this::mostrarLogin);

        pantallaInicio.setName(INICIO);

        contenedorPrincipal.add(pantallaInicio, INICIO);

        add(contenedorPrincipal);

        layoutPrincipal.show(contenedorPrincipal, INICIO);
    }

    // ==========================================
    // INICIO DE SESIÓN
    // ==========================================

    private void mostrarLogin() {

        VentanaLogin pantallaLogin =
                new VentanaLogin(this::iniciarSesion);

        Component[] componentes =
                contenedorPrincipal.getComponents();

        for (Component componente : componentes) {

            if (LOGIN.equals(componente.getName())) {
                contenedorPrincipal.remove(componente);
            }
        }

        pantallaLogin.setName(LOGIN);

        contenedorPrincipal.add(pantallaLogin, LOGIN);

        layoutPrincipal.show(contenedorPrincipal, LOGIN);

        contenedorPrincipal.revalidate();
        contenedorPrincipal.repaint();
    }


private void iniciarSesion(Usuario usuario) {

    if (usuario == null || !usuario.isActivo()) {

        JOptionPane.showMessageDialog(
                this,
                "No fue posible iniciar la sesión con una cuenta activa.",
                "Error de autenticación",
                JOptionPane.ERROR_MESSAGE
        );

        return;
    }

    String rol = normalizarRol(usuario.getRol());

    if (!rol.equals("ADMINISTRADOR")
            && !rol.equals("ARCHIVISTA")
            && !rol.equals("CONSULTA")) {

        JOptionPane.showMessageDialog(
                this,
                "El usuario no tiene un rol autorizado.",
                "Acceso denegado",
                JOptionPane.WARNING_MESSAGE
        );

        mostrarLogin();
        return;
    }

    try {

        System.out.println("--------------------------------");
        System.out.println("AUTENTICACIÓN CORRECTA");
        System.out.println("Usuario: " + usuario.getNombreUsuario());
        System.out.println("Rol: " + rol);
        System.out.println("Construyendo ventana principal...");

        usuarioActual = usuario;

        construirSistema();

        System.out.println("Sistema construido correctamente.");

        layoutPrincipal.show(contenedorPrincipal, SISTEMA);

        contenedorPrincipal.revalidate();
        contenedorPrincipal.repaint();

        System.out.println("Ventana principal mostrada.");
        System.out.println("--------------------------------");

    } catch (RuntimeException ex) {

        ex.printStackTrace();

        usuarioActual = null;

        Component[] componentes =
                contenedorPrincipal.getComponents();

        for (Component componente : componentes) {

            if (SISTEMA.equals(componente.getName())) {
                contenedorPrincipal.remove(componente);
            }
        }

        contenedorPrincipal.revalidate();
        contenedorPrincipal.repaint();

        JOptionPane.showMessageDialog(
                this,
                "Las credenciales fueron verificadas, "
                + "pero ocurrió un error al construir "
                + "la ventana principal.\n\n"
                + "Error: " + ex.getClass().getSimpleName()
                + "\nDetalle: " + ex.getMessage()
                + "\n\nConsulta la consola de Eclipse "
                + "para identificar el origen.",
                "Error al abrir el sistema",
                JOptionPane.ERROR_MESSAGE
        );
    }
}


private String normalizarRol(String rol) {

    if (rol == null) {
        return "";
    }

    String rolNormalizado =
            rol.trim().toUpperCase(java.util.Locale.ROOT);

    // CONSULTOR y CONSULTA tendrán los mismos permisos.
    if (rolNormalizado.equals("CONSULTOR")) {
        return "CONSULTA";
    }

    return rolNormalizado;
}


    // ==========================================
    // CONSTRUIR SISTEMA
    // ==========================================


private void construirSistema() {

    // ==========================================
    // IDENTIFICAR EL ROL DEL USUARIO
    // ==========================================

    if (usuarioActual == null || !usuarioActual.isActivo()) {
        throw new SecurityException(
            "No existe un usuario activo para construir el sistema."
        );
    }

    boolean administrador = esAdministrador();
    boolean archivista = esArchivista();
    boolean consulta = esConsulta();

    if (!administrador && !archivista && !consulta) {
        throw new SecurityException(
            "El usuario no tiene un rol autorizado."
        );
    }

    // ==========================================
    // PANEL PRINCIPAL
    // ==========================================

    panelSistema = new JPanel(new BorderLayout());

    // ==========================================
    // MENÚ LATERAL
    // ==========================================

    menuLateral = new JPanel();

    menuLateral.setLayout(
        new BoxLayout(menuLateral, BoxLayout.Y_AXIS)
    );

    menuLateral.setBackground(GUINDA_OSCURO);
    menuLateral.setPreferredSize(new Dimension(245, 0));

    menuLateral.setBorder(
        new EmptyBorder(20, 15, 20, 15)
    );

    // ==========================================
    // ÁREA DE TRABAJO
    // ==========================================

    layoutTrabajo = new CardLayout();

    areaTrabajo = new JPanel(layoutTrabajo);
    areaTrabajo.setBackground(MARFIL);

    pantallas.clear();

    // ==========================================
    // INICIO DE TRABAJO
    // DISPONIBLE PARA TODOS LOS ROLES
    // ==========================================

    agregarPantalla(
    	    "INICIO_TRABAJO",
    	    crearPantalla(
    	        "Panel principal",
    	        "Sistema Integral de Gestión Documental.",
    	        "Bienvenido al Archivo Municipal de Villa Aldama. "
    	        + "Selecciona una herramienta del menú lateral.",
    	        true
    	    )
    	);

    // ==========================================
    // CONSULTA DOCUMENTAL
    // DISPONIBLE PARA LOS TRES ROLES
    // ==========================================

    if (administrador || archivista || consulta) {

        agregarPantalla(
            "CONSULTA",
            new VentanaConsulta(usuarioActual)
        );
    }

    // ==========================================
    // MÓDULOS DE ADMINISTRADOR Y ARCHIVISTA
    // ==========================================

    if (administrador || archivista) {

        // GESTIÓN DOCUMENTAL

        agregarPantalla(
            "DOCUMENTOS",
            new VentanaDocumentos(usuarioActual)
        );

        // EXPEDIENTES

        agregarPantalla(
            "EXPEDIENTES",
            crearPantalla(
                "Gestión de expedientes",
                "Organización y administración de expedientes.",
                "Módulo preparado para el Prototipo 2. "
                + "Aquí se incorporarán las operaciones de creación, "
                + "organización y consulta de expedientes."
            )
        );

        // INVENTARIOS

        agregarPantalla(
            "INVENTARIOS",
            crearPantalla(
                "Inventarios documentales",
                "Control y organización de los inventarios del archivo.",
                "Módulo preparado para el Prototipo 2. "
                + "Aquí se incorporarán los inventarios documentales "
                + "y sus operaciones correspondientes."
            )
        );
    }


    // ==========================================
    // MÓDULOS EXCLUSIVOS DEL ADMINISTRADOR
    // ==========================================

    if (administrador) {

        // USUARIOS

        agregarPantalla(
            "USUARIOS",
            new VentanaUsuarios(usuarioActual)
        );

        // CATÁLOGOS

        agregarPantalla(
            "CATALOGOS",
            crearPantalla(
                "Catálogos del sistema",
                "Administración de catálogos documentales.",
                "Módulo preparado para el Prototipo 2. "
                + "Los catálogos oficiales deberán validarse "
                + "con el Ayuntamiento."
            )
        );

        // REPORTES

        agregarPantalla(
            "REPORTES",
            new VentanaReportes(usuarioActual)
        );

    }


    // ==========================================
    // CONSTRUIR MENÚ SEGÚN EL ROL
    // ==========================================

    construirMenu();

    // ==========================================
    // PANEL DE DESPLAZAMIENTO DEL MENÚ
    // ==========================================

    JScrollPane scrollMenu = new JScrollPane(
        menuLateral,
        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
    );

    scrollMenu.setBorder(
        BorderFactory.createEmptyBorder()
    );

    scrollMenu.setPreferredSize(
        new Dimension(265, 600)
    );

    // ==========================================
    // DISTRIBUCIÓN DEL SISTEMA
    // ==========================================

    panelSistema.add(
        scrollMenu,
        BorderLayout.WEST
    );

    panelSistema.add(
        areaTrabajo,
        BorderLayout.CENTER
    );

    // ==========================================
    // REEMPLAZAR PANTALLA ANTERIOR
    // ==========================================

    Component[] componentes =
            contenedorPrincipal.getComponents();

    for (Component componente : componentes) {

        if (SISTEMA.equals(componente.getName())) {
            contenedorPrincipal.remove(componente);
        }
    }

    panelSistema.setName(SISTEMA);

    contenedorPrincipal.add(
        panelSistema,
        SISTEMA
    );

    // ==========================================
    // MOSTRAR INICIO DE TRABAJO
    // ==========================================

    mostrarPantalla("INICIO_TRABAJO");

    contenedorPrincipal.revalidate();
    contenedorPrincipal.repaint();
}


    // ==========================================
    // CONSTRUIR MENÚ SEGÚN EL ROL
    // ==========================================

    private void construirMenu() {

        menuLateral.removeAll();

        JLabel nombreSistema = new JLabel(
            "<html><b>ARCHIVO<br>MUNICIPAL</b></html>"
        );

        nombreSistema.setForeground(BLANCO);
        nombreSistema.setFont(
            new Font("Serif", Font.BOLD, 21)
        );

        nombreSistema.setAlignmentX(Component.LEFT_ALIGNMENT);

        menuLateral.add(nombreSistema);
        menuLateral.add(Box.createVerticalStrut(8));

        JLabel municipio = new JLabel(
            "VILLA ALDAMA, VERACRUZ"
        );

        municipio.setForeground(DORADO);
        municipio.setFont(
            new Font("Serif", Font.PLAIN, 11)
        );

        municipio.setAlignmentX(Component.LEFT_ALIGNMENT);

        menuLateral.add(municipio);
        menuLateral.add(Box.createVerticalStrut(25));

        menuLateral.add(crearSeparadorMenu());

        agregarBotonMenu(
            "⌂   Inicio",
            "INICIO_TRABAJO"
        );

        String rol = normalizarRol(usuarioActual.getRol());

        // ADMINISTRADOR Y ARCHIVISTA
        if (esAdministrador() || esArchivista()) {

            agregarBotonMenu(
                "▤   Gestión documental",
                "DOCUMENTOS"
            );

            agregarBotonMenu(
                "▣   Expedientes",
                "EXPEDIENTES"
            );

            agregarBotonMenu(
                "▥   Inventarios",
                "INVENTARIOS"
            );
        }

        // LOS TRES ROLES PUEDEN CONSULTAR
        if (esAdministrador()
                || esArchivista()
                || esConsulta()) {

            agregarBotonMenu(
                "⌕   Consulta documental",
                "CONSULTA"
            );
        }

        // SOLO ADMINISTRADOR
        if (esAdministrador()) {

            menuLateral.add(
                Box.createVerticalStrut(8)
            );

            menuLateral.add(crearSeparadorMenu());

            agregarBotonMenu(
                "♙   Usuarios",
                "USUARIOS"
            );

            agregarBotonMenu(
                "⚙   Catálogos",
                "CATALOGOS"
            );

            agregarBotonMenu(
                "▤   Reportes",
                "REPORTES"
            );
        }

        // ESPACIO INFERIOR
        menuLateral.add(Box.createVerticalGlue());

        menuLateral.add(crearSeparadorMenu());

        JLabel informacionUsuario = new JLabel(
            "<html><b>" + usuarioActual.getNombre()
            + "</b><br>" + rol + "</html>"
        );

        informacionUsuario.setForeground(BLANCO);

        informacionUsuario.setFont(
            new Font("Serif", Font.PLAIN, 13)
        );

        informacionUsuario.setAlignmentX(
            Component.LEFT_ALIGNMENT
        );

        menuLateral.add(informacionUsuario);

        menuLateral.add(Box.createVerticalStrut(15));

        JButton cerrarSesion = crearBotonMenu(
            "Cerrar sesión"
        );

        cerrarSesion.setBackground(GUINDA_CLARO);

        cerrarSesion.addActionListener(
            e -> cerrarSesion()
        );

        menuLateral.add(cerrarSesion);

        menuLateral.revalidate();
        menuLateral.repaint();
    }

    // ==========================================
    // VALIDACIÓN DE ROLES
    // ==========================================

    private boolean esAdministrador() {

        return "ADMINISTRADOR".equals(
            normalizarRol(usuarioActual.getRol())
        );
    }

    private boolean esArchivista() {

        return "ARCHIVISTA".equals(
            normalizarRol(usuarioActual.getRol())
        );
    }

    private boolean esConsulta() {

        return "CONSULTA".equals(
            normalizarRol(usuarioActual.getRol())
        );
    }

    // ==========================================
    // BOTONES DEL MENÚ
    // ==========================================

    private void agregarBotonMenu(
            String texto,
            String identificador) {

        JButton boton = crearBotonMenu(texto);

        boton.addActionListener(
            e -> mostrarPantalla(identificador)
        );

        menuLateral.add(boton);

        menuLateral.add(
            Box.createVerticalStrut(5)
        );
    }

    private JButton crearBotonMenu(String texto) {

        JButton boton = new JButton(texto);

        boton.setFont(
            new Font("Serif", Font.PLAIN, 14)
        );

        boton.setForeground(BLANCO);
        boton.setBackground(GUINDA_OSCURO);

        boton.setHorizontalAlignment(
            SwingConstants.LEFT
        );

        boton.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 43)
        );

        boton.setAlignmentX(Component.LEFT_ALIGNMENT);

        boton.setBorder(
            BorderFactory.createEmptyBorder(
                8, 10, 8, 5
            )
        );

        boton.setFocusPainted(false);

        boton.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );

        return boton;
    }

    private JSeparator crearSeparadorMenu() {

        JSeparator separador = new JSeparator();

        separador.setForeground(DORADO);
        separador.setBackground(GUINDA_OSCURO);

        separador.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 1)
        );

        return separador;
    }

    // ==========================================
    // PANTALLAS PROVISIONALES
    // ==========================================


private JPanel crearPantalla(
        String titulo,
        String subtitulo,
        String descripcion) {

    return crearPantalla(
        titulo,
        subtitulo,
        descripcion,
        false
    );
}


private JPanel crearPantalla(
        String titulo,
        String subtitulo,
        String descripcion,
        boolean mostrarEscudo) {

    JPanel panel = new JPanel(
        new BorderLayout(15, 15)
    );

    panel.setBackground(MARFIL);

    panel.setBorder(
        new EmptyBorder(35, 40, 35, 40)
    );

    // ENCABEZADO
    JPanel encabezado = new JPanel(
        new GridLayout(2, 1, 5, 5)
    );

    encabezado.setBackground(MARFIL);

    JLabel etiquetaTitulo = new JLabel(titulo);

    etiquetaTitulo.setFont(
        new Font("Serif", Font.BOLD, 27)
    );

    etiquetaTitulo.setForeground(GUINDA);

    JLabel etiquetaSubtitulo = new JLabel(subtitulo);

    etiquetaSubtitulo.setFont(
        new Font("Serif", Font.PLAIN, 15)
    );

    etiquetaSubtitulo.setForeground(TEXTO);

    encabezado.add(etiquetaTitulo);
    encabezado.add(etiquetaSubtitulo);

    // PANEL BLANCO
    JPanel contenido = new JPanel(
        new BorderLayout(10, 15)
    );

    contenido.setBackground(BLANCO);

    contenido.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                new Color(225, 217, 205)
            ),
            new EmptyBorder(25, 25, 25, 25)
        )
    );

    // MENSAJE DE BIENVENIDA
    JLabel descripcionLabel = new JLabel(
        "<html><div style='width:500px;'>"
        + descripcion
        + "</div></html>"
    );

    descripcionLabel.setFont(
        new Font("Serif", Font.PLAIN, 16)
    );

    descripcionLabel.setForeground(GRIS);

    contenido.add(
        descripcionLabel,
        BorderLayout.NORTH
    );

    // ESCUDO INSTITUCIONAL
    if (mostrarEscudo) {

        JLabel etiquetaEscudo = crearEscudoBienvenida();

        contenido.add(
            etiquetaEscudo,
            BorderLayout.CENTER
        );
    }

    panel.add(encabezado, BorderLayout.NORTH);
    panel.add(contenido, BorderLayout.CENTER);

    return panel;
}


private JLabel crearEscudoBienvenida() {

    JLabel etiquetaEscudo = new JLabel();

    etiquetaEscudo.setHorizontalAlignment(
        SwingConstants.CENTER
    );

    etiquetaEscudo.setVerticalAlignment(
        SwingConstants.CENTER
    );

    try {

        java.net.URL rutaEscudo =
            getClass().getResource(
                "/recursos/escudo_villa_aldama_menu.png"
            );

        if (rutaEscudo == null) {

            throw new java.io.IOException(
                "No se encontró escudo_villa_aldama_menu.png "
                + "en la carpeta recursos."
            );
        }

        BufferedImage imagenOriginal =
            ImageIO.read(rutaEscudo);

        if (imagenOriginal == null) {

            throw new java.io.IOException(
                "No fue posible interpretar la imagen del escudo."
            );
        }

        // TAMAÑO MÁXIMO DEL ESCUDO
        int anchoMaximo = 230;
        int altoMaximo = 230;

        // CONSERVAR LAS PROPORCIONES ORIGINALES
        double escala = Math.min(
            (double) anchoMaximo / imagenOriginal.getWidth(),
            (double) altoMaximo / imagenOriginal.getHeight()
        );

        int nuevoAncho = (int) (
            imagenOriginal.getWidth() * escala
        );

        int nuevoAlto = (int) (
            imagenOriginal.getHeight() * escala
        );

        Image imagenEscalada =
            imagenOriginal.getScaledInstance(
                nuevoAncho,
                nuevoAlto,
                Image.SCALE_SMOOTH
            );

        etiquetaEscudo.setIcon(
            new ImageIcon(imagenEscalada)
        );

    } catch (Exception ex) {

        System.err.println(
            "ERROR AL CARGAR EL ESCUDO INSTITUCIONAL: "
            + ex.getMessage()
        );

        etiquetaEscudo.setText(
            "Escudo institucional no disponible"
        );

        etiquetaEscudo.setForeground(GRIS);
    }

    return etiquetaEscudo;
}

    // ==========================================
    // REGISTRAR PANTALLAS
    // ==========================================

    private void agregarPantalla(
            String identificador,
            JPanel panel) {

        pantallas.put(identificador, panel);

        areaTrabajo.add(panel, identificador);
    }

    // ==========================================
    // CAMBIAR PANTALLA
    // ==========================================

    private void mostrarPantalla(String identificador) {

        if (!pantallas.containsKey(identificador)) {
            return;
        }

        // CONTROL DE ACCESO
        if (identificador.equals("USUARIOS")
                || identificador.equals("CATALOGOS")
                || identificador.equals("REPORTES")) {

            if (!esAdministrador()) {

                JOptionPane.showMessageDialog(
                    this,
                    "No tienes autorización para acceder a este módulo.",
                    "Acceso restringido",
                    JOptionPane.WARNING_MESSAGE
                );

                return;
            }
        }

        if (identificador.equals("DOCUMENTOS")
                || identificador.equals("EXPEDIENTES")
                || identificador.equals("INVENTARIOS")) {

            if (!esAdministrador() && !esArchivista()) {

                JOptionPane.showMessageDialog(
                    this,
                    "No tienes autorización para acceder a este módulo.",
                    "Acceso restringido",
                    JOptionPane.WARNING_MESSAGE
                );

                return;
            }
        }

        layoutTrabajo.show(areaTrabajo, identificador);

        areaTrabajo.revalidate();
        areaTrabajo.repaint();
    }

    // ==========================================
    // CERRAR SESIÓN
    // ==========================================


private void cerrarSesion() {

    int respuesta = JOptionPane.showConfirmDialog(
        this,
        "¿Deseas cerrar la sesión actual?",
        "Cerrar sesión",
        JOptionPane.YES_NO_OPTION
    );

    if (respuesta != JOptionPane.YES_OPTION) {
        return;
    }

    try {

        if (usuarioActual != null) {

            actividadServicio.registrarActividad(
                usuarioActual.getIdUsuario(),
                "SESIONES",
                null,
                "CIERRE_SESION",
                "El usuario cerró su sesión."
            );
        }

        usuarioActual = null;
        pantallas.clear();

        mostrarInicio();

    } catch (SQLException ex) {

        JOptionPane.showMessageDialog(
            this,
            "No fue posible registrar el cierre de sesión.\n"
                + "No se cerrará la sesión para proteger "
                + "el registro de actividad.",
            "Error de bitácora",
            JOptionPane.ERROR_MESSAGE
        );

        ex.printStackTrace();
    }
}


//==========================================
//CERRAR APLICACIÓN Y REGISTRAR ACTIVIDAD
//==========================================


private void salirAplicacion() {

    int respuesta = JOptionPane.showConfirmDialog(
        this,
        "¿Deseas salir del Sistema Integral de Gestión Documental?",
        "Salir del sistema",
        JOptionPane.YES_NO_OPTION
    );

    if (respuesta != JOptionPane.YES_OPTION) {
        return;
    }

    try {

        if (usuarioActual != null) {

            actividadServicio.registrarActividad(
                usuarioActual.getIdUsuario(),
                "SESIONES",
                null,
                "CIERRE_SESION",
                "El usuario cerró la aplicación."
            );
        }

    } catch (SQLException ex) {

        int continuar = JOptionPane.showConfirmDialog(
            this,
            "No fue posible registrar el cierre de sesión "
                + "en la bitácora.\n"
                + "¿Deseas salir de todas formas?",
            "Advertencia de auditoría",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (continuar != JOptionPane.YES_OPTION) {
            return;
        }

        ex.printStackTrace();
    }

    dispose();
    System.exit(0);
}


    // ==========================================
    // REGRESAR A BIENVENIDA
    // ==========================================

    private void mostrarInicio() {

        Component[] componentes =
                contenedorPrincipal.getComponents();

        for (Component componente : componentes) {

            if (!INICIO.equals(componente.getName())
                    && !LOGIN.equals(componente.getName())) {

                contenedorPrincipal.remove(componente);
            }
        }

        layoutPrincipal.show(
            contenedorPrincipal,
            INICIO
        );

        contenedorPrincipal.revalidate();
        contenedorPrincipal.repaint();
    }

    // ==========================================
    // INICIAR PROGRAMA
    // ==========================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            VentanaAplicacion aplicacion =
                    new VentanaAplicacion();

            aplicacion.setVisible(true);
        });
    }
}
