
package vista;

import modelo.Usuario;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    private final Usuario usuario;

    private final Color COLOR_GUINDA = new Color(138, 22, 48);
    private final Color COLOR_FONDO = new Color(245, 245, 245);

    public VentanaPrincipal(Usuario usuario) {

        if (usuario == null || !usuario.isActivo()) {
            throw new SecurityException(
                "No existe una sesión válida para ingresar al sistema."
            );
        }

        this.usuario = usuario;

        String rol = usuario.getRol();

        if (!"ADMINISTRADOR".equalsIgnoreCase(rol)
                && !"ARCHIVISTA".equalsIgnoreCase(rol)
                && !"CONSULTA".equalsIgnoreCase(rol)) {

            throw new SecurityException(
                "El usuario no tiene un rol autorizado."
            );
        }

        configurarVentana();
        construirInterfaz();
    }

    private void configurarVentana() {

        setTitle("Sistema Integral de Gestión Documental - Archivo Municipal");

        setSize(1050, 650);
        setMinimumSize(new Dimension(850, 550));

        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void construirInterfaz() {

        JPanel principal = new JPanel(new BorderLayout(15, 15));
        principal.setBackground(COLOR_FONDO);
        principal.setBorder(
            BorderFactory.createEmptyBorder(25, 30, 25, 30)
        );

        // ENCABEZADO

        JPanel encabezado = new JPanel(new GridLayout(3, 1, 5, 5));
        encabezado.setBackground(COLOR_FONDO);

        JLabel titulo = new JLabel(
            "ARCHIVO MUNICIPAL",
            SwingConstants.CENTER
        );

        titulo.setFont(new Font("Serif", Font.BOLD, 30));
        titulo.setForeground(COLOR_GUINDA);

        JLabel subtitulo = new JLabel(
            "Sistema Integral de Gestión Documental",
            SwingConstants.CENTER
        );

        subtitulo.setFont(new Font("Serif", Font.PLAIN, 20));

        JLabel institucion = new JLabel(
            "H. Ayuntamiento de Villa Aldama, Veracruz",
            SwingConstants.CENTER
        );

        institucion.setFont(new Font("Serif", Font.PLAIN, 16));

        encabezado.add(titulo);
        encabezado.add(subtitulo);
        encabezado.add(institucion);

        principal.add(encabezado, BorderLayout.NORTH);

        // INFORMACIÓN DEL USUARIO

        JPanel panelUsuario = new JPanel(new GridLayout(2, 1, 5, 5));
        panelUsuario.setBackground(Color.WHITE);

        panelUsuario.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_GUINDA),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
            )
        );

        JLabel lblBienvenida = new JLabel(
            "Bienvenido(a): " + usuario.getNombre()
        );

        lblBienvenida.setFont(
            new Font("Serif", Font.BOLD, 17)
        );

        JLabel lblRol = new JLabel(
            "Rol de usuario: " + usuario.getRol()
        );

        lblRol.setFont(
            new Font("Serif", Font.PLAIN, 15)
        );

        panelUsuario.add(lblBienvenida);
        panelUsuario.add(lblRol);

        // MENÚ PRINCIPAL

        JPanel panelMenu = new JPanel(new GridLayout(0, 2, 20, 20));
        panelMenu.setBackground(COLOR_FONDO);
        panelMenu.setBorder(
            BorderFactory.createEmptyBorder(30, 40, 30, 40)
        );

        if (esAdministrador() || esArchivista()) {

            JButton btnDocumentos = crearBoton(
                "GESTIÓN DOCUMENTAL"
            );

            btnDocumentos.addActionListener(
                e -> abrirDocumentos()
            );

            panelMenu.add(btnDocumentos);
        }

        if (esConsulta()) {

            JButton btnConsulta = crearBoton(
                "CONSULTA DOCUMENTAL"
            );

            btnConsulta.addActionListener(
                e -> abrirConsulta()
            );

            panelMenu.add(btnConsulta);
        }

        if (esAdministrador()) {

            JButton btnUsuarios = crearBoton(
                "ADMINISTRACIÓN DE USUARIOS"
            );

            btnUsuarios.addActionListener(
                e -> abrirUsuarios()
            );

            panelMenu.add(btnUsuarios);
        }

        // Si no hay suficientes botones, agregamos espacio visual.

        if (panelMenu.getComponentCount() == 1) {
            panelMenu.add(new JLabel());
        }

        principal.add(panelUsuario, BorderLayout.CENTER);
        principal.add(panelMenu, BorderLayout.SOUTH);

        // PIE DE VENTANA

        JPanel pie = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pie.setBackground(COLOR_FONDO);

        JButton btnCerrarSesion = new JButton("Cerrar sesión");

        btnCerrarSesion.setFont(
            new Font("Serif", Font.BOLD, 14)
        );

        btnCerrarSesion.setBackground(COLOR_GUINDA);
        btnCerrarSesion.setForeground(Color.WHITE);
        btnCerrarSesion.setFocusPainted(false);

        btnCerrarSesion.addActionListener(
            e -> cerrarSesion()
        );

        pie.add(btnCerrarSesion);

        principal.add(pie, BorderLayout.PAGE_END);

        setContentPane(principal);
    }

    private JButton crearBoton(String texto) {

        JButton boton = new JButton(
            "<html><center>" + texto + "</center></html>"
        );

        boton.setFont(
            new Font("Serif", Font.BOLD, 16)
        );

        boton.setBackground(COLOR_GUINDA);
        boton.setForeground(Color.WHITE);

        boton.setFocusPainted(false);
        boton.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );

        boton.setPreferredSize(
            new Dimension(250, 90)
        );

        return boton;
    }

    // VALIDACIÓN DE ROLES

    private boolean esAdministrador() {

        return "ADMINISTRADOR".equalsIgnoreCase(
            usuario.getRol()
        );
    }

    private boolean esArchivista() {

        return "ARCHIVISTA".equalsIgnoreCase(
            usuario.getRol()
        );
    }

    private boolean esConsulta() {

        return "CONSULTA".equalsIgnoreCase(
            usuario.getRol()
        );
    }

    // APERTURA DE GESTIÓN DOCUMENTAL

    private void abrirDocumentos() {

        if (!esAdministrador() && !esArchivista()) {

            mostrarError(
                "No tienes autorización para gestionar documentos."
            );

            return;
        }

        try {

            VentanaDocumentos panelDocumentos =
                new VentanaDocumentos(usuario);

            JFrame ventanaDocumentos = new JFrame(
                "Gestión documental - Archivo Municipal"
            );

            ventanaDocumentos.setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
            );

            ventanaDocumentos.setSize(1200, 750);
            ventanaDocumentos.setMinimumSize(
                new Dimension(1000, 650)
            );

            ventanaDocumentos.setLocationRelativeTo(this);

            ventanaDocumentos.setContentPane(panelDocumentos);

            ventanaDocumentos.setVisible(true);

        } catch (SecurityException ex) {

            mostrarError(ex.getMessage());
        }
    }

    // APERTURA DE CONSULTA DOCUMENTAL

    private void abrirConsulta() {

        try {

            VentanaConsulta panelConsulta =
                new VentanaConsulta(usuario);

            JFrame ventanaConsulta = new JFrame(
                "Consulta documental - Archivo Municipal"
            );

            ventanaConsulta.setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
            );

            ventanaConsulta.setSize(1100, 700);

            ventanaConsulta.setMinimumSize(
                new Dimension(900, 600)
            );

            ventanaConsulta.setLocationRelativeTo(this);

            ventanaConsulta.setContentPane(panelConsulta);

            ventanaConsulta.setVisible(true);

        } catch (SecurityException ex) {

            mostrarError(ex.getMessage());

        }
    }

    // APERTURA DE ADMINISTRACIÓN DE USUARIOS

    private void abrirUsuarios() {

        if (!esAdministrador()) {

            mostrarError(
                "Solo el administrador puede gestionar usuarios."
            );

            return;
        }

        try {

            VentanaUsuarios panelUsuarios =
                new VentanaUsuarios(usuario);

            JFrame ventanaUsuarios = new JFrame(
                "Administración de usuarios - Archivo Municipal"
            );

            ventanaUsuarios.setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
            );

            ventanaUsuarios.setSize(1100, 700);

            ventanaUsuarios.setMinimumSize(
                new Dimension(900, 600)
            );

            ventanaUsuarios.setLocationRelativeTo(this);

            ventanaUsuarios.setContentPane(panelUsuarios);

            ventanaUsuarios.setVisible(true);

        } catch (SecurityException ex) {

            mostrarError(ex.getMessage());

        }
    }
    // CERRAR SESIÓN

    private void cerrarSesion() {

        int respuesta = JOptionPane.showConfirmDialog(
            this,
            "¿Deseas cerrar tu sesión?",
            "Cerrar sesión",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (respuesta == JOptionPane.YES_OPTION) {

            dispose();

            SwingUtilities.invokeLater(() -> {

                VentanaAplicacion aplicacion =
                    new VentanaAplicacion();

                aplicacion.setVisible(true);
            });
        }
    }

    // MENSAJES DE ERROR

    private void mostrarError(String mensaje) {

        JOptionPane.showMessageDialog(
            this,
            mensaje,
            "Acceso restringido",
            JOptionPane.WARNING_MESSAGE
        );
    }
}
