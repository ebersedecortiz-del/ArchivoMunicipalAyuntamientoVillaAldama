
package vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class VentanaInicio extends JPanel {

    // Identidad visual institucional
    private final Color GUINDA = new Color(112, 0, 25);
    private final Color GUINDA_OSCURO = new Color(82, 0, 18);
    private final Color DORADO = new Color(205, 170, 100);
    private final Color MARFIL = new Color(248, 237, 215);

    public VentanaInicio(Runnable accionIngresar) {

        setLayout(new BorderLayout());

        JPanel principal = new JPanel(new BorderLayout());
        principal.setBackground(GUINDA);

        // Línea superior
        JPanel lineaSuperior = new JPanel();
        lineaSuperior.setBackground(DORADO);
        lineaSuperior.setPreferredSize(new Dimension(0, 3));

        // Contenido central
        JPanel contenido = new JPanel(new GridBagLayout());
        contenido.setBackground(GUINDA);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel elementos = new JPanel();
        elementos.setLayout(new BoxLayout(elementos, BoxLayout.Y_AXIS));
        elementos.setBackground(GUINDA);

        // Escudo oficial
        JLabel imagenEscudo = new JLabel();
        imagenEscudo.setAlignmentX(Component.CENTER_ALIGNMENT);

        java.net.URL recurso = getClass().getResource(
            "/recursos/escudo_villa_aldama.png"
        );

        if (recurso != null) {

            try {

                BufferedImage original = ImageIO.read(recurso);

                if (original != null) {

                    int anchoMaximo = 230;
                    int altoMaximo = 290;

                    double escala = Math.min(
                        (double) anchoMaximo / original.getWidth(),
                        (double) altoMaximo / original.getHeight()
                    );

                    int nuevoAncho = (int) Math.round(
                        original.getWidth() * escala
                    );

                    int nuevoAlto = (int) Math.round(
                        original.getHeight() * escala
                    );

                    BufferedImage imagenEscalada =
                        new BufferedImage(
                            nuevoAncho,
                            nuevoAlto,
                            BufferedImage.TYPE_INT_ARGB
                        );

                    Graphics2D g2d = imagenEscalada.createGraphics();

                    g2d.setRenderingHint(
                        RenderingHints.KEY_INTERPOLATION,
                        RenderingHints.VALUE_INTERPOLATION_BICUBIC
                    );

                    g2d.setRenderingHint(
                        RenderingHints.KEY_RENDERING,
                        RenderingHints.VALUE_RENDER_QUALITY
                    );

                    g2d.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON
                    );

                    g2d.drawImage(
                        original, 0, 0,
                        nuevoAncho, nuevoAlto, null
                    );

                    g2d.dispose();

                    imagenEscudo.setIcon(
                        new ImageIcon(imagenEscalada)
                    );

                } else {

                    imagenEscudo.setText("No se pudo leer el escudo");
                    imagenEscudo.setForeground(MARFIL);
                }

            } catch (java.io.IOException ex) {

                imagenEscudo.setText("Error al cargar el escudo");
                imagenEscudo.setForeground(MARFIL);
                ex.printStackTrace();
            }

        } else {

            imagenEscudo.setText("ESCUDO OFICIAL");
            imagenEscudo.setForeground(MARFIL);
        }

        // Nombre del Ayuntamiento
        JLabel ayuntamiento = new JLabel(
            "H. AYUNTAMIENTO DE VILLA ALDAMA",
            SwingConstants.CENTER
        );

        ayuntamiento.setFont(
            new Font("Times New Roman", Font.PLAIN, 26)
        );
        ayuntamiento.setForeground(MARFIL);
        ayuntamiento.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Título principal
        JLabel titulo = new JLabel(
            "ARCHIVO MUNICIPAL",
            SwingConstants.CENTER
        );

        titulo.setFont(
            new Font("Times New Roman", Font.BOLD, 43)
        );
        titulo.setForeground(MARFIL);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Subtítulo
        JLabel subtitulo = new JLabel(
            "Sistema Integral de Gestión Documental",
            SwingConstants.CENTER
        );

        subtitulo.setFont(
            new Font("Times New Roman", Font.ITALIC, 21)
        );
        subtitulo.setForeground(MARFIL);
        subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Línea decorativa
        JPanel linea = new JPanel();
        linea.setBackground(DORADO);
        linea.setMaximumSize(new Dimension(450, 2));
        linea.setPreferredSize(new Dimension(450, 2));
        linea.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Botón de ingreso
        JButton btnIngresar = new JButton("INGRESAR AL SISTEMA");

        btnIngresar.setFont(
            new Font("Times New Roman", Font.BOLD, 19)
        );
        btnIngresar.setForeground(MARFIL);
        btnIngresar.setBackground(GUINDA);
        btnIngresar.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(DORADO, 2),
                new EmptyBorder(13, 35, 13, 35)
            )
        );
        btnIngresar.setFocusPainted(false);
        btnIngresar.setContentAreaFilled(false);
        btnIngresar.setOpaque(false);
        btnIngresar.setCursor(
            new Cursor(Cursor.HAND_CURSOR)
        );
        btnIngresar.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Ahora el botón solicita la navegación al contenedor principal
        btnIngresar.addActionListener(e -> {

            if (accionIngresar != null) {
                accionIngresar.run();
            }
        });

        // Efecto de color al pasar el cursor
        btnIngresar.addMouseListener(
            new java.awt.event.MouseAdapter() {

                @Override
                public void mouseEntered(
                    java.awt.event.MouseEvent e
                ) {
                    btnIngresar.setForeground(DORADO);
                }

                @Override
                public void mouseExited(
                    java.awt.event.MouseEvent e
                ) {
                    btnIngresar.setForeground(MARFIL);
                }
            }
        );

        // Pie institucional
        JLabel pie = new JLabel(
            "H. Ayuntamiento de Villa Aldama, Veracruz",
            SwingConstants.CENTER
        );

        pie.setFont(
            new Font("Times New Roman", Font.ITALIC, 15)
        );
        pie.setForeground(MARFIL);
        pie.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Organización de los elementos
        elementos.add(imagenEscudo);
        elementos.add(Box.createVerticalStrut(22));
        elementos.add(ayuntamiento);
        elementos.add(Box.createVerticalStrut(28));
        elementos.add(linea);
        elementos.add(Box.createVerticalStrut(24));
        elementos.add(titulo);
        elementos.add(Box.createVerticalStrut(12));
        elementos.add(subtitulo);
        elementos.add(Box.createVerticalStrut(35));
        elementos.add(btnIngresar);

        gbc.weighty = 1;
        contenido.add(elementos, gbc);

        // Pie de página
        JPanel panelPie = new JPanel(new BorderLayout());
        panelPie.setBackground(GUINDA_OSCURO);
        panelPie.setBorder(new EmptyBorder(13, 10, 13, 10));
        panelPie.add(pie, BorderLayout.CENTER);

        // Línea inferior
        JPanel lineaInferior = new JPanel();
        lineaInferior.setBackground(DORADO);
        lineaInferior.setPreferredSize(new Dimension(0, 3));

        panelPie.add(lineaInferior, BorderLayout.SOUTH);

        // Integración del panel
        principal.add(lineaSuperior, BorderLayout.NORTH);
        principal.add(contenido, BorderLayout.CENTER);
        principal.add(panelPie, BorderLayout.SOUTH);

        add(principal, BorderLayout.CENTER);
    }
}
